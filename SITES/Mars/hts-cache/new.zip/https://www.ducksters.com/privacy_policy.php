<!DOCTYPE HTML>
<html lang="en">
<head>
<meta name="description" content="Ducksters Privacy Policy">
<title>Ducksters: Privacy Policy</title>
<style type="text/css">

@media screen{

*, *:before, *:after {
  -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
}
 
body { margin: 0; }

img {
  max-width: 100%;
}

.columnsContainer { position: relative; margin: 1px; margin-left:auto; margin-right:auto; max-width:1000px;background-color: #FFFFFF;}
 
.leftColumn {  border: 0; padding: 0px;}
 
.rightColumn { border: 0; padding: 0px;}

h1 { font-family: Arial, sans-serif; font-size:2.4em; color: #2C5463;margin:6px 10px 6px 10px;}
h2 { font-family: Arial, sans-serif; font-size:2.2em; color: #FF8000;margin:6px 10px 8px 10px;}
body {font-size:1.0em;}

#header_container {max-width: 1000px;}

body {
    font-size:100%;
	font-family: Arial;
	background: white;
	text-align: center;
	padding: 0;
}
#header_container {
    margin: 0px auto 0px auto;
	padding:0px;
    border: 0px;	
	background-color: #FFFFFF;
 }
#ad_text {
  font-family : "Arial",sans-serif;
  font-size : .7em;
  font-weight : normal;
  color: #898989;
 } 
.button {
  display : inline-block;
  cursor : pointer;
  
  border-style : solid;
  border-width : 1px;
  border-radius : 5px;
  padding : 4px 11px 4px 11px;
  box-shadow : 0 1px 4px rgba(0,0,0,.6);
  font-size : 20px;
  font-weight : normal;
  color : #fff;
  text-shadow : 0 1px 3px rgba(0,0,0,.4);
  font-family : "Arial",sans-serif;
  text-decoration : none;
  margin: 0px 0px 5px 10px;
}

button.blue,
.button.blue {
  border-color : #2C5463;
  background: #2C5463;
  background: -moz-linear-gradient(top, #2C5463 0%, #376B7F 100%);
  background: -webkit-gradient(linear, left top, left bottom, 
    color-stop(0%,#2C5463), color-stop(100%,#376B7F));
  background: -webkit-linear-gradient(top, #2C5463 0%,#376B7F 100%);
  background: -o-linear-gradient(top, #2C5463 0%,#376B7F 100%);
  background: -ms-linear-gradient(top, #2C5463 0%,#376B7F 100%);
  background: linear-gradient(top, #2C5463 0%,#376B7F 100%);
  filter: progid:DXImageTransform.Microsoft.gradient( 
    startColorstr='#2C5463', endColorstr='#376B7F',GradientType=0 );
}

#polltableid { 
	width: 300px;
	padding: 0px;
	background-color:#FFF;
	border-radius:10px;
	border: 4px solid #2C5463;
	box-shadow: 5px 5px 3px #888888;
	margin: 10px auto 10px auto;
	} 
#rightside {
    float:right;
	margin: 0 0 4px 10px;
	background-color: #FFFFFF;
    }	
#main_table {
	text-align:left;
	}
#footerid {
    font-size:0.9em;
    margin: 0px auto 0px auto;
    max-width:1000px;
}
#footer_search {
   border-radius:10px;
   border: 4px solid #EAA951;
   margin: 0px auto 0px auto;
   padding: 10px;
   background-color: #FFFFFF;
 }	
#footer_menu {
  width: 100%;
  border-radius:10px;
  border: 4px solid #2C5463;
  text-align:left;
  background-color: #FFFFFF;
 } 
#footer_menu td { 
  vertical-align:top;
  font-size:1.1em;
}

#footer_column1 {width:50%;position:relative;float:left;} 
#footer_column2 {width:50%;position:relative;float:left;}
#footer_column3 {width:50%;position:relative;float:left;}
#footer_column4 {width:50%;position:relative;float:left;}
}
.responsive-ad-test { width: 728px; height: 90px; }

#righttopblank {display:active; }

@media screen and (min-width: 1050px ) 
{
#righttopblank {display:none; }
}
 
@media screen and (min-width: 720px ) 
{

#header_container {max-width: 1000px; }
nav {height:37px;}
nav ul {font-size: 20px;}
nav ul li a {width:112px; height:30px;}

#main_table {max-width:1000px;}
#footer_search {max-width: 600px;}
#footerid {max-width: 1000px;background-color: #FFFFFF;} 

#search_header {
	padding: 4px;
    border-top-left-radius:10px;
    border-top-right-radius:10px;
	border-bottom-left-radius:10px;
    border-bottom-right-radius:10px;
	border: 4px solid #EAA951;
	width: 300px;
	margin: 0px 0px 0px 0px;
	position: relative; 
	float:right;
 }
.responsive-ad-test { width: 728px; height: 90px; }

.leftColumn { margin-right: 330px; min-height:1150px;background-color: #FFFFFF;padding-left: 10px;}
.rightColumn { position: absolute; top: 0; right: 0; width: 330px;background-color: #FFFFFF;}
  
#footer_column1 {width:25%;position:relative;float:left;} 
#footer_column2 {width:25%;position:relative;float:left;}
#footer_column3 {width:25%;position:relative;float:left;}
#footer_column4 {width:25%;position:relative;float:left;}  
 
#graphic1 {display:none; }
}
@media screen and (max-width: 728px ) 
{
#graphic {display:none; }
#graphic1 {display:inline; }
}

@media screen and (max-width: 655px ) 
{
#search_title {display:none; }
.responsive-ad-test { width: 600px; height: 70px; }
#righttopblank {display:none; }
}

@media screen and (max-width: 450px){
.responsive-ad-test { width: 319px; height: 60px; } 
#citation {display:none; }
}

@media screen and (-webkit-min-device-pixel-ratio: 2){
  /* iphone 4*/
  <meta name="viewport" content="initial-scale=1.0">
}
</style>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-714916-2', 'ducksters.com');
  ga('send', 'pageview');
  ga('set', 'anonymizeIp', true);
</script>
<script>
function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
</script>

<meta name="viewport" content="initial-scale=1.0">
 
</head>
<body bgcolor="#ffffff">
<div id="header_container">
<span id="graphic" style="position: relative;border: 0px;">
<a href="/"><img src="/graphics/ducksters_header_test3.gif" alt="" border="0"></a>
</span>
<span id="graphic1" style="position: relative;border: 0px;">
<a href="/"><img src="/graphics/ducksters_header_minimal3.gif" alt="" border="0"></a>
</span>

<span id="search_header">
<font color="#FF8000" size="5" ><b id="search_title"><font color="#2C5463">Search</font></b></font>
<form action="https://www.google.com" id="cse-search-box" target="_blank">
  <div>
    <input type="hidden" name="cx" value="partner-pub-1809268078385119:3620521284" />
    <input type="hidden" name="ie" value="UTF-8" />
    <input type="text" name="q" size="34" />
    <input type="submit" name="sa" value="Search" />
  </div>
</form>
<script type="text/javascript" src="https://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang="></script>
</span>
<BR>
<font size="+2"><a  class="button blue" href="/history/">History</a>
<a class="button blue" href="/biography/">Biography</a>
<a class="button blue" href="/geography/">Geography</a>
<a class="button blue" href="/science/">Science</a>
<a class="button blue" href="/games/">Games</a>
</font>
</div><div class="columnsContainer"><div class="leftColumn" align="left">

<div align="center"><h2>Privacy Policy</h2></div>
<BR><BR>
www.ducksters.com does not collect personally identifiable contact information such as names, addresses, and passwords on the website. www.ducksters.com does not send newsletters or conduct contests. 
<BR><BR>
<b>Regarding Email Addresses </b>
<BR><BR>
If you send us an email with personal information, we will not sell your email address to third parties or use it to send you a newsletter. If we receive an email we believe is from a child under the age of 13, we will delete the email after responding. 
<BR><BR>
<b>Parent Rights</b> 
<BR><BR>
Although we don't believe we collect any personal information on children, if a parent or guardian feels we have personal information regarding their child they may request that we delete the information at <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="cca1ada5a08ca8b9afa7bfb8a9bebfe2afa3a1e2">[email&#160;protected]</a> 
<BR><BR>
<b>Links to Other Sites </b>
<BR><BR>
Some content on www.ducksters.com may be hosted and served by third parties. Also, www.ducksters.com may contain links to third party web sites that www.ducksters.com does not control. We are not responsible for the privacy policies or the data collection practices of third party sites. 
<BR><BR>
<b>Privacy Policy Regarding Analytics </b>
<BR><BR>
www.ducksters.com currently uses a program called Google Analytics to track various website metrics such as the number of visitors, browser type, operating system, visitor location, the number of pages each visitor views, etc. A cookie may be placed on your computer to help track this information. This information cannot be used to determine the identity of the user. These statistics are used as support for internal operations and to track the overall health of the website.  You can view the Google privacy policy at "https://policies.google.com/privacy"
You can opt out of Google Analytics for all websites  at "https://support.google.com/analytics/answer/181881?hl=en".
<BR><BR>
<b>Advertising </b>
<BR><BR>
www.ducksters.com works with network advertisers to serve advertisements on www.ducksters.com. These advertising providers may set and access their own tracking technologies on your device (such as cookies and web beacons). They may also collect or have access to your device identifier and usage information. Your Device Identifier will be used only to support internal operations. www.ducksters.com may share Usage Information about visitors with third party vendors such as advertising networks and analytics providers for similar purposes. 
www.ducksters.com uses Playwire Kid's Club as its primary advertising partner. You can view Playwire's privacy policy at "https://www.playwire.com/privacy-policy/" .
<BR><BR>
<b>Adsense Search</b> 
<BR><BR>
www.ducksters.com currently uses the Google Adsense search engine as a search for our site. When you use the search engine you will be moved to another site (google.com) that will be subject to Google's own privacy policy (see above for link to the Google privacy policy). 
<BR><BR>
<b>Use of Cookies</b>
<ul>
    <li><b>Games Cookies:</b>  Some of the games on www.ducksters.com use cookies to track information regarding the specific game such as game level and high score. </li>
    <li><b>Analytics Cookies:</b>  www.ducksters.com uses Google Analytics as described above.  Cookies are used to track information such as the number of visitors, browser type, operating system, visitor location, the number of pages each visitor views, etc. You can opt out of Google Analytics for all websites at href="https://support.google.com/analytics/answer/181881?hl=en".</li>
    <li><b>Marketing Cookies:</b>  Our advertizing partner, Playwire, or its partners, may use cookies to track non-personal marketing data such as impression counting (how many times an ad is shown), frequency capping (to limit how many times an ad is shown), click counting (how many times an ad is clicked), and viewability (how long an ad is viewed by a user). </li>
    <li><b>Other/Necessary Cookies:</b>  Other cookies may be used for security or site functionality.  Ducksters uses Cloudflare (https://www.cloudflare.com/privacypolicy/) as a content distribution network.  Cloudflare may use cookies to maintain security, analyze traffic, or otherwise improve website performance.</li>
</ul> 

<b>Log Files</b>
<BR><BR>
Log files are maintained and analyzed of all requests for files on this website's web servers. Log files do not capture personal information but do capture the user's IP address, which is automatically recognized by our web servers.
<BR><BR>
Aggregated analysis of these log files may be used to monitor website usage. This data may be made available to the www.ducksters.com staff and partner agencies to allow them to measure statistics important to the business such as the overall popularity of the website.
<BR><BR>
Except as stated already, www.ducksters.com will make no attempt to identify individual users, except where there is a reasonable suspicion that unauthorized access to systems is being attempted. As a condition of use of this site, all users give permission for www.ducksters.com to use its access logs to attempt to track users who are reasonably suspected of gaining, or attempting to gain, unauthorized access.
<BR><BR>
<b>How We Use Information</b>
<BR><BR>
Information collected may be used as follows:

<ul>
    <li>To maintain, operate, improve, promote, and provide the Website and Services.</li>
    <li>To enable access and use of the Website and Services.</li>
    <li>To respond to comments, questions, support, requests, and other issues.</li>
    <li>To monitor and analyze trends, usage, and activities in connection with the Websites and Services and for marketing or advertising purposes.</li>
    <li>To comply with legal obligations as well as to investigate and prevent fraudulent transactions, unauthorized access to the Services, and other illegal activities.</li>
    <li>www.ducksters.com may aggregate data we acquire about our Customers and their End Users, including the Log Data described above. For example, we may assemble data to determine how Web crawlers index the Internet and whether they are engaged in malicious activity or to compile web traffic reports and statistics. Non-personally identifiable, aggregated data may be shared with third parties.</li>
</ul> 

<b>Locality</b>
<BR><BR>
Ducksters is wholly owned by Technological Solutions, Inc. (TSI). www.ducksters.com is located, marketed, published, designed, and intended for use in the United States.
<BR><BR>
<b>Updates </b>
<BR><BR>
Our Privacy Policy may change from time to time. Updates will be posted on this page.
<BR><BR>
<b>Contact Ducksters Regarding Privacy Policy Questions</b> 
<BR><BR>
If you have any questions or concerns regarding our privacy policy please contact us at <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="c5a8a4aca985a1b0a6aeb6b1a0b7b6eba6aaa8">[email&#160;protected]</a> or at: 
<BR><BR>
Technological Solutions, Inc. 4015 Sunridge Road Raleigh, NC 27613 
<BR><BR>
Last Updated: 8/21/18 

<BR><BR>
      <p dir="ltr"><font size="2">Back to </font><a 
      href="/"><strong><font 
      size=2>Ducksters</font></strong></a><font size="2"> Home Page</font></p></ TD>


<div align="center">This site is a product of TSI, Copyright 2018, All Rights Reserved. By using this site you agree to the Terms of Use.</div>       
</table>
  </tr>
    </td>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script></body>
</html>
