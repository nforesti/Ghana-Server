<!DOCTYPE HTML>
<html lang="en">
<head>
<meta name="keywords" content="geography,US,united,state,world,maps,flags,kids,fun,learn,study,educate,education,educational,school,history,language,geography">

<meta name="description" content="Kids learn about the geography of the United States including capital, flag, state bird, fun facts, history, state tree, timeline, and counties.">

<title>Geography for Kids: United States</title>

<script type="text/javascript">
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
  var tyche = {
                mode: 'tyche',
                config: '//config.playwire.com/1015702/v2/websites/62069/banner.json',
                isMobile: 'true'
            };
}
else
{
  var tyche = {
                mode: 'tyche',
                config: '//config.playwire.com/1015702/v2/websites/62069/banner.json',
            };
}
</script>
<script id="tyche" src="//cdn.intergi.com/hera/tyche.js" type="text/javascript"></script>

<style type="text/css">

@media screen{

*, *:before, *:after {
  -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
}
 
body { margin: 0; }

img {
  max-width: 100%; height: auto;
}

.columnsContainer { position: relative; margin: 0px; margin-left:auto; margin-right:auto; max-width:1070px;background-color: #FFFFFF;}

#graphic1 {display:none; }
h1 { font-family: 'Century Gothic', Calibri, Geneva, sans-serif; font-size:2.3em; color: #008040;margin:6px 10px 6px 10px;}
h2 { font-family: 'Century Gothic', Calibri, Geneva, sans-serif; font-size:2.2em; color: #004080;margin:6px 10px 8px 10px;}
body {font-size:1.0em;}

body {
    font-size:100%;
	font-family: Arial;
	background: #2A9BD6;
	text-align: center;
	padding: 0;
}

ul li a {display: inline-block; margin: 4px 4px 4px 4px;} 
li a {display: inline-block; margin: 4px 4px 4px 4px;} 
ul a {display: inline-block; margin: 4px 4px 4px 4px;} 
span a {display: inline-block; margin: 4px 4px 4px 4px;} 
table a {display: inline-block; margin: 4px 4px 4px 4px;} 

a.playwire_report_ad_link{
color: #898989 !important;
text-decoration: none;
}
.wrapper {
  width:100%;
  max-width:1070px;
  margin:0 auto;
  background:#FFFFFF;
  overflow:hidden;
}
.inner {
  -webkit-transform: translateZ(0);
  transform: translateZ(0);
 }
.sidebar-right {
  background:#FFFFF;
  width:100%;
  float:none;
  padding:.4em;
  margin:.4em 0 .4em;
}
.contentT {
  padding:.4em;
  width: 100%;
  padding-right:.5em;
  float:left;
}
.content {
  padding:.4em;
  width: 100%;
  min-height:1450px;
  padding-right:.5em;
  float:left;
}
#playwire_video {padding-top:3px;margin:auto;max-width:640px;}
#standard_image {
    clear:both;
    margin:auto;
    border-style: solid;
    border-color: #525252;
    border-width: 4px;
    display:inline-block;
    background-color: white;
    box-shadow: 5px 10px 5px #888888;
    padding:2px;
    margin-bottom:25px;
}
#standard_image_center {
    clear:both;
    margin:auto;
    border-style: solid;
    border-color: #525252;
    border-width: 4px;
    display:inline-block;
    background-color: white;
    box-shadow: 5px 10px 5px #888888;
    padding:2px;
    margin-bottom:25px;
}
#header_container {
    max-width: 1070px;
    margin: 0px auto 0px auto;
	background-color: #FFFFFF;
	padding:10px 10px 0px 10px;
	position:relative;
	border:8px;
	border-color:#008000;
	border-style:solid;
	border-radius:20px; 
 }
#ad_text {
  font-family : "Arial",sans-serif;
  font-size : .9em;
  font-weight : normal;
  color: #898989;
 }
.radio-toolbar label {
    display:inline-block;
    background-color:#ddd;
    padding:4px 11px;
    font-family:Arial;
    font-size:16px;
}
.radio-toolbar input[type="radio"]:checked + label {
    background-color:#bbb;
}
.button {
  display : inline-block;
  cursor : pointer;
  border-radius : 5px;
  padding : 5px 11px 5px 11px;
  width: 112px;
  box-shadow : 0 1px 4px rgba(0,0,0,.6);
  font-size : 20px;
  font-weight : normal;
  color : #fff;
  text-shadow : 0 1px 3px rgba(0,0,0,.4);
  font-family : "Arial",sans-serif;
  text-decoration : none;
  margin: 0px 0px 10px 10px;
}
button.blue,
.button.blue {
  border-color : #0080C0;
  background: #0080C0;
}
button.green,
.button.green {
  border-color : #008000;
  background: #008000;
}
#rightsidebox1 { 
	width: 320px;
	padding: 0px;
	background-color:#FFF;
	border: 10px solid #004080;
	margin: 0px auto 10px auto;
	-webkit-transform: translateZ(0);
	transform: translateZ(0);
	}
#rightsidebox2 { 
	width: 320px;
	padding: 0px;
	background-color:#FFF;
	border: 10px solid #F48F0C;
	margin: 0px auto 10px auto;
	-webkit-transform: translateZ(0);
	transform: translateZ(0);
	} 		
#rightside {
    float:right;
	margin: 0 0 0px 0px;
	background-color: #FFFFFF;
    }	
#main_table {
	text-align:left;
	}
#footerid {
    font-size:0.9em;
    margin: 0px auto 0px auto;
    max-width:1070px;
}
#footer_search {
	border: 10px solid #F48F0C;
	margin: 10px auto 10px auto;
   padding: 20px;
   background-color: #FFFFFF;
 }	
#footer_menu {
  width: 100%;
  border: 10px solid #008000;
  text-align:left;
  background-color: #FFFFFF;
 } 
#footer_menu td { 
  vertical-align:top;
  font-size:1.1em;
}

#footer_column1 {width:50%;position:relative;float:left;} 
#footer_column2 {width:50%;position:relative;float:left;}
#footer_column3 {width:50%;position:relative;float:left;}
#footer_column4 {width:50%;position:relative;float:left;}

#whatsnewfont {
font-family: 'Comic Sans MS'; font-weight: bold; font-style: normal; text-decoration: none; font-size: 24pt; color: #008080}
#whatsnewlink  { 
font-family: 'Century Gothic', Calibri, Geneva, sans-serif; font-weight:bold; text-decoration: none; font-size: 24pt; color: #008000;}
} 

@media screen and (min-width: 550px){


#standard_image {
    float:right;
	margin: 25px 25px;
}
  
#main_table {max-width:1070px;}
#footer_search {max-width: 600px;}
#footerid {max-width: 1070px;background-color: #FFFFFF;}
#graphic1 {display:none; }

.wrapper {
  width:100%;
  max-width:1070px;
  margin:0 auto;
  background:#FFFFFF;
  overflow:hidden;
  border:5px;border-color:#008040;border-style:solid;
}

.sidebar-right {
  background:#FFFFF;
  width:31%;
  float:left;
  padding:.1em;
  margin:.1em 0 .1em;
}
.contentT {
  padding:.4em;
  width: 67%;
  padding-right:.5em;
  float:left;
}
.content {
  padding:.4em;
  width: 69%;
  min-height:1450px;
  padding-right:.5em;
  float:left;
}

.content_mobile {
  padding:.4em;
  width: 100%;
  padding-right:.5em;
  float:left;
}

.leftColumntop {margin-right: 450px; background-color: #2A9BD6;padding-left: 10px;padding-right:10px}
.rightColumntop {position: absolute; top: 0; right: 0; width: 450px;background-color: #2A9BD6;padding-right:10px}

.leftColumn1 {margin-right: 0px; background-color: #FFFFFF;padding-left: 10px;padding-right:10px}
.rightColumn1 { position: absolute; top: 0px; right: 8px; width: 320px;background-color: #FFFFFF;padding:15px 10px 0px 10px}

.leftColumn {margin-right: 343px; min-height:1450px;background-color: #FFFFFF;padding-left: 10px;padding-right:8px}
.rightColumn {position: absolute; top: 10px; right: 0; width: 343px;background-color: #FFFFFF;padding-right:5px;}

#footer_column1 {width:25%;position:relative;float:left;} 
#footer_column2 {width:25%;position:relative;float:left;}
#footer_column3 {width:25%;position:relative;float:left;}
#footer_column4 {width:25%;position:relative;float:left;}
}

@media screen and (max-width: 655px) 
{
#graphic1 {display:none; }
.leftColumntop {display:none; }
.rightColumntop {display:none; }

#adspace {display:none; }

.button {
  border-radius : 2px;
  padding : 4px 4px 4px 4px;
  width: auto;
  font-size : 20px;
  font-weight : normal;
  margin: 0px 0px 5px 5px;
}

}

@media screen and (max-width: 470px){
#graphic {display:none; }
#graphic1 {display:inline; }
}

@media screen and (max-width: 400px){
#graphic {display:none; }
#graphic1 {display:inline; }
#rightsidebox1 { 
	width: 308px;
	border: 4px solid #004080;
	}
#rightsidebox2 { 
	width: 308px;
	border: 4px solid #F48F0C;
	}
#header_container {
    max-width: 1070px;
    margin: 0px auto 0px auto;
	background-color: #FFFFFF;
	padding:0px 0px 2px 0px;
	position:relative;
	border:4px;
	border-color:#008000;
	border-style:solid;
	border-radius:10px; 
 }	
}

@media screen and (-webkit-min-device-pixel-ratio: 2){
  /* iphone 4*/
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
}
</style>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-714916-2', 'ducksters.com');
  ga('send', 'pageview');
  ga('set', 'anonymizeIp', true);
</script>

<script type="text/javascript" src="/jquery-1.10.1.min.js"></script>
<script type="text/javascript" src="/jquery.sticky-kit.js"></script>
<script type="text/javascript" src="/sticky4.js"></script>

<link rel="shortcut icon" href="/favico2.png"> 
<link rel="apple-touch-icon" href="/favico2.png">
<link rel="icon" href="/favico2.png" sizes="16x16" type="image/png">


<meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body bgcolor="#ffffff">

<div class="columnsContainer" style="background-color:#2A9BD6;">
<div class="leftColumntop" align="left">
<font size="-1"><i>Parents and Teachers</i>: Support Ducksters by following us on <a href="https://www.facebook.com/pages/Ducksters/103074613109209"><img src="/facebook_24.png" width="24" height="24" alt="Ducksters Facebook" title="" /></a> or <a href="https://www.twitter.com/DuckstersKids"><img src="/twitter_24.png" width="24" height="24" alt="Ducksters Twitter" title="" /></a>.</font>
</div>

<div class="rightColumntop">
<form action="https://www.google.com" id="cse-search-box" target="_blank">
  <div>
    <input type="hidden" name="cx" value="partner-pub-1809268078385119:3620521284" />
    <input type="hidden" name="ie" value="UTF-8" />
    <input type="text" name="q" size="40" />
    <input type="submit" name="sa" value="Search" />
  </div>
</form>
<script type="text/javascript" src="https://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang="></script>
</div>
</div>
<div id="header_container">
<div class="leftColumn1" align="center">
<span id="graphic" style="position: relative;border: 0px;">
<a href="/"><img src="/graphics/ducksters_new_header_shrunk2.gif" width="700" height="200" alt="Ducksters Educational Site" title="" /></a></span><span id="graphic1" style="position: relative;border: 0px;"><a href="/"><img src="/graphics/ducksters_mobile_4.gif" alt="Ducksters Educational Site" border="0"></a>
</span>
<div align="center"><font size="+2">
<a  class="button green" href="/history/">History</a>
<a class="button green" href="/biography/">Biography</a>
<a class="button green" href="/geography/">Geography</a>
<a class="button green" href="/science/">Science</a>
<a class="button green" href="/games/">Games</a>
</font></div></div></div>
<BR id="adspace">
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
}
else
{
document.write("<div align='center'><div data-pw-desk='leaderboard_atf'></div><div data-pw-mobi='leaderboard_atf'></div>"); 
}
</script>
<div class="wrapper">
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
document.write("<div class='content_mobile' align='left'>");
if ($(window).width() < 600) {
document.write("<div align='center'>");
document.write("<div data-pw-mobi='leaderboard_atf'></div><div data-pw-desk='leaderboard_atf'></div>");   
}
else {
document.write("<div style='float:right;'>");   
document.write("<div data-pw-mobi='med_rect_atf'></div><div data-pw-desk='med_rect_atf'></div>"); 
} 
}
else
{
document.write("<div class='content' align='left'><div align='center'>");
}
</script></div>



      
      <table cellspacing="0" cellpadding="3" width="99%" align="center" border="0">
        
        <tr>
          <td>
            <h1><div align="center">United States Geography 
            </div></h1>
          <td>
      <p align="center"><img src="flagmaps/us-flag.gif" width="103" height="54" alt="United States Flag" border="0" align=""></p></td></tr></table></p> 
      </strong><BR>

	<table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" id="backyard" summary="layout table">
  <tr>
    <td>
	

		<div>
	          <div align="center">
			  <img src="us_relief.gif" alt="Select the US State" title="Map of US States" width="274" height="182" border="0" usemap="#us_map" />
			<br />
			<br />
          </div>
          <map name="us_map">
  <area shape="poly" coords="13,43,29,49,28,64,48,90,43,107,34,108,19,92,14,73,10,53" href="/geography/state.php?State=California" alt="California" title="California">
  <area shape="poly" coords="76,134,89,141,93,162,109,175,100,179,88,167,75,172,48,178,21,170,21,153,43,171,54,166,54,152,57,145,64,138" href="/geography/state.php?State=Alaska" alt="Alaska" title="Alaska">
  <area shape="poly" coords="208,77,216,83,222,80,227,71,217,70" href="/geography/state.php?State=West%20Virginia" alt="West Virginia" title="West Virginia">
  <area shape="poly" coords="60,9,107,14,107,36,67,35,62,18" href="/geography/state.php?State=Montana" alt="Montana" title="Montana">
  <area shape="poly" coords="185,104,195,104,200,126,187,131" href="/geography/state.php?State=Alabama" alt="Alabama" title="Alabama">
  <area shape="poly" coords="138,17,167,22,158,29,156,37,155,42,163,49,140,49" href="/geography/state.php?State=Minnesota" alt="Minnesota" title="Minnesota">
  <area shape="rect" coords="255,55,267,63" href="/geography/state.php?State=Connecticut" alt="Connecticut" title="Connecticut">
  <area shape="rect" coords="246,72,261,79" href="/geography/state.php?State=Delaware" alt="Delaware" title="Delaware">
  <area shape="rect" coords="250,82,263,89" href="/geography/state.php?State=District%20of%20Columbia" alt="District of Columbia" title="District of Columbia">
  <area shape="poly" coords="215,56,218,69,242,63,237,51" href="/geography/state.php?State=Pennsylvania" alt="Pennsylvania" title="Pennsylvania">
  <area shape="poly" coords="54,85,77,88,71,122,63,120,45,111" href="/geography/state.php?State=Arizona" alt="Arizona" title="Arizona">
  <area shape="poly" coords="11,122,18,127,10,139,30,142,42,139,46,136,38,128,15,115" href="/geography/state.php?State=Hawaii" alt="Hawaii" title="Hawaii">
  <area shape="poly" coords="230,162,235,152,223,129,193,130,210,134,219,150" href="/geography/state.php?State=Florida" alt="Florida" title="Florida">
  <area shape="poly" coords="220,53,224,44,235,44,234,34,244,31,249,51,244,52,238,47" href="/geography/state.php?State=New%20York" alt="New York" title="New York">
  <area shape="rect" coords="240,14,253,21" href="/geography/state.php?State=New%20Hampshire" alt="New Hampshire" title="New Hampshire">
  <area shape="poly" coords="173,106,184,104,185,132,178,133,169,125" href="/geography/state.php?State=Mississippi" alt="Mississippi" title="Mississippi">
  <area shape="poly" coords="209,89,243,85,237,73,231,71,225,81" href="/geography/state.php?State=Virginia" alt="Virginia" title="Virginia">
  <area shape="poly" coords="24,3,22,16,42,27,51,26,57,19,59,9,36,4" href="/geography/state.php?State=Washington" alt="Washington" title="Washington">
  <area shape="poly" coords="83,64,79,86,109,90,113,67" href="/geography/state.php?State=Colorado" alt="Colorado" title="Colorado">
  <area shape="poly" coords="48,49,71,54,75,39,67,38,64,32,62,26,57,16" href="/geography/state.php?State=Idaho" alt="Idaho" title="Idaho">
  <area shape="rect" coords="250,90,265,98" href="/geography/state.php?State=Maryland" alt="Maryland" title="Maryland">
  <area shape="rect" coords="258,37,271,44" href="/geography/state.php?State=Massachusetts" alt="Massachusetts" title="Massachusetts">
  <area shape="poly" coords="109,34,137,35,138,53,106,51" href="/geography/state.php?State=South%20Dakota" alt="South Dakota" title="South Dakota">
  <area shape="poly" coords="147,94,150,111,125,108,126,95,111,92,112,91" href="/geography/state.php?State=Oklahoma" alt="Oklahoma" title="Oklahoma">
  <area shape="poly" coords="74,61,105,64,105,41,76,38" href="/geography/state.php?State=Wyoming" alt="Wyoming" title="Wyoming">
  <area shape="poly" coords="13,37,22,19,31,24,40,29,45,30,51,29,46,47,22,44" href="/geography/state.php?State=Oregon" alt="Oregon" title="Oregon">   
  <area shape="poly" coords="141,51,147,68,165,69,170,60,163,52" href="/geography/state.php?State=Iowa" alt="Iowa" title="Iowa">
  <area shape="poly" coords="109,16,109,32,136,32,136,17" href="/geography/state.php?State=North%20Dakota" alt="North Dakota" title="North Dakota">
  <area shape="poly" coords="167,26,195,27,206,51,202,57,190,58,188,47,185,41" href="/geography/state.php?State=Michigan" alt="Michigan" title="Michigan">
  <area shape="poly" coords="160,30,175,34,180,42,180,53,169,53,166,47,158,39" href="/geography/state.php?State=Wisconsin" alt="Wisconsin" title="Wisconsin">
  <area shape="rect" coords="251,63,262,70" href="/geography/state.php?State=New%20Jersey" alt="New Jersey" title="New Jersey">
  <area shape="poly" coords="198,59,214,58,216,69,207,77,200,76" href="/geography/state.php?State=Ohio" alt="Ohio" title="Ohio">
  <area shape="poly" coords="177,94,210,91,202,100,173,103" href="/geography/state.php?State=Tennessee" alt="Tennessee" title="Tennessee">
  <area shape="poly" coords="179,92,203,90,211,84,207,79,197,79,192,85,185,84" href="/geography/state.php?State=Kentucky" alt="Kentucky" title="Kentucky">
  <area shape="poly" coords="150,96,175,95,167,116,151,116" href="/geography/state.php?State=Arkansas" alt="Arkansas" title="Arkansas">
  <area shape="poly" coords="185,61,196,60,196,77,186,84" href="/geography/state.php?State=Indiana" alt="Indiana" title="Indiana">
  <area shape="rect" coords="231,21,243,29" href="/geography/state.php?State=Vermont" alt="Vermont" title="Vermont">
  <area shape="poly" coords="108,94,123,96,122,109,129,112,151,114,155,136,139,144,135,162,125,155,116,138,108,133,104,140,98,136,88,123,106,122" href="/geography/state.php?State=Texas" alt="Texas" title="Texas">
  <area shape="poly" coords="79,88,73,123,77,120,104,121,106,92" href="/geography/state.php?State=New%20Mexico" alt="New Mexico" title="New Mexico">
  <area shape="rect" coords="162,152,196,178" href="/geography/state.php?State=Puerto%20Rico" alt="Puerto Rico" title="Puerto Rico">
  <area shape="rect" coords="260,47,272,54" href="/geography/state.php?State=Rhode%20Island" alt="Rhode Island" title="Rhode Island">
  <area shape="poly" coords="31,48,30,64,49,87,53,80,57,54" href="/geography/state.php?State=Nevada" alt="Nevada" title="Nevada">
  <area shape="poly" coords="114,73,143,73,147,79,147,90,112,89" href="/geography/state.php?State=Kansas" alt="Kansas" title="Kansas">
  <area shape="poly" coords="107,53,107,62,115,63,116,70,145,72,141,56" href="/geography/state.php?State=Nebraska" alt="Nebraska" title="Nebraska">
  <area shape="poly" coords="197,103,204,127,219,127,222,117,209,103" href="/geography/state.php?State=Georgia" alt="Georgia" title="Georgia">
  <area shape="poly" coords="60,53,71,55,71,62,81,64,78,86,54,83" href="/geography/state.php?State=Utah" alt="Utah" title="Utah">
  <area shape="poly" coords="173,57,182,57,184,80,178,89,173,79,167,71" href="/geography/state.php?State=Illinois" alt="Illinois" title="Illinois">
  <area shape="rect" coords="197,152,212,176" href="/geography/state.php?State=Virgin%20Islands" alt="U.S. Virgin Islands" title="U.S. Virgin Islands">
  <area shape="poly" coords="148,71,152,79,151,94,176,94,171,79,164,70" href="/geography/state.php?State=Missouri" alt="Missouri" title="Missouri">
  <area shape="poly" coords="259,9,264,10,271,22,259,37,258,33,255,24" href="/geography/state.php?State=Maine" alt="Maine" title="Maine">
  <area shape="poly" coords="154,117,168,118,165,129,174,130,181,142,157,136" href="/geography/state.php?State=Louisiana" alt="Louisiana" title="Louisiana">
  <area shape="poly" coords="203,101,214,90,241,87,245,91,236,101,228,97" href="/geography/state.php?State=North%20Carolina" alt="North Carolina" title="North Carolina">
  <area shape="poly" coords="213,102,225,115,233,105,226,100" href="/geography/state.php?State=South%20Carolina" alt="South Carolina" title="South Carolina">
</map><div align="center">Click on the state in the map above to get more information or select state or territory below.</div>
	  </div>
	</td>
  </tr>
</table>
<BR><BR>
<div align="center"><script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
document.write("<div data-pw-desk='med_rect_btf'></div>");
document.write("<div data-pw-mobi='med_rect_btf'></div>");
}
</script></div><b>For state symbols, flag, maps, geography, and fun facts:</b>
<BR><BR>
<table border="0"  width="99%">
  <tr><!-- Row 1 -->
     <td>
<a href="/geography/state.php?State=Alabama" title="Study Info for the State of Alabama">Alabama</a><BR>
<a href="/geography/state.php?State=Alaska" title="Study Info for the State of Alaska">Alaska</a><BR>
<a href="/geography/state.php?State=Arizona" title="Study Info for the State of Arizona">Arizona</a><BR>
<a href="/geography/state.php?State=Arkansas" title="Study Info for the State of Arkansas">Arkansas</a><BR>
<a href="/geography/state.php?State=California" title="Study Info for the State of California">California</a><BR>
<a href="/geography/state.php?State=Colorado" title="Study Info for the State of Colorado">Colorado</a><BR>
<a href="/geography/state.php?State=Connecticut" title="Study Info for the State of Connecticut">Connecticut</a><BR>
<a href="/geography/state.php?State=Delaware" title="Study Info for the State of Delaware">Delaware</a><BR>
<a href="/geography/state.php?State=District%20of%20Columbia" title="Study Info for the State of District of Columbia">District of Columbia</a><BR>
<a href="/geography/state.php?State=Florida" title="Study Info for the State of Florida">Florida</a><BR>
<a href="/geography/state.php?State=Georgia" title="Study Info for the State of Georgia">Georgia</a><BR>
</td>
<td>
<a href="/geography/state.php?State=Hawaii" title="Study Info for the State of Hawaii">Hawaii</a><BR>
<a href="/geography/state.php?State=Idaho" title="Study Info for the State of Idaho">Idaho</a><BR>
<a href="/geography/state.php?State=Illinois" title="Study Info for the State of Illinois">Illinois</a><BR>
<a href="/geography/state.php?State=Indiana" title="Study Info for the State of Indiana">Indiana</a><BR>
<a href="/geography/state.php?State=Iowa" title="Study Info for the State of Iowa">Iowa</a><BR>
<a href="/geography/state.php?State=Kansas" title="Study Info for the State of Kansas">Kansas</a><BR>
<a href="/geography/state.php?State=Kentucky" title="Study Info for the State of Kentucky">Kentucky</a><BR>
<a href="/geography/state.php?State=Louisiana" title="Study Info for the State of Louisiana">Louisiana</a><BR>
<a href="/geography/state.php?State=Maine" title="Study Info for the State of Maine">Maine</a><BR>
<a href="/geography/state.php?State=Maryland" title="Study Info for the State of Maryland">Maryland</a><BR>
<a href="/geography/state.php?State=Massachusetts" title="Study Info for the State of Massachusetts">Massachusetts</a><BR>
</td>
<td>
<a href="/geography/state.php?State=Michigan" title="Study Info for the State of Michigan">Michigan</a><BR>
<a href="/geography/state.php?State=Minnesota" title="Study Info for the State of Minnesota">Minnesota</a><BR>
<a href="/geography/state.php?State=Mississippi" title="Study Info for the State of Mississippi">Mississippi</a><BR>
<a href="/geography/state.php?State=Missouri" title="Study Info for the State of Missouri">Missouri</a><BR>
<a href="/geography/state.php?State=Montana" title="Study Info for the State of Montana">Montana</a><BR>
<a href="/geography/state.php?State=Nebraska" title="Study Info for the State of Nebraska">Nebraska</a><BR>
<a href="/geography/state.php?State=Nevada" title="Study Info for the State of Nevada">Nevada</a><BR>
<a href="/geography/state.php?State=New%20Hampshire" title="Study Info for the State of New Hampshire">New Hampshire</a><BR>
<a href="/geography/state.php?State=New%20Jersey" title="Study Info for the State of New Jersey">New Jersey</a><BR>
<a href="/geography/state.php?State=New%20Mexico" title="Study Info for the State of New Mexico">New Mexico</a><BR>
<a href="/geography/state.php?State=New%20York" title="Study Info for the State of New York">New York</a><BR>
</td>
<td>
<a href="/geography/state.php?State=North%20Carolina" title="Study Info for the State of North Carolina">North Carolina</a><BR>
<a href="/geography/state.php?State=North%20Dakota" title="Study Info for the State of North Dakota">North Dakota</a><BR>
<a href="/geography/state.php?State=Ohio" title="Study Info for the State of Ohio">Ohio</a><BR>
<a href="/geography/state.php?State=Oklahoma" title="Study Info for the State of Oklahoma">Oklahoma</a><BR>
<a href="/geography/state.php?State=Oregon" title="Study Info for the State of Oregon">Oregon</a><BR>
<a href="/geography/state.php?State=Pennsylvania" title="Study Info for the State of Pennsylvania">Pennsylvania</a><BR>
<a href="/geography/state.php?State=Puerto%20Rico" title="Study Info for the State of Puerto Rico">Puerto Rico</a><BR>
<a href="/geography/state.php?State=Rhode%20Island" title="Study Info for the State of Rhode Island">Rhode Island</a><BR>
<a href="/geography/state.php?State=South%20Carolina" title="Study Info for the State of South Carolina">South Carolina</a><BR>
<a href="/geography/state.php?State=South%20Dakota" title="Study Info for the State of ASouth Dakota">South Dakota</a><BR>
<a href="/geography/state.php?State=Tennessee" title="Study Info for the State of Tennessee">Tennessee</a><BR>
</td>
<td valign="top">
<a href="/geography/state.php?State=Texas" title="Study Info for the State of Texas">Texas</a><BR>
<a href="/geography/state.php?State=Utah" title="Study Info for the State of Utah">Utah</a><BR>
<a href="/geography/state.php?State=Vermont" title="Study Info for the State of Vermont">Vermont</a><BR>
<a href="/geography/state.php?State=Virgin%20Islands" title="Study Info for the State of Virgin Islands">Virgin Islands</a><BR>
<a href="/geography/state.php?State=Virginia" title="Study Info for the State of Virginia">Virginia</a><BR>
<a href="/geography/state.php?State=Washington" title="Study Info for the State of Washington">Washington</a><BR>
<a href="/geography/state.php?State=West%20Virginia" title="Study Info for the State of West Virginia">West Virginia</a><BR>
<a href="/geography/state.php?State=Wisconsin" title="Study Info for the State of Wisconsin">Wisconsin</a><BR>
<a href="/geography/state.php?State=Wyoming" title="Study Info for the State of Wyoming">Wyoming</a><BR>
</td><!-- Col 3 -->
  </tr>
</table>
<BR><BR>
<b>United States Maps</b>
<BR><BR>
<div align="center">Click on the maps below to see a larger view</div>
<BR><BR>
<table border="0"  width="99%">
  <tr><!-- Row 1 -->
     <td>
<div align="center"><a href="https://www.ilibrarian.net/flagmaps/us_states_colors_map_lg.jpg"><img src="us_states/us_states_colors_map_sm.JPG" width="244" height="165" alt="" border="0" align=""></a>
<BR>States colored</div><BR>
	 </td><!-- Col 1 -->
     <td>
<div align="center"><a href="https://www.ilibrarian.net/flagmaps/us_states_capitals_map_lg.jpg"><img src="us_states/us_states_capitals_map_sm.JPG" width="241" height="165" alt="" border="0" align=""></a>	
<BR>States and capitals</div><BR>
	 </td><!-- Col 2 -->
  </tr>
  <tr><!-- Row 2 -->
     <td>
<div align="center"><a href="https://www.ilibrarian.net/flagmaps/us_states_map_regions_lg.jpg"><img src="us_states/us_states_map_regions_vsm.jpg" width="245" height="164" alt="" border="0" align=""></a>	 
<BR>Regions of the US</div><BR>
	 </td><!-- Col 1 -->
     <td>
<div align="center"><a href="https://www.ilibrarian.net/flagmaps/rivers_us_map_lg.jpg"><img src="us_states/rivers_us_map_vsm.jpg" width="246" height="166" alt="" border="0" align=""></a>	 
<BR>Major Rivers</div><BR>
	 </td><!-- Col 2 -->
  </tr>
  <tr><!-- Row 3 -->
     <td>
<div align="center"><a href="https://www.ilibrarian.net/flagmaps/deserts_us_states_map_lg.jpg"><img src="us_states/deserts_us_states_map_vsm.jpg" width="248" height="173" alt="" border="0" align=""></a>	 
<BR>Major Deserts</div><BR>
	 </td><!-- Col 1 -->
     <td>
<div align="center"><a href="https://www.ilibrarian.net/flagmaps/mountain_range_us_map_lg.jpg"><img src="us_states/mountain_range_us_map_vsm.jpg" width="245" height="164" alt="" border="0" align=""></a>	 
<BR>Mountain Ranges</div><BR>
	 </td><!-- Col 2 -->
  </tr>
</table>
<div align="center"><script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
document.write("<div data-pw-desk='med_rect_btf'></div>");
document.write("<div data-pw-mobi='med_rect_btf'></div>");
}
</script></div><b>Geographical Features of the United States:</b>
<BR><BR>
<span><a href="/geography/us_states/us_geographical_regions.php">Regions of the United States</a><BR>
<a href="/geography/us_states/us_rivers.php">US Rivers</a><BR>
<a href="/geography/us_states/us_lakes.php">US Lakes</a><BR>
<a href="/geography/us_states/us_mountain_ranges.php">US Mountain Ranges</a><BR>
<a href="/geography/us_states/us_deserts.php">US Deserts</a></span>

<BR><BR>
<b>For US state history:</b>
<BR><BR>
<table border="0"  width="99%">
  <tr><!-- Row 1 -->
     <td>
<a href="/geography/us_states/alabama_history.php">Alabama</a><BR>
<a href="/geography/us_states/alaska_history.php">Alaska</a><BR>
<a href="/geography/us_states/arizona_history.php">Arizona</a><BR>
<a href="/geography/us_states/arkansas_history.php">Arkansas</a><BR>
<a href="/geography/us_states/california_history.php">California</a><BR>
<a href="/geography/us_states/colorado_history.php">Colorado</a><BR>
<a href="/geography/us_states/connecticut_history.php">Connecticut</a><BR>
<a href="/geography/us_states/delaware_history.php">Delaware</a><BR>
<a href="/geography/us_states/florida_history.php">Florida</a><BR>
<a href="/geography/us_states/georgia_history.php">Georgia</a><BR>
	 
	 </td><!-- Col 1 -->
     <td>
<a href="/geography/us_states/hawaii_history.php">Hawaii</a><BR>
<a href="/geography/us_states/idaho_history.php">Idaho</a><BR>
<a href="/geography/us_states/illinois_history.php">Illinois</a><BR>
<a href="/geography/us_states/indiana_history.php">Indiana</a><BR>
<a href="/geography/us_states/iowa_history.php">Iowa</a><BR>
<a href="/geography/us_states/kansas_history.php">Kansas</a><BR>
<a href="/geography/us_states/kentucky_history.php">Kentucky</a><BR>
<a href="/geography/us_states/louisiana_history.php">Louisiana</a><BR>
<a href="/geography/us_states/maine_history.php">Maine</a><BR>
<a href="/geography/us_states/maryland_history.php">Maryland</a><BR>
	 
	 </td><!-- Col 2 -->
     <td>
<a href="/geography/us_states/massachusetts_history.php">Massachusetts</a><BR>
<a href="/geography/us_states/michigan_history.php">Michigan</a><BR>
<a href="/geography/us_states/minnesota_history.php">Minnesota</a><BR>
<a href="/geography/us_states/mississippi_history.php">Mississippi</a><BR>
<a href="/geography/us_states/missouri_history.php">Missouri</a><BR>
<a href="/geography/us_states/montana_history.php">Montana</a><BR>
<a href="/geography/us_states/nebraska_history.php">Nebraska</a><BR>
<a href="/geography/us_states/nevada_history.php">Nevada</a><BR>
<a href="/geography/us_states/new_hampshire_history.php">New Hampshire</a><BR>
<a href="/geography/us_states/new_jersey_history.php">New Jersey</a><BR>
	 
	 </td><!-- Col 3 -->
     <td>
<a href="/geography/us_states/new_mexico_history.php">New Mexico</a><BR>
<a href="/geography/us_states/new_york_history.php">New York</a><BR>
<a href="/geography/us_states/north_carolina_history.php">North Carolina</a><BR>
<a href="/geography/us_states/north_dakota_history.php">North Dakota</a><BR>
<a href="/geography/us_states/ohio_history.php">Ohio</a><BR>
<a href="/geography/us_states/oklahoma_history.php">Oklahoma</a><BR>
<a href="/geography/us_states/oregon_history.php">Oregon</a><BR>
<a href="/geography/us_states/pennsylvania_history.php">Pennsylvania</a><BR>
<a href="/geography/us_states/rhode_island_history.php">Rhode Island</a><BR>
<a href="/geography/us_states/south_carolina_history.php">South Carolina</a>	 <BR>
	 </td><!-- Col 4 -->
     <td>
<a href="/geography/us_states/south_dakota_history.php">South Dakota</a><BR>
<a href="/geography/us_states/tennessee_history.php">Tennessee</a><BR>
<a href="/geography/us_states/texas_history.php">Texas</a><BR>
<a href="/geography/us_states/utah_history.php">Utah</a><BR>
<a href="/geography/us_states/vermont_history.php">Vermont</a><BR>
<a href="/geography/us_states/virginia_history.php">Virginia</a><BR>
<a href="/geography/us_states/washington_history.php">Washington</a><BR>
<a href="/geography/us_states/west_virginia_history.php">West Virginia</a><BR>
<a href="/geography/us_states/wisconsin_history.php">Wisconsin</a><BR>
<a href="/geography/us_states/wyoming_history.php">Wyoming</a>	<BR> 
	 </td><!-- Col 4 -->	 
  </tr>
</table>
<BR><BR>
<b>US Geography Games</b>
<BR><BR>
<span><a href="/games/united_states_map_game.php">United States Map Game</a><BR>
<a href="/games/united_states_capitals_map_game.php">US State Capitals</a><BR>
<a href="/games/united_states_flags_map_game.php">US State Flags</a><BR>
<a href="/games/crossword_puzzle/united_states_geography.php">United States Crossword</a><BR>
<a href="/games/word_search/us_geography.php">United States Word Search</a></span>
<BR><BR>
Go here to learn more about the country of the <a href="/geography/country/united_states.php">United States</a>.
<BR><BR>
Back to <a href="/geography/">Geography</a></ TD>
      
</div>
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
}
else
{

document.write("<div class='sidebar-right' id='sidebar'><div class='inner'><span id='ad_text'>Advertisement</span><div align='center' id='rightsidebox1'>");
document.write("<div data-pw-desk='med_rect_atf'></div>");
document.write("<div data-pw-mobi='med_rect_atf'></div>");
document.write("</div><table  id='rightsidebox2'><tr><td>");

var value=Math.floor((Math.random()*4)+1);
if (value==1)
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>Vote for your favorite US President:</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpoll.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>George Washington<br><input name='answer' type='radio' value='two'>John Adams<br><input name='answer' type='radio' value='three'>Thomas Jefferson<br><input name='answer' type='radio' value='four'>Abraham Lincoln<br><input name='answer'type='radio' value='five'>Franklin D. Roosevelt<br></font>");
}
else if (value==2)
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>Which superpower would you want if you were a Superhero?</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpollsuperpower.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>Super Strength<br><input name='answer' type='radio' value='two'>Flying<br><input name='answer' type='radio' value='three'>Super Speed<br><input name='answer' type='radio' value='four'>Invisibility<br><input name='answer'type='radio' value='five'>Super Stretch<br></font>");
}
else if (value==3)
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>Vote for your favorite explorer:</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpollexplorers.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>Captain James Cook<br><input name='answer' type='radio' value='two'>Neil Armstrong<br><input name='answer' type='radio' value='three'>Christopher Columbus<br><input name='answer' type='radio' value='four'>Ferdinand Magellan<br><input name='answer'type='radio' value='five'>Marco Polo<br></font>");
}
else
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>What is your best subject at school?</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpollschoolsubject.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>Math<br><input name='answer' type='radio' value='two'>Reading<br><input name='answer' type='radio' value='three'>Writing<br><input name='answer' type='radio' value='four'>Science<br><input name='answer'type='radio' value='five'>History<br></font>");
}
document.write("</div></td><td><input name='psubmit' type='submit' value='Vote' class='button blue'></form><BR><BR><a href='/takekidspolls1.php'><font size='-1'>More polls</font></a></td></tr></table></td></tr></table>");
}
</script>
</div>
</div>
</div>

<div id="footerid">
<div align="center">
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
document.write("<div data-pw-desk='leaderboard_btf'></div><div data-pw-mobi='leaderboard_btf'></div>");
}
else
{
document.write("<div data-pw-desk='leaderboard_btf'></div><div data-pw-mobi='leaderboard_btf'></div>");
}
</script>
</div>
<BR><BR>
<div id="footer_search">
<form action="https://www.google.com" id="cse-search-box">
  <div>
    <input type="hidden" name="cx" value="partner-pub-1809268078385119:5398998522" />
    <input type="hidden" name="ie" value="UTF-8" />
    <input type="text" name="q" size="36" />
    <input type="submit" name="sa" value="Search" />
  </div>
</form>
<script type="text/javascript" src="https://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en"></script>
</div>
<BR>
<table id="footer_menu"><tr><td> 
<span id="footer_column1">
	<a href="/study.php"><font color="#F48F0C">Homework</font></a><br>	
		<a href="/animals.php">Animals</a><br>
		<a href="/kidsmath/">Math</a><br>
	    <a href="/history/">History</a><br>	
		<a href="/biography/">Biography</a><br>
		<a href="/money/">Money and Finance</a><br> 
	<br>
			<font color="#F48F0C">Biography</font><br>	
		  <a href="/history/art/">Artists</a><br>
		  <a href="/history/civil_rights/">Civil Rights Leaders</a><br>
		  <a href="/biography/entrepreneurs/">Entrepreneurs</a><br>
		  <a href="/biography/explorers/">Explorers</a><br>
		  <a href="/biography/scientists/scientists_and_inventors.php">Inventors and Scientists</a><br>
		  <a href="/biography/women_leaders/">Women Leaders</a><br>
		  <a href="/biography/world_leaders/">World Leaders</a><br>
		  <a href="/biography/uspresidents/">US Presidents</a><br>
		  <br>
</span>	<span id="footer_column2"> 
          <a><font color="#F48F0C">US History</font></a><br>
		  <a href="/history/native_americans.php">Native Americans</a><BR>
		  <a href="/history/colonial_america/">Colonial America</a><br>
          <a href="/history/american_revolution.php">American Revolution</a><BR>
		  <a href="/history/us_1800s/industrial_revolution.php">Industrial Revolution</a><BR>  
          <a href="/history/civil_war.php">American Civil War</a><BR>
          <a href="/history/westward_expansion/">Westward Expansion</a><BR>
		  <a href="/history/us_1900s/great_depression.php">The Great Depression</a><BR>
		  <a href="/history/civil_rights/">Civil Rights Movement</a><BR>
		  <a href="/history/us_1800s/">Pre-1900s</a><BR>
          <a href="/history/us_1900s/">1900 to Present</a><BR>
		  <a href="/history/us_government.php">US Government</a><BR>
          <a href="/geography/us_states/">US State History</a><BR>	
		<br> 
		<a href="/science/"><font color="#F48F0C">Science</font></a><br>
        <a href="/science/biology/">Biology</a><br>
		<a href="/science/chemistry/">Chemistry</a><br>	
		<a href="/science/earth_science/">Earth Science</a><br>							
		<a href="/science/physics/">Physics</a><br>	
	<BR>	
</span>	<span id="footer_column3">  
          <a><font color="#F48F0C">World History</font></a><br>
		  <a href="/history/africa/">Ancient Africa</a><BR>						
          <a href="/history/china/ancient_china.php">Ancient China</a><br>
          <a href="/history/ancient_egypt.php">Ancient Egypt</a><br>
          <a href="/history/ancient_greece.php">Ancient Greece</a><br>
          <a href="/history/mesopotamia/ancient_mesopotamia.php">Ancient Mesopotamia</a><br>		  
          <a href="/history/ancient_rome.php">Ancient Rome</a><br>
          <a href="/history/middle_ages_timeline.php">Middle Ages</a><br>
          <a href="/history/islam/">Islamic Empire</a><BR>		  
          <a href="/history/renaissance.php">Renaissance</a><br>
          <a href="/history/aztec_maya_inca.php">Aztec, Maya, Inca</a><br>
		  <a href="/history/french_revolution/">French Revolution</a><br>
          <a href="/history/world_war_i/">World War 1</a><br>
          <a href="/history/world_war_ii/">World War 2</a><br>
          <a href="/history/cold_war/summary.php">Cold War</a><br>
          <a href="/history/art/">Art History</a><br>	
         <br>
	 
</span>	
<span id="footer_column4">
	 <a href="/geography/"><font color="#F48F0C">Geography</font></a><br>
					<a href="/geography/usgeography.php">United States</a><br>
					<a href="/geography/africa.php">Africa</a><br>
					<a href="/geography/asia.php">Asia</a><br>
					<a href="/geography/centralamerica.php">Central America</a><br>
					<a href="/geography/europe.php">Europe</a><br>
					<a href="/geography/middleeast.php">Middle East</a><br>
					<a href="/geography/northamerica.php">North America</a><br>
					<a href="/geography/oceania.php">Oceania</a><br>
					<a href="/geography/southamerica.php">South America</a><br>
					<a href="/geography/southeastasia.php">Southeast Asia</a><br>	 
<br>
     <a><font color="#F48F0C">Fun Stuff</font></a><br>	
		       <a href="/games/">Educational Games</a><br>
			   <a href="/holidays/kids_calendar.php">Holidays</a><BR>	
			   <a href="/jokes/">Jokes for Kids</a><br>	
			   <a href="/movies.php">Movies</a><br>	
			   <a href="/music.php">Music</a><br>  
			   <a href="/sports.php">Sports</a><br>	

</span> 
	 </td></tr>
<div align="center"><img src="/graphics/ducksters_footer_1.gif" width="745" height="101" alt="" title="" />	</div> 
	 </table>
<BR><BR>
<a href="/about.php">About Ducksters</a>&nbsp;<a href="/privacy_policy.php"><b><font color="#008000">Privacy Policy</b></a></font>&nbsp;
<script type="text/javascript">
var title_1 = document.title;
var location_1 = document.location.href;
document.write ("<a href='/citation.php?title=" + title_1 + "&location=" + location_1 + "'>Cite this Page</a>");
</script>&nbsp;
<BR><BR>
Follow us on <a href="https://www.facebook.com/pages/Ducksters/103074613109209"><img src="/facebook_24.png" width="24" height="24" alt="Ducksters Facebook" title="" /></a> or <a href="https://www.twitter.com/DuckstersKids"><img src="/twitter_24.png" width="24" height="24" alt="Ducksters Twitter" title="" /></a>
<BR><BR>
This site is a product of TSI (Technological Solutions, Inc.), Copyright 2019, All Rights Reserved.
By using this site you agree to the
<a href="/termsofuse.php">Terms of Use.</a>
<BR><BR>
<script type="text/javascript">
var title_1 = document.title;
var location_1 = document.location.href;
document.write ("<a href='/citation.php?title=" + title_1 + "&location=" + location_1 + "'>Cite this Page</a>");
</script>
<BR><BR>
</div>
</div>             

</body>
</html>
