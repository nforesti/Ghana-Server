<!DOCTYPE HTML>
<html lang="en">
<head>
<meta name="keywords" content="europe,country,countries,geography,world,state,world,maps,flags,kids,learn,study,educate,education,educational,school,subject,history,language">

<meta name="description" content="Kids learn about Europe and the countries of Europe. Facts such as geography, flags, maps, exports, natural resouces, and languages.">

<title>Geography for Kids: European countries flags, maps, industries, culture of Europe</title>

<script type="text/javascript">
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
  var tyche = {
                mode: 'tyche',
                config: '//config.playwire.com/1015702/v2/websites/62069/banner.json',
                isMobile: 'true'
            };
}
else
{
  var tyche = {
                mode: 'tyche',
                config: '//config.playwire.com/1015702/v2/websites/62069/banner.json',
            };
}
</script>
<script id="tyche" src="//cdn.intergi.com/hera/tyche.js" type="text/javascript"></script>

<style type="text/css">

@media screen{

*, *:before, *:after {
  -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
}
 
body { margin: 0; }

img {
  max-width: 100%; height: auto;
}

.columnsContainer { position: relative; margin: 0px; margin-left:auto; margin-right:auto; max-width:1070px;background-color: #FFFFFF;}

#graphic1 {display:none; }
h1 { font-family: 'Century Gothic', Calibri, Geneva, sans-serif; font-size:2.3em; color: #008040;margin:6px 10px 6px 10px;}
h2 { font-family: 'Century Gothic', Calibri, Geneva, sans-serif; font-size:2.2em; color: #004080;margin:6px 10px 8px 10px;}
body {font-size:1.0em;}

body {
    font-size:100%;
	font-family: Arial;
	background: #2A9BD6;
	text-align: center;
	padding: 0;
}

ul li a {display: inline-block; margin: 4px 4px 4px 4px;} 
li a {display: inline-block; margin: 4px 4px 4px 4px;} 
ul a {display: inline-block; margin: 4px 4px 4px 4px;} 
span a {display: inline-block; margin: 4px 4px 4px 4px;} 
table a {display: inline-block; margin: 4px 4px 4px 4px;} 

a.playwire_report_ad_link{
color: #898989 !important;
text-decoration: none;
}
.wrapper {
  width:100%;
  max-width:1070px;
  margin:0 auto;
  background:#FFFFFF;
  overflow:hidden;
}
.inner {
  -webkit-transform: translateZ(0);
  transform: translateZ(0);
 }
.sidebar-right {
  background:#FFFFF;
  width:100%;
  float:none;
  padding:.4em;
  margin:.4em 0 .4em;
}
.contentT {
  padding:.4em;
  width: 100%;
  padding-right:.5em;
  float:left;
}
.content {
  padding:.4em;
  width: 100%;
  min-height:1450px;
  padding-right:.5em;
  float:left;
}
#playwire_video {padding-top:3px;margin:auto;max-width:640px;}
#standard_image {
    clear:both;
    margin:auto;
    border-style: solid;
    border-color: #525252;
    border-width: 4px;
    display:inline-block;
    background-color: white;
    box-shadow: 5px 10px 5px #888888;
    padding:2px;
    margin-bottom:25px;
}
#standard_image_center {
    clear:both;
    margin:auto;
    border-style: solid;
    border-color: #525252;
    border-width: 4px;
    display:inline-block;
    background-color: white;
    box-shadow: 5px 10px 5px #888888;
    padding:2px;
    margin-bottom:25px;
}
#header_container {
    max-width: 1070px;
    margin: 0px auto 0px auto;
	background-color: #FFFFFF;
	padding:10px 10px 0px 10px;
	position:relative;
	border:8px;
	border-color:#008000;
	border-style:solid;
	border-radius:20px; 
 }
#ad_text {
  font-family : "Arial",sans-serif;
  font-size : .9em;
  font-weight : normal;
  color: #898989;
 }
.radio-toolbar label {
    display:inline-block;
    background-color:#ddd;
    padding:4px 11px;
    font-family:Arial;
    font-size:16px;
}
.radio-toolbar input[type="radio"]:checked + label {
    background-color:#bbb;
}
.button {
  display : inline-block;
  cursor : pointer;
  border-radius : 5px;
  padding : 5px 11px 5px 11px;
  width: 112px;
  box-shadow : 0 1px 4px rgba(0,0,0,.6);
  font-size : 20px;
  font-weight : normal;
  color : #fff;
  text-shadow : 0 1px 3px rgba(0,0,0,.4);
  font-family : "Arial",sans-serif;
  text-decoration : none;
  margin: 0px 0px 10px 10px;
}
button.blue,
.button.blue {
  border-color : #0080C0;
  background: #0080C0;
}
button.green,
.button.green {
  border-color : #008000;
  background: #008000;
}
#rightsidebox1 { 
	width: 320px;
	padding: 0px;
	background-color:#FFF;
	border: 10px solid #004080;
	margin: 0px auto 10px auto;
	-webkit-transform: translateZ(0);
	transform: translateZ(0);
	}
#rightsidebox2 { 
	width: 320px;
	padding: 0px;
	background-color:#FFF;
	border: 10px solid #F48F0C;
	margin: 0px auto 10px auto;
	-webkit-transform: translateZ(0);
	transform: translateZ(0);
	} 		
#rightside {
    float:right;
	margin: 0 0 0px 0px;
	background-color: #FFFFFF;
    }	
#main_table {
	text-align:left;
	}
#footerid {
    font-size:0.9em;
    margin: 0px auto 0px auto;
    max-width:1070px;
}
#footer_search {
	border: 10px solid #F48F0C;
	margin: 10px auto 10px auto;
   padding: 20px;
   background-color: #FFFFFF;
 }	
#footer_menu {
  width: 100%;
  border: 10px solid #008000;
  text-align:left;
  background-color: #FFFFFF;
 } 
#footer_menu td { 
  vertical-align:top;
  font-size:1.1em;
}

#footer_column1 {width:50%;position:relative;float:left;} 
#footer_column2 {width:50%;position:relative;float:left;}
#footer_column3 {width:50%;position:relative;float:left;}
#footer_column4 {width:50%;position:relative;float:left;}

#whatsnewfont {
font-family: 'Comic Sans MS'; font-weight: bold; font-style: normal; text-decoration: none; font-size: 24pt; color: #008080}
#whatsnewlink  { 
font-family: 'Century Gothic', Calibri, Geneva, sans-serif; font-weight:bold; text-decoration: none; font-size: 24pt; color: #008000;}
} 

@media screen and (min-width: 550px){


#standard_image {
    float:right;
	margin: 25px 25px;
}
  
#main_table {max-width:1070px;}
#footer_search {max-width: 600px;}
#footerid {max-width: 1070px;background-color: #FFFFFF;}
#graphic1 {display:none; }

.wrapper {
  width:100%;
  max-width:1070px;
  margin:0 auto;
  background:#FFFFFF;
  overflow:hidden;
  border:5px;border-color:#008040;border-style:solid;
}

.sidebar-right {
  background:#FFFFF;
  width:31%;
  float:left;
  padding:.1em;
  margin:.1em 0 .1em;
}
.contentT {
  padding:.4em;
  width: 67%;
  padding-right:.5em;
  float:left;
}
.content {
  padding:.4em;
  width: 69%;
  min-height:1450px;
  padding-right:.5em;
  float:left;
}

.content_mobile {
  padding:.4em;
  width: 100%;
  padding-right:.5em;
  float:left;
}

.leftColumntop {margin-right: 450px; background-color: #2A9BD6;padding-left: 10px;padding-right:10px}
.rightColumntop {position: absolute; top: 0; right: 0; width: 450px;background-color: #2A9BD6;padding-right:10px}

.leftColumn1 {margin-right: 0px; background-color: #FFFFFF;padding-left: 10px;padding-right:10px}
.rightColumn1 { position: absolute; top: 0px; right: 8px; width: 320px;background-color: #FFFFFF;padding:15px 10px 0px 10px}

.leftColumn {margin-right: 343px; min-height:1450px;background-color: #FFFFFF;padding-left: 10px;padding-right:8px}
.rightColumn {position: absolute; top: 10px; right: 0; width: 343px;background-color: #FFFFFF;padding-right:5px;}

#footer_column1 {width:25%;position:relative;float:left;} 
#footer_column2 {width:25%;position:relative;float:left;}
#footer_column3 {width:25%;position:relative;float:left;}
#footer_column4 {width:25%;position:relative;float:left;}
}

@media screen and (max-width: 655px) 
{
#graphic1 {display:none; }
.leftColumntop {display:none; }
.rightColumntop {display:none; }

#adspace {display:none; }

.button {
  border-radius : 2px;
  padding : 4px 4px 4px 4px;
  width: auto;
  font-size : 20px;
  font-weight : normal;
  margin: 0px 0px 5px 5px;
}

}

@media screen and (max-width: 470px){
#graphic {display:none; }
#graphic1 {display:inline; }
}

@media screen and (max-width: 400px){
#graphic {display:none; }
#graphic1 {display:inline; }
#rightsidebox1 { 
	width: 308px;
	border: 4px solid #004080;
	}
#rightsidebox2 { 
	width: 308px;
	border: 4px solid #F48F0C;
	}
#header_container {
    max-width: 1070px;
    margin: 0px auto 0px auto;
	background-color: #FFFFFF;
	padding:0px 0px 2px 0px;
	position:relative;
	border:4px;
	border-color:#008000;
	border-style:solid;
	border-radius:10px; 
 }	
}

@media screen and (-webkit-min-device-pixel-ratio: 2){
  /* iphone 4*/
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
}
</style>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-714916-2', 'ducksters.com');
  ga('send', 'pageview');
  ga('set', 'anonymizeIp', true);
</script>

<script type="text/javascript" src="/jquery-1.10.1.min.js"></script>
<script type="text/javascript" src="/jquery.sticky-kit.js"></script>
<script type="text/javascript" src="/sticky4.js"></script>

<link rel="shortcut icon" href="/favico2.png"> 
<link rel="apple-touch-icon" href="/favico2.png">
<link rel="icon" href="/favico2.png" sizes="16x16" type="image/png">


<meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body bgcolor="#ffffff">

<div class="columnsContainer" style="background-color:#2A9BD6;">
<div class="leftColumntop" align="left">
<font size="-1"><i>Parents and Teachers</i>: Support Ducksters by following us on <a href="https://www.facebook.com/pages/Ducksters/103074613109209"><img src="/facebook_24.png" width="24" height="24" alt="Ducksters Facebook" title="" /></a> or <a href="https://www.twitter.com/DuckstersKids"><img src="/twitter_24.png" width="24" height="24" alt="Ducksters Twitter" title="" /></a>.</font>
</div>

<div class="rightColumntop">
<form action="https://www.google.com" id="cse-search-box" target="_blank">
  <div>
    <input type="hidden" name="cx" value="partner-pub-1809268078385119:3620521284" />
    <input type="hidden" name="ie" value="UTF-8" />
    <input type="text" name="q" size="40" />
    <input type="submit" name="sa" value="Search" />
  </div>
</form>
<script type="text/javascript" src="https://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang="></script>
</div>
</div>
<div id="header_container">
<div class="leftColumn1" align="center">
<span id="graphic" style="position: relative;border: 0px;">
<a href="/"><img src="/graphics/ducksters_new_header_shrunk2.gif" width="700" height="200" alt="Ducksters Educational Site" title="" /></a></span><span id="graphic1" style="position: relative;border: 0px;"><a href="/"><img src="/graphics/ducksters_mobile_4.gif" alt="Ducksters Educational Site" border="0"></a>
</span>
<div align="center"><font size="+2">
<a  class="button green" href="/history/">History</a>
<a class="button green" href="/biography/">Biography</a>
<a class="button green" href="/geography/">Geography</a>
<a class="button green" href="/science/">Science</a>
<a class="button green" href="/games/">Games</a>
</font></div></div></div>
<BR id="adspace">
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
}
else
{
document.write("<div align='center'><div data-pw-desk='leaderboard_atf'></div><div data-pw-mobi='leaderboard_atf'></div>"); 
}
</script>
<div class="wrapper">
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
document.write("<div class='content_mobile' align='left'>");
if ($(window).width() < 600) {
document.write("<div align='center'>");
document.write("<div data-pw-mobi='leaderboard_atf'></div><div data-pw-desk='leaderboard_atf'></div>");   
}
else {
document.write("<div style='float:right;'>");   
document.write("<div data-pw-mobi='med_rect_atf'></div><div data-pw-desk='med_rect_atf'></div>"); 
} 
}
else
{
document.write("<div class='content' align='left'><div align='center'>");
}
</script></div>

      <table cellspacing="0" cellpadding="3" width="99%" align="center" border="0">
        
        <tr>
          <td>
		  <a href="/geography">Geography</a>	
            <h1><div align="center">Europe</div></h1>
			<h2><div align="center">Geography</div></h2>	
          <td>
      <p align="center"><img src="europeglobe.png" alt="Geography of Europe" width="210" height="120" alt="" border="0" align=""></p></td></tr></table></p> 
      </strong>

Europe is the sixth largest continent in size and the third largest in population. It is bordered by the Mediterranean Sea to the south, Asia to the east, and the Atlantic Ocean to the West. Europe is a wealthy continent and is the center of the West and Western Democracy.
<BR><BR>
Europe has been the home to some of the Earth's greatest civilizations from Ancient Greece to the Roman Empire. It is also the home to the birth of democracy. Europe has been the central point of two of the biggest wars in modern history: World War I and World War II. Recently Europe has united under the common union called the European Union. This union allows independent European countries to have a single currency and to combine their economic and military power.
<BR><BR>

<b><font color="#008000">Population:</font></b> 738,199,000 (Source: 2010 United Nations)
<div style='float:right;margin: 10px 10px'><a href="https://www.ilibrarian.net/flagmaps/europe.jpg" title="Click to see large Map of Europe"><img src="/geography/flagmaps/europe_sm.jpg" alt="Map of Europe"  border="0" align="">
<div align="center"> <BR>
Click here to see large map of Europe</a>
</div></div>
<BR><BR>
<b><font color="#008000">Area:</font></b> 3,930,000 square miles
<BR><BR>
<b><font color="#008000">Ranking:</font></b> It is the sixth largest and third most populous continent
<BR><BR>
<b><font color="#008000">Major Biomes:</font></b> temperate forest, grasslands
<BR><BR>
<b><font color="#008000">Major cities:</font></b>
<ul>
    <li>Moscow, Russia</li>
    <li>London, United Kingdom</li>
    <li>St Petersburg, Russia</li>
    <li>Berlin, Germany</li>
    <li>Madrid, Spain</li>
    <li>Rome, Italy</li>
    <li>Kiev, Ukraine</li>
    <li>Paris, France</li>
    <li>Bucharest, Romania</li>
    <li>Budapest, Hungary</li>
</ul>
<div align="center"><script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
document.write("<div data-pw-desk='med_rect_btf'></div>");
document.write("<div data-pw-mobi='med_rect_btf'></div>");
}
</script></div><b><font color="#008000">Bordering Bodies of Water:</font></b> Atlantic Ocean, Mediterranean Sea, Bay of Biscay, North Sea, Baltic Sea, Black Sea
<BR><BR>
<b><font color="#008000">Major Rivers and Lakes:</font></b> Danube River, Elbe River, Loire River, Po River, Rhine River, Volga River, Ladoga Lake, Onega Lake, Lake Geneva, Lake Como
<BR><BR>
<b><font color="#008000">Major Geographical Features:</font></b> Alps, Ural Mountains, Pyrenees, Carpathian Mountains, Apennines, Massif Central plateau, North European Plain, the islands of Great Britain and Ireland, Iberian Peninsula
<h2>Countries of Europe</h2>
Learn more about the countries from the continent of Europe. Get all sorts of information on each country from Europe including a map, a picture of the flag, population, and much more. Select the country below for more information:
		 <BR><BR> 
      <table border="0"  width="99%">
  <tr height="185" valign="top">
     <td width="35%">
 
 <a href="/geography/country.php?country=Albania" title="Learn more about Albania">Albania</a>
 <BR> 
 <a href="/geography/country.php?country=Andorra" title="Learn more about Andorra">Andorra</a> 
 <BR>
 <a href="/geography/country.php?country=Austria" title="Learn more about Austria">Austria</a>  
 <BR>
 <a href="/geography/country.php?country=Belarus" title="Learn more about Belarus">Belarus</a>  
 <BR>
  <a href="/geography/country.php?country=Belgium" title="Learn more about Belgium">Belgium</a> 
 <BR>
  <a href="/geography/country.php?country=Bosnia%20and%20Herzegovina" title="Learn more about Bosnia and Herzegovina">Bosnia and Herzegovina</a> 
 <BR>
  <a href="/geography/country.php?country=Bulgaria" title="Learn more about Bulgaria">Bulgaria</a> 
 <BR>
  <a href="/geography/country.php?country=Croatia" title="Learn more about Croatia">Croatia</a> 
 <BR>
  <a href="/geography/country.php?country=Czech%20Republic" title="Learn more about Czech Republic">Czech Republic</a> 
 <BR>
  <a href="/geography/country.php?country=Denmark" title="Learn more about Denmark">Denmark</a> 
 <BR>
  <a href="/geography/country.php?country=Estonia" title="Learn more about Estonia">Estonia</a> 
 <BR>
  <a href="/geography/country.php?country=European%20Union" title="Learn more about European Union">European Union</a> 
 <BR>
  <a href="/geography/country.php?country=Faroe%20Islands" title="Learn more about Faroe Islands">Faroe Islands</a> 
 <BR>
  <a href="/geography/country.php?country=Finland" title="Learn more about Finland">Finland</a> 
 <BR>
  <a href="/geography/country/france.php" title="Learn more about France">France</a><BR>
&nbsp;&nbsp;<a href="/geography/country/france_history_timeline.php">(Timeline of France)</a> 
 <BR>
  <a href="/geography/country/germany.php" title="Learn more about Germany">Germany</a><BR>
&nbsp;&nbsp;<a href="/geography/country/germany_history_timeline.php">(Timeline of Germany)</a> 
 <BR>
  <a href="/geography/country.php?country=Gibraltar" title="Learn more about Gibraltar">Gibraltar</a>
 <BR>
  <a href="/geography/country/greece.php" title="Learn more about Greece">Greece</a><BR>
&nbsp;&nbsp;<a href="/geography/country/greece_history_timeline.php">(Timeline of Greece)</a>
	 </td>
     <td width="32%">
  <a href="/geography/country.php?country=Guernsey" title="Learn more about Guernsey">Guernsey</a> 
 <BR> 	 
  <a href="/geography/country.php?country=Holy%20See%20(Vatican%20City)" title="Learn more about Holy See (Vatican City)">Holy See (Vatican City)</a>
 <BR>
  <a href="/geography/country.php?country=Hungary" title="Learn more about Hungary">Hungary</a> 
 <BR>
   <a href="/geography/country.php?country=Iceland" title="Learn more about Iceland">Iceland</a> 
 <BR>
  <a href="/geography/country/ireland.php" title="Learn more about Ireland">Ireland</a><BR>
&nbsp;&nbsp;<a href="/geography/country/ireland_history_timeline.php">(Timeline of Ireland)</a> 
 <BR>
  <a href="/geography/country.php?country=Isle%20of%20Man" title="Learn more about Isle of Man">Isle of Man</a> 
 <BR>
  <a href="/geography/country/italy.php" title="Learn more about Italy">Italy</a><BR>
&nbsp;&nbsp;<a href="/geography/country/italy_history_timeline.php">(Timeline of Italy)</a> 
 <BR>
  <a href="/geography/country.php?country=Jersey" title="Learn more about Jersey">Jersey</a> 
 <BR>
  <a href="/geography/country.php?country=Latvia" title="Learn more about Latvia">Latvia</a> 
 <BR>
  <a href="/geography/country.php?country=Liechtenstein" title="Learn more about Liechtenstein">Liechtenstein</a> 
 <BR>
  <a href="/geography/country.php?country=Lithuania" title="Learn more about Lithuania">Lithuania</a> 
 <BR>
  <a href="/geography/country.php?country=Luxembourg" title="Learn more about Luxembourg">Luxembourg</a> 
 <BR>
  <a href="/geography/country.php?country=Macedonia" title="Learn more about Macedonia">Macedonia</a> 
 <BR>
  <a href="/geography/country.php?country=Malta" title="Learn more about Malta">Malta</a> 
 <BR>
  <a href="/geography/country.php?country=Moldova" title="Learn more about Moldova">Moldova</a>
<BR>
  <a href="/geography/country.php?country=Monaco" title="Learn more about Monaco">Monaco</a> 
 <BR>
  <a href="/geography/country.php?country=Montenegro" title="Learn more about Montenegro">Montenegro</a>
 <BR> 
  <a href="/geography/country/netherlands.php" title="Learn more about Netherlands">Netherlands</a><BR>
&nbsp;&nbsp;<a href="/geography/country/netherlands_history_timeline.php">(Timeline of Netherlands)</a>
	 </td>
     <td width="33%">
  <a href="/geography/country.php?country=Norway" title="Learn more about Norway">Norway</a> 
 <BR>
  <a href="/geography/country/poland.php" title="Learn more about Poland">Poland</a><BR>
&nbsp;&nbsp;<a href="/geography/country/poland_history_timeline.php">(Timeline of Poland)</a> 
 <BR>
  <a href="/geography/country.php?country=Portugal" title="Learn more about Portugal">Portugal</a> 
 <BR>
  <a href="/geography/country.php?country=Romania" title="Learn more about Romania">Romania</a> 
 <BR>
  <a href="/geography/country/russia.php" title="Learn more about Russia">Russia</a><BR>
&nbsp;&nbsp;<a href="/geography/country/russia_history_timeline.php">(Timeline of Russia)</a> 
 <BR> 
  <a href="/geography/country.php?country=San%20Marino" title="Learn more about San Marino">San Marino</a> 
 <BR>
  <a href="/geography/country.php?country=Serbia" title="Learn more about Serbia">Serbia</a> 
 <BR>
  <a href="/geography/country.php?country=Slovakia" title="Learn more about Slovakia">Slovakia</a> 
 <BR>
  <a href="/geography/country.php?country=Slovenia" title="Learn more about Slovenia">Slovenia</a> 
 <BR>
  <a href="/geography/country/spain.php" title="Learn more about Spain">Spain</a><BR>
&nbsp;&nbsp;<a href="/geography/country/spain_history_timeline.php">(Timeline of Spain)</a> 
 <BR>
  <a href="/geography/country/sweden.php" title="Learn more about Sweden">Sweden</a><BR>
&nbsp;&nbsp;<a href="/geography/country/sweden_history_timeline.php">(Timeline of Sweden)</a> 
 <BR>
  <a href="/geography/country.php?country=Switzerland" title="Learn more about Switzerland">Switzerland</a> 
 <BR>
  <a href="/geography/country.php?country=Ukraine" title="Learn more about Ukraine">Ukraine</a> 
 <BR> 
  <a href="/geography/country/united_kingdom.php" title="Learn more about United Kingdom">United Kingdom</a><BR>
&nbsp;&nbsp;<a href="/geography/country/united_kingdom_history_timeline.php">(Timeline of United Kingdom)</a> 
 
	 </td>
  </tr>

</table>
 <BR>
 <div align="center"><script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
document.write("<div data-pw-desk='med_rect_btf'></div>");
document.write("<div data-pw-mobi='med_rect_btf'></div>");
}
</script></div><h2>Coloring Map</h2>

Color in this map to learn the countries of Europe.
 <BR><BR><div align="center"><a href="https://www.ilibrarian.net/flagmaps/europe_map_coloring.gif"><img src="europe_map_coloring_sm.jpg" width="202" height="269" alt="Europe Coloring Map of countries" border="0" align=""></a>
 <BR>Click to get a larger printable version of map.</div>
 <BR><BR>
	 
<h2>Fun Facts about Europe</h2>
Europe is home to the smallest country in the world, the Holy See or the Vatican. It is the smallest country both in size and population.
<BR><BR>
The tallest mountain in Europe is Mount Elbrus in Russia.
<BR><BR>
Europe is home to the birthplace of democracy and Western culture in the ancient civilizations of <a href="/history/ancient_greece.php">Ancient Greece</a> and <a href="/history/ancient_rome.php">Ancient Rome</a>.
<BR><BR>
Most of Europe now uses the same currency called the Euro.
<BR><BR>
The area of Russia that is west of the Ural Mountains is usually considered part of Europe. The area to the east of the Urals is considered part of Asia.
<BR><BR>
The Industrial Revolution began in Europe in Great Britain.
 <BR>
 <h2>Other Maps</h2>  
<table border="0"  width="99%">
  <tr><!-- Row 1 -->
     <td  width="33%">
	 <div align="center"><a href="https://www.ilibrarian.net/flagmaps/europe_eu_nato.jpg"><img src="flagmaps/europe_eu_nato_sm.jpg" width="197" height="152" alt="" title="" border="0"/><BR>
European Union and NATO<BR>
(click for larger)</a></div>
	 </td><!-- Col 1 -->
     <td width="33%">
	 <div align="center"><a href="https://www.ilibrarian.net/flagmaps/europe_population_density.jpg"><img src="flagmaps/europe_population_density_sm.jpg" width="200" height="150" alt="" title="" border="0"/><BR>
Population Density<BR>
(click for larger)</a></div>
	 </td><!-- Col 2 -->
     <td width="33%">
	<div align="center"> <a href="https://www.ilibrarian.net/flagmaps/europe_satellite_map.jpg"><img src="flagmaps/europe_satellite_map_sm.jpg" width="200" height="140" alt="" title="" border="0"/><BR>
Satellite Map<BR>
(click for larger)</a> </div>
	 
	 </td><!-- Col 3 -->
  </tr>
</table>
<BR>
<b>Geography Games:</b>
<BR><BR>
<a href="/games/europe_map_game.php">Europe Map Game</a><BR>
<a href="/games/europe_capital_cities_map_game.php">Europe -  Capital Cities</a><BR>
<a href="/games/europe_flags_map_game.php">Europe - Flags</a><BR>
<a href="/games/crossword_puzzle/europe_geography.php">Europe Crossword</a><BR>
<a href="/games/word_search/europe_geography.php">Europe Word Search</a>
<BR><BR>
<b>Other Regions and Continents of the World:</b>

<ul>
    <li><a href="/geography/africa.php">Africa</a></li>
    <li><a href="/geography/asia.php">Asia</a></li>
    <li><a href="/geography/centralamerica.php">Central America and Caribbean</a></li>
    <li><a href="/geography/europe.php">Europe</a></li>
    <li><a href="/geography/middleeast.php">Middle East</a></li>
    <li><a href="/geography/northamerica.php">North America</a></li>
    <li><a href="/geography/oceania.php">Oceania and Australia</a></li>
    <li><a href="/geography/southamerica.php">South America</a></li>
    <li><a href="/geography/southeastasia.php">Southeast Asia</a></li>
</ul>  

      <p dir="ltr">Back to <a 
      href="/geography"><strong>Geography</strong></a> Home Page</p>
	  
      
      
      </div>
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
}
else
{

document.write("<div class='sidebar-right' id='sidebar'><div class='inner'><span id='ad_text'>Advertisement</span><div align='center' id='rightsidebox1'>");
document.write("<div data-pw-desk='med_rect_atf'></div>");
document.write("<div data-pw-mobi='med_rect_atf'></div>");
document.write("</div><table  id='rightsidebox2'><tr><td>");

var value=Math.floor((Math.random()*4)+1);
if (value==1)
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>Vote for your favorite US President:</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpoll.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>George Washington<br><input name='answer' type='radio' value='two'>John Adams<br><input name='answer' type='radio' value='three'>Thomas Jefferson<br><input name='answer' type='radio' value='four'>Abraham Lincoln<br><input name='answer'type='radio' value='five'>Franklin D. Roosevelt<br></font>");
}
else if (value==2)
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>Which superpower would you want if you were a Superhero?</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpollsuperpower.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>Super Strength<br><input name='answer' type='radio' value='two'>Flying<br><input name='answer' type='radio' value='three'>Super Speed<br><input name='answer' type='radio' value='four'>Invisibility<br><input name='answer'type='radio' value='five'>Super Stretch<br></font>");
}
else if (value==3)
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>Vote for your favorite explorer:</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpollexplorers.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>Captain James Cook<br><input name='answer' type='radio' value='two'>Neil Armstrong<br><input name='answer' type='radio' value='three'>Christopher Columbus<br><input name='answer' type='radio' value='four'>Ferdinand Magellan<br><input name='answer'type='radio' value='five'>Marco Polo<br></font>");
}
else
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>What is your best subject at school?</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpollschoolsubject.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>Math<br><input name='answer' type='radio' value='two'>Reading<br><input name='answer' type='radio' value='three'>Writing<br><input name='answer' type='radio' value='four'>Science<br><input name='answer'type='radio' value='five'>History<br></font>");
}
document.write("</div></td><td><input name='psubmit' type='submit' value='Vote' class='button blue'></form><BR><BR><a href='/takekidspolls1.php'><font size='-1'>More polls</font></a></td></tr></table></td></tr></table>");
}
</script>
</div>
</div>
</div>

<div id="footerid">
<div align="center">
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
document.write("<div data-pw-desk='leaderboard_btf'></div><div data-pw-mobi='leaderboard_btf'></div>");
}
else
{
document.write("<div data-pw-desk='leaderboard_btf'></div><div data-pw-mobi='leaderboard_btf'></div>");
}
</script>
</div>
<BR><BR>
<div id="footer_search">
<form action="https://www.google.com" id="cse-search-box">
  <div>
    <input type="hidden" name="cx" value="partner-pub-1809268078385119:5398998522" />
    <input type="hidden" name="ie" value="UTF-8" />
    <input type="text" name="q" size="36" />
    <input type="submit" name="sa" value="Search" />
  </div>
</form>
<script type="text/javascript" src="https://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en"></script>
</div>
<BR>
<table id="footer_menu"><tr><td> 
<span id="footer_column1">
	<a href="/study.php"><font color="#F48F0C">Homework</font></a><br>	
		<a href="/animals.php">Animals</a><br>
		<a href="/kidsmath/">Math</a><br>
	    <a href="/history/">History</a><br>	
		<a href="/biography/">Biography</a><br>
		<a href="/money/">Money and Finance</a><br> 
	<br>
			<font color="#F48F0C">Biography</font><br>	
		  <a href="/history/art/">Artists</a><br>
		  <a href="/history/civil_rights/">Civil Rights Leaders</a><br>
		  <a href="/biography/entrepreneurs/">Entrepreneurs</a><br>
		  <a href="/biography/explorers/">Explorers</a><br>
		  <a href="/biography/scientists/scientists_and_inventors.php">Inventors and Scientists</a><br>
		  <a href="/biography/women_leaders/">Women Leaders</a><br>
		  <a href="/biography/world_leaders/">World Leaders</a><br>
		  <a href="/biography/uspresidents/">US Presidents</a><br>
		  <br>
</span>	<span id="footer_column2"> 
          <a><font color="#F48F0C">US History</font></a><br>
		  <a href="/history/native_americans.php">Native Americans</a><BR>
		  <a href="/history/colonial_america/">Colonial America</a><br>
          <a href="/history/american_revolution.php">American Revolution</a><BR>
		  <a href="/history/us_1800s/industrial_revolution.php">Industrial Revolution</a><BR>  
          <a href="/history/civil_war.php">American Civil War</a><BR>
          <a href="/history/westward_expansion/">Westward Expansion</a><BR>
		  <a href="/history/us_1900s/great_depression.php">The Great Depression</a><BR>
		  <a href="/history/civil_rights/">Civil Rights Movement</a><BR>
		  <a href="/history/us_1800s/">Pre-1900s</a><BR>
          <a href="/history/us_1900s/">1900 to Present</a><BR>
		  <a href="/history/us_government.php">US Government</a><BR>
          <a href="/geography/us_states/">US State History</a><BR>	
		<br> 
		<a href="/science/"><font color="#F48F0C">Science</font></a><br>
        <a href="/science/biology/">Biology</a><br>
		<a href="/science/chemistry/">Chemistry</a><br>	
		<a href="/science/earth_science/">Earth Science</a><br>							
		<a href="/science/physics/">Physics</a><br>	
	<BR>	
</span>	<span id="footer_column3">  
          <a><font color="#F48F0C">World History</font></a><br>
		  <a href="/history/africa/">Ancient Africa</a><BR>						
          <a href="/history/china/ancient_china.php">Ancient China</a><br>
          <a href="/history/ancient_egypt.php">Ancient Egypt</a><br>
          <a href="/history/ancient_greece.php">Ancient Greece</a><br>
          <a href="/history/mesopotamia/ancient_mesopotamia.php">Ancient Mesopotamia</a><br>		  
          <a href="/history/ancient_rome.php">Ancient Rome</a><br>
          <a href="/history/middle_ages_timeline.php">Middle Ages</a><br>
          <a href="/history/islam/">Islamic Empire</a><BR>		  
          <a href="/history/renaissance.php">Renaissance</a><br>
          <a href="/history/aztec_maya_inca.php">Aztec, Maya, Inca</a><br>
		  <a href="/history/french_revolution/">French Revolution</a><br>
          <a href="/history/world_war_i/">World War 1</a><br>
          <a href="/history/world_war_ii/">World War 2</a><br>
          <a href="/history/cold_war/summary.php">Cold War</a><br>
          <a href="/history/art/">Art History</a><br>	
         <br>
	 
</span>	
<span id="footer_column4">
	 <a href="/geography/"><font color="#F48F0C">Geography</font></a><br>
					<a href="/geography/usgeography.php">United States</a><br>
					<a href="/geography/africa.php">Africa</a><br>
					<a href="/geography/asia.php">Asia</a><br>
					<a href="/geography/centralamerica.php">Central America</a><br>
					<a href="/geography/europe.php">Europe</a><br>
					<a href="/geography/middleeast.php">Middle East</a><br>
					<a href="/geography/northamerica.php">North America</a><br>
					<a href="/geography/oceania.php">Oceania</a><br>
					<a href="/geography/southamerica.php">South America</a><br>
					<a href="/geography/southeastasia.php">Southeast Asia</a><br>	 
<br>
     <a><font color="#F48F0C">Fun Stuff</font></a><br>	
		       <a href="/games/">Educational Games</a><br>
			   <a href="/holidays/kids_calendar.php">Holidays</a><BR>	
			   <a href="/jokes/">Jokes for Kids</a><br>	
			   <a href="/movies.php">Movies</a><br>	
			   <a href="/music.php">Music</a><br>  
			   <a href="/sports.php">Sports</a><br>	

</span> 
	 </td></tr>
<div align="center"><img src="/graphics/ducksters_footer_1.gif" width="745" height="101" alt="" title="" />	</div> 
	 </table>
<BR><BR>
<a href="/about.php">About Ducksters</a>&nbsp;<a href="/privacy_policy.php"><b><font color="#008000">Privacy Policy</b></a></font>&nbsp;
<script type="text/javascript">
var title_1 = document.title;
var location_1 = document.location.href;
document.write ("<a href='/citation.php?title=" + title_1 + "&location=" + location_1 + "'>Cite this Page</a>");
</script>&nbsp;
<BR><BR>
Follow us on <a href="https://www.facebook.com/pages/Ducksters/103074613109209"><img src="/facebook_24.png" width="24" height="24" alt="Ducksters Facebook" title="" /></a> or <a href="https://www.twitter.com/DuckstersKids"><img src="/twitter_24.png" width="24" height="24" alt="Ducksters Twitter" title="" /></a>
<BR><BR>
This site is a product of TSI (Technological Solutions, Inc.), Copyright 2019, All Rights Reserved.
By using this site you agree to the
<a href="/termsofuse.php">Terms of Use.</a>
<BR><BR>
<script type="text/javascript">
var title_1 = document.title;
var location_1 = document.location.href;
document.write ("<a href='/citation.php?title=" + title_1 + "&location=" + location_1 + "'>Cite this Page</a>");
</script>
<BR><BR>
</div>
</div>             

</body>
</html>
