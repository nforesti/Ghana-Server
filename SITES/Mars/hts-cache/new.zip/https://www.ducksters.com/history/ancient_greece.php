<!DOCTYPE HTML>
<html lang="en">
<head>
<style type="text/css">
table a {display: inline-block; margin: 4px 4px 4px 4px;} 
</style>
<meta name="keywords" content="Ancient,Greece,kids,history,social,studies">

<meta name="description" content="Kids learn about the civilization and history of Ancient Greece including the government, philosophy, science, Athens, Sparta, daily life, people, art, architecture, theater, and mythology. Educational articles for students, schools, and teachers.">

<title>History: Ancient Greece for Kids</title>

<script type="text/javascript">
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
  var tyche = {
                mode: 'tyche',
                config: '//config.playwire.com/1015702/v2/websites/62069/banner.json',
                isMobile: 'true'
            };
}
else
{
  var tyche = {
                mode: 'tyche',
                config: '//config.playwire.com/1015702/v2/websites/62069/banner.json',
            };
}
</script>
<script id="tyche" src="//cdn.intergi.com/hera/tyche.js" type="text/javascript"></script>

<style type="text/css">

@media screen{

*, *:before, *:after {
  -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
}
 
body { margin: 0; }

img {
  max-width: 100%; height: auto;
}

.columnsContainer { position: relative; margin: 0px; margin-left:auto; margin-right:auto; max-width:1070px;background-color: #FFFFFF;}

#graphic1 {display:none; }
h1 { font-family: 'Century Gothic', Calibri, Geneva, sans-serif; font-size:2.3em; color: #008040;margin:6px 10px 6px 10px;}
h2 { font-family: 'Century Gothic', Calibri, Geneva, sans-serif; font-size:2.2em; color: #004080;margin:6px 10px 8px 10px;}
body {font-size:1.0em;}

body {
    font-size:100%;
	font-family: Arial;
	background: #2A9BD6;
	text-align: center;
	padding: 0;
}

ul li a {display: inline-block; margin: 4px 4px 4px 4px;} 
li a {display: inline-block; margin: 4px 4px 4px 4px;} 
ul a {display: inline-block; margin: 4px 4px 4px 4px;} 
span a {display: inline-block; margin: 4px 4px 4px 4px;} 
table a {display: inline-block; margin: 4px 4px 4px 4px;} 

a.playwire_report_ad_link{
color: #898989 !important;
text-decoration: none;
}
.wrapper {
  width:100%;
  max-width:1070px;
  margin:0 auto;
  background:#FFFFFF;
  overflow:hidden;
}
.inner {
  -webkit-transform: translateZ(0);
  transform: translateZ(0);
 }
.sidebar-right {
  background:#FFFFF;
  width:100%;
  float:none;
  padding:.4em;
  margin:.4em 0 .4em;
}
.contentT {
  padding:.4em;
  width: 100%;
  padding-right:.5em;
  float:left;
}
.content {
  padding:.4em;
  width: 100%;
  min-height:1450px;
  padding-right:.5em;
  float:left;
}
#playwire_video {padding-top:3px;margin:auto;max-width:640px;}
#standard_image {
    clear:both;
    margin:auto;
    border-style: solid;
    border-color: #525252;
    border-width: 4px;
    display:inline-block;
    background-color: white;
    box-shadow: 5px 10px 5px #888888;
    padding:2px;
    margin-bottom:25px;
}
#standard_image_center {
    clear:both;
    margin:auto;
    border-style: solid;
    border-color: #525252;
    border-width: 4px;
    display:inline-block;
    background-color: white;
    box-shadow: 5px 10px 5px #888888;
    padding:2px;
    margin-bottom:25px;
}
#header_container {
    max-width: 1070px;
    margin: 0px auto 0px auto;
	background-color: #FFFFFF;
	padding:10px 10px 0px 10px;
	position:relative;
	border:8px;
	border-color:#008000;
	border-style:solid;
	border-radius:20px; 
 }
#ad_text {
  font-family : "Arial",sans-serif;
  font-size : .9em;
  font-weight : normal;
  color: #898989;
 }
.radio-toolbar label {
    display:inline-block;
    background-color:#ddd;
    padding:4px 11px;
    font-family:Arial;
    font-size:16px;
}
.radio-toolbar input[type="radio"]:checked + label {
    background-color:#bbb;
}
.button {
  display : inline-block;
  cursor : pointer;
  border-radius : 5px;
  padding : 5px 11px 5px 11px;
  width: 112px;
  box-shadow : 0 1px 4px rgba(0,0,0,.6);
  font-size : 20px;
  font-weight : normal;
  color : #fff;
  text-shadow : 0 1px 3px rgba(0,0,0,.4);
  font-family : "Arial",sans-serif;
  text-decoration : none;
  margin: 0px 0px 10px 10px;
}
button.blue,
.button.blue {
  border-color : #0080C0;
  background: #0080C0;
}
button.green,
.button.green {
  border-color : #008000;
  background: #008000;
}
#rightsidebox1 { 
	width: 320px;
	padding: 0px;
	background-color:#FFF;
	border: 10px solid #004080;
	margin: 0px auto 10px auto;
	-webkit-transform: translateZ(0);
	transform: translateZ(0);
	}
#rightsidebox2 { 
	width: 320px;
	padding: 0px;
	background-color:#FFF;
	border: 10px solid #F48F0C;
	margin: 0px auto 10px auto;
	-webkit-transform: translateZ(0);
	transform: translateZ(0);
	} 		
#rightside {
    float:right;
	margin: 0 0 0px 0px;
	background-color: #FFFFFF;
    }	
#main_table {
	text-align:left;
	}
#footerid {
    font-size:0.9em;
    margin: 0px auto 0px auto;
    max-width:1070px;
}
#footer_search {
	border: 10px solid #F48F0C;
	margin: 10px auto 10px auto;
   padding: 20px;
   background-color: #FFFFFF;
 }	
#footer_menu {
  width: 100%;
  border: 10px solid #008000;
  text-align:left;
  background-color: #FFFFFF;
 } 
#footer_menu td { 
  vertical-align:top;
  font-size:1.1em;
}

#footer_column1 {width:50%;position:relative;float:left;} 
#footer_column2 {width:50%;position:relative;float:left;}
#footer_column3 {width:50%;position:relative;float:left;}
#footer_column4 {width:50%;position:relative;float:left;}

#whatsnewfont {
font-family: 'Comic Sans MS'; font-weight: bold; font-style: normal; text-decoration: none; font-size: 24pt; color: #008080}
#whatsnewlink  { 
font-family: 'Century Gothic', Calibri, Geneva, sans-serif; font-weight:bold; text-decoration: none; font-size: 24pt; color: #008000;}
} 

@media screen and (min-width: 550px){


#standard_image {
    float:right;
	margin: 25px 25px;
}
  
#main_table {max-width:1070px;}
#footer_search {max-width: 600px;}
#footerid {max-width: 1070px;background-color: #FFFFFF;}
#graphic1 {display:none; }

.wrapper {
  width:100%;
  max-width:1070px;
  margin:0 auto;
  background:#FFFFFF;
  overflow:hidden;
  border:5px;border-color:#008040;border-style:solid;
}

.sidebar-right {
  background:#FFFFF;
  width:31%;
  float:left;
  padding:.1em;
  margin:.1em 0 .1em;
}
.contentT {
  padding:.4em;
  width: 67%;
  padding-right:.5em;
  float:left;
}
.content {
  padding:.4em;
  width: 69%;
  min-height:1450px;
  padding-right:.5em;
  float:left;
}

.content_mobile {
  padding:.4em;
  width: 100%;
  padding-right:.5em;
  float:left;
}

.leftColumntop {margin-right: 450px; background-color: #2A9BD6;padding-left: 10px;padding-right:10px}
.rightColumntop {position: absolute; top: 0; right: 0; width: 450px;background-color: #2A9BD6;padding-right:10px}

.leftColumn1 {margin-right: 0px; background-color: #FFFFFF;padding-left: 10px;padding-right:10px}
.rightColumn1 { position: absolute; top: 0px; right: 8px; width: 320px;background-color: #FFFFFF;padding:15px 10px 0px 10px}

.leftColumn {margin-right: 343px; min-height:1450px;background-color: #FFFFFF;padding-left: 10px;padding-right:8px}
.rightColumn {position: absolute; top: 10px; right: 0; width: 343px;background-color: #FFFFFF;padding-right:5px;}

#footer_column1 {width:25%;position:relative;float:left;} 
#footer_column2 {width:25%;position:relative;float:left;}
#footer_column3 {width:25%;position:relative;float:left;}
#footer_column4 {width:25%;position:relative;float:left;}
}

@media screen and (max-width: 655px) 
{
#graphic1 {display:none; }
.leftColumntop {display:none; }
.rightColumntop {display:none; }

#adspace {display:none; }

.button {
  border-radius : 2px;
  padding : 4px 4px 4px 4px;
  width: auto;
  font-size : 20px;
  font-weight : normal;
  margin: 0px 0px 5px 5px;
}

}

@media screen and (max-width: 470px){
#graphic {display:none; }
#graphic1 {display:inline; }
}

@media screen and (max-width: 400px){
#graphic {display:none; }
#graphic1 {display:inline; }
#rightsidebox1 { 
	width: 308px;
	border: 4px solid #004080;
	}
#rightsidebox2 { 
	width: 308px;
	border: 4px solid #F48F0C;
	}
#header_container {
    max-width: 1070px;
    margin: 0px auto 0px auto;
	background-color: #FFFFFF;
	padding:0px 0px 2px 0px;
	position:relative;
	border:4px;
	border-color:#008000;
	border-style:solid;
	border-radius:10px; 
 }	
}

@media screen and (-webkit-min-device-pixel-ratio: 2){
  /* iphone 4*/
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
}
</style>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-714916-2', 'ducksters.com');
  ga('send', 'pageview');
  ga('set', 'anonymizeIp', true);
</script>

<script type="text/javascript" src="/jquery-1.10.1.min.js"></script>
<script type="text/javascript" src="/jquery.sticky-kit.js"></script>
<script type="text/javascript" src="/sticky4.js"></script>

<link rel="shortcut icon" href="/favico2.png"> 
<link rel="apple-touch-icon" href="/favico2.png">
<link rel="icon" href="/favico2.png" sizes="16x16" type="image/png">


<meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body bgcolor="#ffffff">

<div class="columnsContainer" style="background-color:#2A9BD6;">
<div class="leftColumntop" align="left">
<font size="-1"><i>Parents and Teachers</i>: Support Ducksters by following us on <a href="https://www.facebook.com/pages/Ducksters/103074613109209"><img src="/facebook_24.png" width="24" height="24" alt="Ducksters Facebook" title="" /></a> or <a href="https://www.twitter.com/DuckstersKids"><img src="/twitter_24.png" width="24" height="24" alt="Ducksters Twitter" title="" /></a>.</font>
</div>

<div class="rightColumntop">
<form action="https://www.google.com" id="cse-search-box" target="_blank">
  <div>
    <input type="hidden" name="cx" value="partner-pub-1809268078385119:3620521284" />
    <input type="hidden" name="ie" value="UTF-8" />
    <input type="text" name="q" size="40" />
    <input type="submit" name="sa" value="Search" />
  </div>
</form>
<script type="text/javascript" src="https://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang="></script>
</div>
</div>
<div id="header_container">
<div class="leftColumn1" align="center">
<span id="graphic" style="position: relative;border: 0px;">
<a href="/"><img src="/graphics/ducksters_new_header_shrunk2.gif" width="700" height="200" alt="Ducksters Educational Site" title="" /></a></span><span id="graphic1" style="position: relative;border: 0px;"><a href="/"><img src="/graphics/ducksters_mobile_4.gif" alt="Ducksters Educational Site" border="0"></a>
</span>
<div align="center"><font size="+2">
<a  class="button green" href="/history/">History</a>
<a class="button green" href="/biography/">Biography</a>
<a class="button green" href="/geography/">Geography</a>
<a class="button green" href="/science/">Science</a>
<a class="button green" href="/games/">Games</a>
</font></div></div></div>
<BR id="adspace">
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
}
else
{
document.write("<div align='center'><div data-pw-desk='leaderboard_atf'></div><div data-pw-mobi='leaderboard_atf'></div>"); 
}
</script>
<div class="wrapper">
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
document.write("<div class='content_mobile' align='left'>");
if ($(window).width() < 600) {
document.write("<div align='center'>");
document.write("<div data-pw-mobi='leaderboard_atf'></div><div data-pw-desk='leaderboard_atf'></div>");   
}
else {
document.write("<div style='float:right;'>");   
document.write("<div data-pw-mobi='med_rect_atf'></div><div data-pw-desk='med_rect_atf'></div>"); 
} 
}
else
{
document.write("<div class='content' align='left'><div align='center'>");
}
</script></div>
<h1><div align="center">Ancient Greece for Kids</div></h1>

Ancient Greece was a civilization that dominated much of the Mediterranean thousands of years ago. At its peak under Alexander the Great, Ancient Greece ruled much of Europe and Western Asia. The Greeks came before the <a href="/history/ancient_rome.php">Romans</a> and much of the Roman culture was influenced  by the Greeks. 
<BR><BR>
Ancient Greece formed the foundation of much of Western culture today. Everything from government, philosophy, science, mathematics, art, literature, and even sports was impacted by the Ancient Greeks.
<BR><BR><div align="center"><img src="greek_acropolis_2.jpg" width="403" height="178" alt="Acropolis in Athens" border="0" align="">
<BR><i>The Acropolis of Athens</i> by Salonica84</div>
<BR>
<b>Periods</b>
<BR><BR>
Historians often divide up the history of Ancient Greece into three periods:

<ol type="1">
    <li><b>Archaic Period</b> - This period ran from the start of Greek civilization in 800 BC to the introduction of Democracy in 508 BC. This period included the start of the Olympic Games and Homer's writing of the Odyssey and the Illiad.</li>
    <li><b>Classical Period</b> - This is the time that most of us think of when we think of Ancient Greece. Athens was governed by a democracy and great philosophers like Socrates and Plato arose. Also, the wars between Sparta and Athens were during this time. This period ended with the rise and then death of Alexander the Great in 323 BC.</li>
    <li><b>Hellenistic Period </b>- The Hellenistic period lasted from the death of Alexander the Great until 146 BC when Rome conquered Greece. The name Hellenistic comes from the Greek word "hellens", which is what the Greeks called themselves.</li>
</ol> 
<div align="center"><script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
document.write("<div data-pw-desk='med_rect_btf'></div>");
document.write("<div data-pw-mobi='med_rect_btf'></div>");
}
</script></div><b>Athens and Sparta</b>
<BR><BR>
Athens and Sparta were the two main city states that ruled much of ancient Greece. They were often rivals and fought each other in the Peloponnesian Wars. At other times they united together in order to protect the Greek lands from invaders. The cultures of the two cities were very different. Sparta was almost entirely focused on war and how to fight, while Athens focused on the arts and learning.
<BR><BR>
<b>Fun Facts about Ancient Greece</b>

<ul>
    <li>The Greeks often ate dinner while lying on their sides.</li>
    <li>They invented the yo-yo which is considered the 2nd oldest toy in the world after the doll.</li>
    <li>About one third of the population of some city-states were slaves.</li>
    <li>There were more city-states than just Sparta and Athens, Ancient Greece had around 100 city-states.</li>
    <li>The Romans copied much of the Greek culture including their gods, architecture, language, and even how they ate!</li>
    <li>Pheidippides was a Greek hero who ran 150 miles from Marathon to Sparta to get help against the Persians. After the Greeks won the war, he ran 25 miles from Marathon to Athens to announce the victory. This is where the marathon running race gets its name.</li>
    <li>When law trials were held in the city of Athens, they used large juries of 500 citizens. That's a lot more than the 12 we use today.</li>
</ul> 
<b>Recommended books and references:</b>
<BR><BR>
    <li>A guide to the golden age of Greece by Julie Ferris. 1999.</li>
    <li>A Cultural Atlas for Young People: Ancient Greece by Anton Powell. 1989.</li>
    <li>Eyewitness Books: Ancient Greece written by Anne Pearson. 2004.</li>
    <li>Life in ancient Athens by Don Nardo. 2000. </li>
 
<BR><BR>
<div align="center"><script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
document.write("<div data-pw-desk='med_rect_btf'></div>");
document.write("<div data-pw-mobi='med_rect_btf'></div>");
}
</script></div><b>Activities</b>
<ul>
    <li>Take a ten question <a href="/history/ancient_greece_questions.php">quiz</a> about this page.</li>
    <BR>
    <li>Go here to test your knowledge with a <a href="/games/crossword_puzzle/ancient_greece.php">Ancient Greece crossword puzzle</a> or <a href="/games/word_search/ancient_greece.php">word search</a>.</li>
    <BR>	
    <li>Listen to a recorded reading of this page:</li>
    <BR>
    <audio controls preload="none"><source src="https://www.ilibrarian.net/audio/ancientgreeceforkids.mp3" type="audio/mpeg">
    Your browser does not support the audio element.</audio>
</ul>
<b>For more about Ancient Greece:</b>
<BR><BR>
<table border="0"  width="99%">
  <tr><!-- Row 1 -->
     <td valign="top">
<b>Overview</b><BR>
<a href="/history/ancient_greek_timeline.php">Timeline of Ancient Greece</a><BR>
<a href="/history/ancient_greece/geography.php">Geography</a><BR>
<a href="/history/ancient_greek_athens.php">The City of Athens</a><BR>
<a href="/history/ancient_greece/sparta.php">Sparta</a><BR>
<a href="/history/ancient_greece/minoans_mycenaeans.php">Minoans and Mycenaeans</a><BR>
<a href="/history/ancient_greece/greek_city_state.php">Greek City-states</a><BR>
<a href="/history/ancient_greece/peloponnesian_war.php">Peloponnesian War</a><BR>
<a href="/history/ancient_greece/persian_wars.php">Persian Wars</a><BR>
<a href="/history/ancient_greece/decline_and_fall_of_ancient_greece.php">Decline and Fall</a><BR>
<a href="/history/ancient_greece/legacy.php">Legacy of Ancient Greece</a><BR>
<a href="/history/ancient_greece/glossary_and_terms.php">Glossary and Terms</a><BR><BR>	  
<b>Arts and Culture</b><BR>
<a href="/history/art/ancient_greek_art.php">Ancient Greek Art</a><BR>
<a href="/history/ancient_greece/drama_and_theatre.php">Drama and Theater</a><BR>
<a href="/history/ancient_greece/architecture.php">Architecture</a><BR>
<a href="/history/ancient_greek_olympics.php">Olympic Games</a><BR>
<a href="/history/ancient_greek_government.php">Government of Ancient Greece</a><BR>
<a href="/history/ancient_greece/greek_alphabet.php">Greek Alphabet</a><BR><BR>
	 </td><!-- Col 1 -->
     <td valign="top">
<b>Daily Life</b><BR>
<a href="/history/ancient_greek_daily_life.php">Daily Lives of the Ancient Greeks</a><BR>
<a href="/history/ancient_greece/typical_greek_city.php">Typical Greek Town</a><BR>
<a href="/history/ancient_greece/food.php">Food</a><BR>
<a href="/history/ancient_greece/clothing.php">Clothing</a><BR>
<a href="/history/ancient_greece/womens_roles.php">Women in Greece</a><BR>
<a href="/history/ancient_greece/science_and_technology.php">Science and Technology</a><BR>
<a href="/history/ancient_greece/soldiers_and_war.php">Soldiers and War</a><BR>
<a href="/history/ancient_greece/slaves.php">Slaves</a><BR><BR>
<b>People</b><BR>
<a href="/biography/alexander_the_great.php">Alexander the Great</a><BR>
<a href="/history/ancient_greece/archimedes.php">Archimedes</a><BR>
<a href="/history/ancient_greece/aristotle.php">Aristotle</a><BR>
<a href="/history/ancient_greece/pericles.php">Pericles</a><BR>
<a href="/history/ancient_greece/plato.php">Plato</a><BR>
<a href="/history/ancient_greece/socrates.php">Socrates</a><BR>
<a href="/history/ancient_greek_famous_people.php">25 Famous Greek People</a><BR>
<a href="/history/ancient_greek_philosophers.php">Greek Philosophers</a><BR><BR>	
	 </td><!-- Col 2 -->
     <td valign="top">
<b>Greek Mythology</b><BR> 
<a href="/history/ancient_greek_mythology.php">Greek Gods and Mythology</a><BR>
<a href="/history/ancient_greece/hercules.php">Hercules</a><BR>
<a href="/history/ancient_greece/achilles.php">Achilles</a><BR>
<a href="/history/ancient_greece/monsters_and_creatures_of_greek_mythology.php">Monsters of Greek Mythology</a><BR>
<a href="/history/ancient_greece/titans.php">The Titans</a><BR>
<a href="/history/ancient_greece/iliad.php">The Iliad</a><BR>
<a href="/history/ancient_greece/odyssey.php">The Odyssey</a><BR><BR>	 
<b>The Olympian Gods</b><BR>
<a href="/history/ancient_greece/zeus.php">Zeus</a><BR>
<a href="/history/ancient_greece/hera.php">Hera</a><BR>
<a href="/history/ancient_greece/poseidon.php">Poseidon</a><BR>
<a href="/history/ancient_greece/apollo.php">Apollo</a><BR>
<a href="/history/ancient_greece/artemis.php">Artemis</a><BR>
<a href="/history/ancient_greece/hermes.php">Hermes</a><BR>
<a href="/history/ancient_greece/athena.php">Athena</a><BR>
<a href="/history/ancient_greece/ares.php">Ares</a><BR>
<a href="/history/ancient_greece/aphrodite.php">Aphrodite</a><BR>
<a href="/history/ancient_greece/hephaestus.php">Hephaestus</a><BR>
<a href="/history/ancient_greece/demeter.php">Demeter</a><BR>
<a href="/history/ancient_greece/hestia.php">Hestia</a><BR>
<a href="/history/ancient_greece/dionysus.php">Dionysus</a><BR>
<a href="/history/ancient_greece/hades.php">Hades</a><BR>
	 </td><!-- Col 3 -->
  </tr>
</table>
<BR>
<a href="/works_cited/ancient_greece.php">Works Cited</a>
	  
      <p>Back to <a 
      href="/history/"><strong>History for Kids</strong></a>
	  </p>
      
      
      </div>
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
}
else
{

document.write("<div class='sidebar-right' id='sidebar'><div class='inner'><span id='ad_text'>Advertisement</span><div align='center' id='rightsidebox1'>");
document.write("<div data-pw-desk='med_rect_atf'></div>");
document.write("<div data-pw-mobi='med_rect_atf'></div>");
document.write("</div><table  id='rightsidebox2'><tr><td>");

var value=Math.floor((Math.random()*4)+1);
if (value==1)
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>Vote for your favorite US President:</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpoll.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>George Washington<br><input name='answer' type='radio' value='two'>John Adams<br><input name='answer' type='radio' value='three'>Thomas Jefferson<br><input name='answer' type='radio' value='four'>Abraham Lincoln<br><input name='answer'type='radio' value='five'>Franklin D. Roosevelt<br></font>");
}
else if (value==2)
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>Which superpower would you want if you were a Superhero?</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpollsuperpower.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>Super Strength<br><input name='answer' type='radio' value='two'>Flying<br><input name='answer' type='radio' value='three'>Super Speed<br><input name='answer' type='radio' value='four'>Invisibility<br><input name='answer'type='radio' value='five'>Super Stretch<br></font>");
}
else if (value==3)
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>Vote for your favorite explorer:</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpollexplorers.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>Captain James Cook<br><input name='answer' type='radio' value='two'>Neil Armstrong<br><input name='answer' type='radio' value='three'>Christopher Columbus<br><input name='answer' type='radio' value='four'>Ferdinand Magellan<br><input name='answer'type='radio' value='five'>Marco Polo<br></font>");
}
else
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>What is your best subject at school?</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpollschoolsubject.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>Math<br><input name='answer' type='radio' value='two'>Reading<br><input name='answer' type='radio' value='three'>Writing<br><input name='answer' type='radio' value='four'>Science<br><input name='answer'type='radio' value='five'>History<br></font>");
}
document.write("</div></td><td><input name='psubmit' type='submit' value='Vote' class='button blue'></form><BR><BR><a href='/takekidspolls1.php'><font size='-1'>More polls</font></a></td></tr></table></td></tr></table>");
}
</script>
</div>
</div>
</div>

<div id="footerid">
<div align="center">
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
document.write("<div data-pw-desk='leaderboard_btf'></div><div data-pw-mobi='leaderboard_btf'></div>");
}
else
{
document.write("<div data-pw-desk='leaderboard_btf'></div><div data-pw-mobi='leaderboard_btf'></div>");
}
</script>
</div>
<BR><BR>
<div id="footer_search">
<form action="https://www.google.com" id="cse-search-box">
  <div>
    <input type="hidden" name="cx" value="partner-pub-1809268078385119:5398998522" />
    <input type="hidden" name="ie" value="UTF-8" />
    <input type="text" name="q" size="36" />
    <input type="submit" name="sa" value="Search" />
  </div>
</form>
<script type="text/javascript" src="https://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en"></script>
</div>
<BR>
<table id="footer_menu"><tr><td> 
<span id="footer_column1">
	<a href="/study.php"><font color="#F48F0C">Homework</font></a><br>	
		<a href="/animals.php">Animals</a><br>
		<a href="/kidsmath/">Math</a><br>
	    <a href="/history/">History</a><br>	
		<a href="/biography/">Biography</a><br>
		<a href="/money/">Money and Finance</a><br> 
	<br>
			<font color="#F48F0C">Biography</font><br>	
		  <a href="/history/art/">Artists</a><br>
		  <a href="/history/civil_rights/">Civil Rights Leaders</a><br>
		  <a href="/biography/entrepreneurs/">Entrepreneurs</a><br>
		  <a href="/biography/explorers/">Explorers</a><br>
		  <a href="/biography/scientists/scientists_and_inventors.php">Inventors and Scientists</a><br>
		  <a href="/biography/women_leaders/">Women Leaders</a><br>
		  <a href="/biography/world_leaders/">World Leaders</a><br>
		  <a href="/biography/uspresidents/">US Presidents</a><br>
		  <br>
</span>	<span id="footer_column2"> 
          <a><font color="#F48F0C">US History</font></a><br>
		  <a href="/history/native_americans.php">Native Americans</a><BR>
		  <a href="/history/colonial_america/">Colonial America</a><br>
          <a href="/history/american_revolution.php">American Revolution</a><BR>
		  <a href="/history/us_1800s/industrial_revolution.php">Industrial Revolution</a><BR>  
          <a href="/history/civil_war.php">American Civil War</a><BR>
          <a href="/history/westward_expansion/">Westward Expansion</a><BR>
		  <a href="/history/us_1900s/great_depression.php">The Great Depression</a><BR>
		  <a href="/history/civil_rights/">Civil Rights Movement</a><BR>
		  <a href="/history/us_1800s/">Pre-1900s</a><BR>
          <a href="/history/us_1900s/">1900 to Present</a><BR>
		  <a href="/history/us_government.php">US Government</a><BR>
          <a href="/geography/us_states/">US State History</a><BR>	
		<br> 
		<a href="/science/"><font color="#F48F0C">Science</font></a><br>
        <a href="/science/biology/">Biology</a><br>
		<a href="/science/chemistry/">Chemistry</a><br>	
		<a href="/science/earth_science/">Earth Science</a><br>							
		<a href="/science/physics/">Physics</a><br>	
	<BR>	
</span>	<span id="footer_column3">  
          <a><font color="#F48F0C">World History</font></a><br>
		  <a href="/history/africa/">Ancient Africa</a><BR>						
          <a href="/history/china/ancient_china.php">Ancient China</a><br>
          <a href="/history/ancient_egypt.php">Ancient Egypt</a><br>
          <a href="/history/ancient_greece.php">Ancient Greece</a><br>
          <a href="/history/mesopotamia/ancient_mesopotamia.php">Ancient Mesopotamia</a><br>		  
          <a href="/history/ancient_rome.php">Ancient Rome</a><br>
          <a href="/history/middle_ages_timeline.php">Middle Ages</a><br>
          <a href="/history/islam/">Islamic Empire</a><BR>		  
          <a href="/history/renaissance.php">Renaissance</a><br>
          <a href="/history/aztec_maya_inca.php">Aztec, Maya, Inca</a><br>
		  <a href="/history/french_revolution/">French Revolution</a><br>
          <a href="/history/world_war_i/">World War 1</a><br>
          <a href="/history/world_war_ii/">World War 2</a><br>
          <a href="/history/cold_war/summary.php">Cold War</a><br>
          <a href="/history/art/">Art History</a><br>	
         <br>
	 
</span>	
<span id="footer_column4">
	 <a href="/geography/"><font color="#F48F0C">Geography</font></a><br>
					<a href="/geography/usgeography.php">United States</a><br>
					<a href="/geography/africa.php">Africa</a><br>
					<a href="/geography/asia.php">Asia</a><br>
					<a href="/geography/centralamerica.php">Central America</a><br>
					<a href="/geography/europe.php">Europe</a><br>
					<a href="/geography/middleeast.php">Middle East</a><br>
					<a href="/geography/northamerica.php">North America</a><br>
					<a href="/geography/oceania.php">Oceania</a><br>
					<a href="/geography/southamerica.php">South America</a><br>
					<a href="/geography/southeastasia.php">Southeast Asia</a><br>	 
<br>
     <a><font color="#F48F0C">Fun Stuff</font></a><br>	
		       <a href="/games/">Educational Games</a><br>
			   <a href="/holidays/kids_calendar.php">Holidays</a><BR>	
			   <a href="/jokes/">Jokes for Kids</a><br>	
			   <a href="/movies.php">Movies</a><br>	
			   <a href="/music.php">Music</a><br>  
			   <a href="/sports.php">Sports</a><br>	

</span> 
	 </td></tr>
<div align="center"><img src="/graphics/ducksters_footer_1.gif" width="745" height="101" alt="" title="" />	</div> 
	 </table>
<BR><BR>
<a href="/about.php">About Ducksters</a>&nbsp;<a href="/privacy_policy.php"><b><font color="#008000">Privacy Policy</b></a></font>&nbsp;
<script type="text/javascript">
var title_1 = document.title;
var location_1 = document.location.href;
document.write ("<a href='/citation.php?title=" + title_1 + "&location=" + location_1 + "'>Cite this Page</a>");
</script>&nbsp;
<BR><BR>
Follow us on <a href="https://www.facebook.com/pages/Ducksters/103074613109209"><img src="/facebook_24.png" width="24" height="24" alt="Ducksters Facebook" title="" /></a> or <a href="https://www.twitter.com/DuckstersKids"><img src="/twitter_24.png" width="24" height="24" alt="Ducksters Twitter" title="" /></a>
<BR><BR>
This site is a product of TSI (Technological Solutions, Inc.), Copyright 2019, All Rights Reserved.
By using this site you agree to the
<a href="/termsofuse.php">Terms of Use.</a>
<BR><BR>
<script type="text/javascript">
var title_1 = document.title;
var location_1 = document.location.href;
document.write ("<a href='/citation.php?title=" + title_1 + "&location=" + location_1 + "'>Cite this Page</a>");
</script>
<BR><BR>
</div>
</div>             

</body>
</html>
