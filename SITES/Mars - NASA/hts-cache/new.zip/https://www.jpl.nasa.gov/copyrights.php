<!DOCTYPE html>
<!--[if IE 9]> <html class="no-js ie ie9" lang="en"> <![endif]-->
<!--[if IE 8]> <html class="no-js ie ie8" lang="en"> <![endif]-->
<html>
  <!-- START HEADER: "DEFAULT" -->
  <head>
    <meta charset='utf-8'>
    <!-- Always force latest IE rendering engine or request Chrome Frame -->
    <meta content='IE=edge,chrome=1' http-equiv='X-UA-Compatible'>
	  <meta content='width=device-width, initial-scale=1.0' name='viewport'>	  <title>Copyrights</title>
    <link href="/assets/stylesheets/manifest.css" rel="stylesheet" type="text/css" media="all" />
    <link href="/assets/stylesheets/print.css" rel="stylesheet" type="text/css" media="print" />
    <script src="/assets/javascripts/public_manifest.js" type="text/javascript"></script>
    <script src="/assets/javascripts/vendor/jquery.fancybox.js" type="text/javascript"></script>
    <script src="/assets/javascripts/vendor/jquery.fancybox-thumbs.js" type="text/javascript"></script>
	    </head>
  <body class='light_background logged_out mobile_menu' id='copyrights'>
    <!--[if lt IE 9]>
      <div class='browsehappy' style='font-size: 30px; color: white; position:absolute; top: 0; margin: 0; height: 3000px; width: 100%; background: #000; z-index: 10000; padding: 5%;'>
        You are using an
        <strong>outdated</strong>
        browser. Please
        <a href='http://browsehappy.com/'>click here</a>
        to upgrade or change your browser.
      </div>
    <![endif]-->
  	<div id='main_container'>
        <div id='site_body'>
          <div class='site_header_area'>
            <header class='site_header'>
              <div class='brand_area'>
                <div class='brand1'>
                  <a class='nasa_logo' href='http://www.nasa.gov' title='NASA'>NASA</a>
                </div>
                <div class='brand2'>
                  <div class='jpl_logo'>
                    <a href='//www.jpl.nasa.gov/' id='jpl_logo' title='Jet Propulsion Laboratory'>Jet Propulsion Laboratory</a>
                  </div>
                  <div class='caltech_logo'>
                    <a href='http://www.caltech.edu/' id='caltech_logo' title='California Institute of Technology' target='_blank'>California Institute of Technology</a>
                  </div>
                </div>
                <img alt='' class='print_only print_logo' src='/assets/images/logo_nasa_trio_black@2x.png'>
              </div>
              <a class='visuallyhidden focusable' href='#main'>Skip Navigation</a>
              <div class='nav_area'>
                <a class='menu_button' href='javascript:void(0);' id='menu_button' title='menu button'>
                  <span class='menu_icon'>menu and search</span>
                </a>
              </div>
            </header>
          </div>
          <div class='main_nav_overlay'>
            <div class='modal_menu'>
              <header class='site_header clearfix'>
                <div class='brand_area'>
                  <div class='brand1'>
                    <a class='nasa_logo' href='http://www.nasa.gov' title=''></a>
                  </div>
                  <div class='brand2'>
                    <div class='jpl_logo'>
                      <a class='' href='' id='jpl_logo' title=''>Jet Propulsion Laboratory</a>
                    </div>
                    <div class='caltech_logo'>
                      <a class='' href='' id='caltech_logo' title=''>California Institute of Technology</a>
                    </div>
                  </div>
  				        <img alt='' class='print_only print_logo' src='/assets/images/logo_nasa_trio_black@2x.png'>
                </div>
                <a class='modal_close' id='modal_close' title='close menu'>close menu</a>
                <div class='nav_area'>
                  <a class='menu_button modal_close' href='javascript:void(0);' id='menu_button' title='menu icon'>
                    <span class='menu_icon'>menu</span>
                  </a>
                </div>
              </header>
  			                  <section class='navigation_area'>
              <div class='grid_layout'>
                <div class='directory'>
                  <form action='/search.php' class='overlay_search top_search'>
                    <input class='search_field' name='q' onblur="this.placeholder = 'search'" onfocus="this.placeholder = ''" placeholder='search' type='text' value=''>
                    <input class='search_submit' type='submit' value=''>
                  </form>
                  <div class='nav_item'>
                    <div class='arrow_box'>
                      <span class='arrow_down'></span>
                    </div>
                    <h3 class='nav_title'>
                      <a href="/about">about JPL</a>
                    </h3>
                    <ul class='subnav'>
                      <li>
                        <a href="/about">about JPL</a>
                      </li>
                      <li>
                        <a href="/about/exec.php">executive council</a>
                      </li>
                      <li>
                        <a href="/about/history.php">history</a>
                      </li>
                      <li>
                        <a href="/about/reports.php">annual reports</a>
                      </li>
                      <li>
                        <a href="/contact_JPL.php">contact us</a>
                      </li>
                      <li>
                        <a href="/opportunities/">opportunities</a>
                      </li>
                    </ul>
                  </div>
                  <div class='gradient_line'></div>
                  <div class='nav_item'>
                    <div class='arrow_box'>
                      <span class='arrow_down'></span>
                    </div>
                    <h3 class='nav_title'>
                      <a href="/events">public events</a>
                    </h3>
                    <ul class='subnav'>
                      <li>
                        <a href="/events">overview</a>
                      </li>
                      <li>
                        <a href="/events/tours/views">tours</a>
                      </li>
                      <li>
                        <a href="/events/lectures.php">lecture series</a>
                      </li>
                      <li>
                        <a href="/events/speakers-bureau.php">speakers bureau</a>
                      </li>
                      <li>
                        <a href="/events/team-competitions.php">team competitions</a>
                      </li>
                      <li>
                        <a href="/events/special-events.php">special events</a>
                      </li>
                    </ul>
                  </div>
                  <div class='gradient_line'></div>
                  <div class='nav_item'>
                    <div class='arrow_box'>
                      <span class='arrow_down'></span>
                    </div>
                    <h3 class='nav_title'>
                      <a href="/edu/">education</a>
                    </h3>
                    <ul class='subnav'>
                      <li>
                        <a href="/edu/intern/">Intern</a>
                      </li>
                      <li>
                        <a href="/edu/learn/">Learn</a>
                      </li>
                      <li>
                        <a href="/edu/teach/">Teach</a>
                      </li>
                      <li>
                        <a href="/edu/news/">News</a>
                      </li>
                      <li>
                        <a href="/edu/events/">Events</a>
                      </li>
                    </ul>
                  </div>
				          <div class='gradient_line'></div>
                  <div class='nav_item'>
                    <div class='arrow_box'>
                      <span class='arrow_down'></span>
                    </div>
                    <h3 class='nav_title'>
                      <a href="/news">news</a>
                    </h3>
                    <ul class='subnav'>
                      <li>
                        <a href="/news">latest news</a>
                      </li>
                      <li>
                        <a href="/news/presskits.php">press kits</a>
                      </li>
                      <li>
                        <a href="/news/factsheets.php">fact sheets</a>
                      </li>
                      <li>
                        <a href="/news/mediainformation.php">media information</a>
                      </li>
                      <li>
                        <a href="http://blogs.jpl.nasa.gov">blog</a>
                      </li>
                    </ul>
                  </div>
                  <div class='gradient_line'></div>
                  <div class='nav_item'>
                    <div class='arrow_box'>
                      <span class='arrow_down'></span>
                    </div>
                    <h3 class='nav_title'>
                      <a href="/missions/">missions</a>
                    </h3>
                    <ul class='subnav'>
                      <li>
                        <a href="/missions/?type=current">current</a>
                      </li>
                      <li>
                        <a href="/missions/?type=past">past</a>
                      </li>
                      <li>
                        <a href="/missions/?type=future">future</a>
                      </li>
                      <li>
                        <a href="/missions/?type=proposed">proposed</a>
                      </li>
                      <li>
                        <a href="/missions">all</a>
                      </li>
                    </ul>
                  </div>
                  <div class='gradient_line'></div>
                  <div class='nav_item'>
                    <div class='arrow_box'>
                      <span class='arrow_down'></span>
                    </div>
                    <h3 class='nav_title'>
                      <a href="/spaceimages">galleries</a>
                    </h3>
                    <ul class='subnav'>
                      <li>
                        <a href="/spaceimages">images</a>
                      </li>
                      <li>
                        <a href="/videos">videos</a>
                      </li>
                      <li>
                        <a href="/infographics">infographics</a>
                      </li>
                      <li>
                        <a href="/multimedia/audio.php">audio</a>
                      </li>
          					  <li>
          						  <a href="/apps/">apps</a>
          					  </li>
                    </ul>
                  </div>
                  <div class='gradient_line'></div>
                  <div class='nav_item centered'>
                    <h3 class='nav_title'><a href="/social">Follow JPL</a></h3>
                    <div class='social_icons'>
                      <!-- AddThis Button BEGIN -->
                      <div class='addthis_toolbox addthis_default_style addthis_32x32_style'>
                        <a addthis:userid='NASAJPL' class='addthis_button_facebook_follow icon'></a>
                        <a addthis:userid='NASAJPL' class='addthis_button_twitter_follow icon'></a>
                        <a addthis:userid='JPLnews' class='addthis_button_youtube_follow icon'></a>
                        <a addthis:userid='nasajpl' class='addthis_button_instagram_follow icon'></a>
                        <a class='icon all_icon' href='/social'>
                          <span>All</span>
                        </a>
                      </div>
                    </div>
                  </div>
                  <form action='/search.php' class='overlay_search'>
                    <input class='search_field' name='q' onblur="this.placeholder = 'search'" onfocus="this.placeholder = ''" placeholder='search' type='text' value=''>
                    <input class='search_submit' type='submit' value=''>
                  </form>
                </div>
              </div>
            </section>            </div>
          </div>
          <a name='main'></a>
          <div id='page'>
          <!-- END HEADER: "DEFAULT" -->	  <!-- START CONTENT -->
	  <div class='header_mask'></div>
	  <section class='content_page module'>
		<div class='grid_layout'>
		  <article>
			<header id='page_header'>
			  <h1 class='article_title'>
				Caltech/JPL Web Privacy Policy and Important Notices
			  </h1>
			</header>
			<div class='clearfix' id='primary_column'>
			  <div class='wysiwyg_content'>
				<p>
				  Unless otherwise noted, Web sites in the domain
				  <strong>jpl.nasa.gov</strong>
				  are managed by the California Institute of Technology in support of the missions and research programs that its Jet Propulsion Laboratory conducts for NASA. This document describes Caltech/JPL's policies on privacy, security, accessibility, linking and copyright.
				</p>
				<ul class='bullet_list'>
				  <li>
					<a href='javascript:void(0)' onclick="mb_utils.slideToElement('#privacy', -140)">
					  Privacy Policy
					</a>
				  </li>
				  <li>
					<a href='javascript:void(0)' onclick="mb_utils.slideToElement('#security', -140)">
					  Security Notice
					</a>
				  </li>
				  <li>
					<a href='javascript:void(0)' onclick="mb_utils.slideToElement('#accessibility', -140)">
					  Accessibility Statement
					</a>
				  </li>
				  <li>
					<a href='javascript:void(0)' onclick="mb_utils.slideToElement('#linking', -140)">
					  Linking Policy and Disclaimer of Endorsement
					</a>
				  </li>
				  <li>
					<a href='javascript:void(0)' onclick="mb_utils.slideToElement('#copyright', -140)">
					  Copyright
					</a>
				  </li>
				</ul>
				<br>
				<div class='gradient_line'></div>
				<h2 id='privacy'>
				  Privacy Policy
				</h2>
				<p>
				  This notice provides Caltech/JPL's policy regarding the nature, purpose, use and sharing of any information collected via Web sites in the jpl.nasa.gov domain. NASA's privacy policy is located
				  <a href='http://www.nasa.gov/about/highlights/HP_Privacy.html'>here</a>.
				</p>
				<p>
				  The information you provide on a Caltech/JPL Web site will be used only for its intended purpose. We will protect your information consistent with the principles of the Privacy Act, the e-Government act of 2002, the Federal Records Act and, as applicable, the Freedom of Information Act. This notice is posted pursuant to the California Online Privacy Protection Act of 2003 (Cal Bus & Prof Code Sections 22575-22579). Changes to this notice may occur as necessary and will be noted here.
				</p>
				<p>Submitting information is strictly voluntary. By doing so, you are giving Caltech/JPL your permission to use the information for the intended purpose. In addition, Caltech/JPL may also furnish this information to NASA at NASA's request. If you do not want to give Caltech/JPL permission to use your information, simply do not provide it. However, not providing certain information may result in Caltech/JPL's inability to provide you with the information or services you desire.</p>
				<p>There are several types of information we collect. These include:</p>
				<ul class='bullet_list'>
				  <li>
					<a href='javascript:void(0)' onclick="mb_utils.slideToElement('#metrics', -140)">Automatically Collected Information</a>
				  </li>
				  <li>
					<a href='javascript:void(0)' onclick="mb_utils.slideToElement('#cookies', -140)">Information Collected for Tracking and Customization (Cookies)</a>
				  </li>
				  <li>
					<a href='javascript:void(0)' onclick="mb_utils.slideToElement('#personal', -140)">Personal Information</a>
				  </li>
				  <li>
					<a href='javascript:void(0)' onclick="mb_utils.slideToElement('#coppa', -140)">Information from Children</a>
				  </li>
				</ul>
				<p>Caltech/JPL never collects information for commercial marketing. We will only share your information with a government agency if it relates to that agency, or as otherwise required by law. Caltech/JPL never creates individual profiles or gives your information to any private organization.</p>
				<h3 id='metrics'>Automatically Collected Information</h3>
				<p>
				  If you sign up to receive email information from JPL such as newsletters, mission bulletins or news releases, you will be asked to provide basic contact information such as your name, email address, email format preference (HTML vs. text), state/province of residence and occupation. In addition, from time to time you may be invited to participate in optional surveys about the information that JPL provides and your interests in space exploration. This information is only used for the following purposes: (a) to help customize information for you that you will find most relevant; and (b) to help us gather broad demographic information for aggregate use in order to improve our web site and information services. Some of this information is gathered and stored on a Web site,
				  <a href='http://www.icontact.com/'>http://www.icontact.com/</a>
				  , operated by a JPL subcontractor that adheres to this policy.
				</p>
				<p>
				  We collect and temporarily store certain technical information about your visit for use in site management and security purposes. This information includes:
				</p>
				<ul class='bullet_list'>
				  <li>
					The Internet domain from which you access our Web site (for example, "xcompany.com" if you use a private Internet access account, or "yourschool.edu" if you connect from an educational domain);
				  </li>
				  <li>
					The IP address (a unique number for each computer connected to the Internet) from which you access our Web site;
				  </li>
				  <li>
					The type of browser (e.g., Netscape, Internet Explorer, Firefox) used to access our site;
				  </li>
				  <li>
					The operating system (Windows, Unix, Macintosh) used to access our site;
				  </li>
				  <li>
					The date and time you access our site;
				  </li>
				  <li>
					The URLs of the pages you visit;
				  </li>
				  <li>
					Your username, if it was used to log in to the Web site; and
				  </li>
				  <li>
					If you visited this Web site from another Web site, the URL of the forwarding site.
				  </li>
				</ul>
				<p>This information is only used to help us make our site more useful for you. With this data we learn about the number of visitors to our site and the types of technology our visitors use.</p>
				<p>Except for authorized law enforcement investigations, no attempts are made to identify individual users or their usage habits. Raw data logs are retained temporarily as required for security and site management purposes only.</p>
				<h3 id='cookies'>Information Collected for Tracking and Customization (Cookies)</h3>
				<p>
				  A cookie is a small file that a Web site transfers to your computer to allow it to remember specific information about your session while you are connected. Your computer will only share the information in the cookie with the Web site that provided it, and no other Web site can request it. There are two types of cookies, session and persistent. Session cookies last only as long as your Web browser is open. Once you close your browser, the cookie disappears. Persistent cookies store information on your computer for longer periods of time.
				</p>
				<p>Caltech/JPL Web sites may use session cookies for technical purposes such as to enable better navigation through the site, or to allow you to customize your preferences for interacting with the site. A few Caltech/JPL Web sites may also make use of persistent cookies to remember you between visits so, for example, you can save your customized preference settings for future visits. Each Caltech/JPL site using persistent cookies identifies itself as doing so.</p>
				<p>At no time is your private information, whether stored in persistent cookies or elsewhere, shared with third parties who have no right to that information. If you do not wish to have session or persistent cookies stored on your machine, you can turn them off in your browser. However, this may affect the functioning of some Caltech/JPL Web sites.</p>
				<h3 id='personal'>Personal Information</h3>
				<p>
				  If you choose to provide us with personal information, through such methods as completing a form or sending us an email, we will use that information to respond to your message and to help us get you the information or services you have requested.
				</p>
				<p>Remember that email isn't necessarily secure. You should never send sensitive or personal information like your Social Security number in an email. Use postal mail or secure Web sites instead.</p>
				<p>Some of our Web sites ask visitors who request specific information to fill out a registration form. Other information collected at Web sites through questionnaires, feedback forms or other means, enables us to determine visitors' interests, with the goal of providing better service to our visitors.</p>
				<h3 id='coppa'>Interaction with Children</h3>
				<p>
				  The
				  <a href='http://www.ftc.gov/ogc/coppa1.htm'>Children's Online Privacy Protection Act (COPPA)</a>
				  governs operators of Web sites directed toward children under 13 years old that collect information from the children, or operators who know that they collect information from children under the age of 13. Requirements include posting a notice stating the information collected and its intended use; obtaining verifiable consent from a child's parent or guardian before collecting, using or disclosing personal information from a child under the age of 13; and giving the parent or guardian the ability to review the submitted information and to prevent further collection or use of the information.
				</p>
				<p>We collect no information about you or your child, other than that detailed in the previous section, when you visit our web site unless you choose to provide information to us. When a Caltech/JPL Web site needs to collect information about a child under 13 years old, COPPA required information and instructions will be provided by the specific Web page that collects information about the child. The Web page will specify exactly what the information will be used for, who will see it and how long it will be kept.</p>
				<p>There are several exceptions that permit collection of a child's personal information without receiving parental consent in advance:</p>
				<ul class='bullet_list'>
				  <li>Collecting the child's name and parent's name and email address to provide the parents with notice and to seek consent for communications with the child.</li>
				  <li>Collecting the child's email address in order to respond to a one time request from a child.</li>
				  <li>Collecting the child's email address to respond more than once to a child's request; i.e., subscription to a newsletter, so long as the parent or guardian is notified after the first communication from the child to give the parent or guardian the opportunity to opt out of the information submitted by the child and cease communications from the Web site operator.</li>
				  <li>Collecting the child's information in order to protect the safety of a child who is participating on the site; i.e., in a chat room. The operator needs to give notice to the parent.</li>
				  <li>Collecting the child's information for the sole purpose of protecting the Web site, take precautions against liability or to respond to law enforcement; i.e., in the case of a Web site compromise.</li>
				</ul>
				<p>Personal information about a child under 13 years of age may be needed to respond to his/her communication to us, such as to receive a poster or to acquire information for a school project. Personal information about your child will be destroyed immediately upon completion of its intended purpose. On rare occasions, it may be determined that a communication from a child under 13 years old should be maintained for historical purposes. Should such an occasion occur, Caltech/JPL will obtain the necessary consent from the child's parent.</p>
				<p>Finally, we provide many on-line tools and services in support of Caltech/JPL's mission. A child under 13 years old may inadvertently provide personal information to one of these services. If this should happen, the information about the child will be deleted immediately upon discovery.</p>
				<br>
				<div class='gradient_line'></div>
				<h2 id='security'>
				  Web Site Security Notice
				</h2>
				<p>
				  For site security purposes and to ensure that this Web service remains available to all users, this computer system employs software programs that monitor network traffic to identify unauthorized attempts to upload or change information,. Anyone using this system expressly consents to such monitoring and is advised that if such monitoring reveals evidence of possible abuse or criminal activity, such evidence may be provided to appropriate law enforcement officials.
				</p>
				<p>
				  Unauthorized attempts to upload or change information on Caltech/JPL servers are strictly prohibited and may be punishable by law, including under the Computer Fraud and Abuse Act of 1986, and the National Information Infrastructure Protection Act of 1996.
				</p>
				<br>
				<div class='gradient_line'></div>
				<h2 id='accessibility'>
				  Accessibility Statement
				</h2>
				<p>
				  We continually strive to ensure the pages on this Web site are accessible to individuals with disabilities in accordance with <a href='http://www.section508.gov'>Section 508 of the Rehabilitation Act</a>. If you have questions about accessibility at JPL or would like to report issues with the accessibility of this site or other JPL sites, please let us know by visiting our <a href="contact_JPL.php">feedback page</a>.
				</p>
				<p>
				  Documents on Caltech/JPL Web sites are presented in many formats. These formats are generally accessible to users using screen reading software. Some files on this Web site may be posted as Adobe Acrobat Portable Document Format (PDF) files. Adobe provides their
				  <a href='http://www.adobe.com/products/acrobat/alternate.html'>Acrobat Reader</a>
				  software as a free download.
				</p>
				<br>
				<div class='gradient_line'></div>
				<h2 id='linking'>
				  Linking Policy and Disclaimer of Endorsement
				</h2>
				<p>Caltech/JPL Web pages link to many Web sites created and maintained by other public and/or private organizations. Caltech/JPL provides links to these sites as a service to our users. The presence of a link is not a Caltech/JPL endorsement of the site.</p>
				<p>When users follow a link to an outside Web site, they are leaving Caltech/JPL and are subject to the privacy and security policies of the owners/sponsors of the outside Web site(s). Caltech/JPL is not responsible for the privacy or information collection practices of non-Caltech/JPL sites.</p>
				<br>
				<div class='gradient_line'></div>
				<h2 id='copyright'>
				  Copyright Status
				</h2>
				<p>
				  JPL-authored documents are sponsored by NASA under Contract NAS7-030010. All documents available from this server may be protected under the U.S. and Foreign Copyright Laws. Permission to reproduce may be required. For information on the use of images from JPL's Web sites, please see our
				  <a href='http://www.jpl.nasa.gov/imagepolicy/'>image use policy</a>.
				</p>
				<p>
				  For information on possible copyright infringement, please visit Caltech's
				  <a href='http://www.caltech.edu/copyright/'>"Copyright Infringement"</a>
				  page.
				</p>
				<p></p>
				<p> </p>
			  </div>
			</div>
		  </article>
		</div>
	  </section>
	  <!-- END CONTENT -->
          <!-- START FOOTER: "DEFAULT" -->
        </div>
        <footer class='clearfix' id='site_footer'>
          <section class='upper_footer'>
            <div class='grid_layout'>
              <div class='footer_newsletter'>
                <h2>Get the Newsletter</h2>
                <form action='/signup/index.php' class='submit_newsletter' method="post">
                  <input class='email_field' name='email_field' onblur="this.placeholder = 'enter email address'" onfocus="this.placeholder = ''" placeholder='enter email address' type='email' value=''>
                  <input class='email_submit' type='submit' value=''>
                </form>
              </div>
              <div class='gradient_line_divider'></div>
              <div class='share'>
                <h2>Follow JPL</h2>
                <div class='social_icons'>
                  <!-- AddThis Button BEGIN -->
                  <div class='addthis_toolbox addthis_default_style addthis_32x32_style'>
                    <a addthis:userid='NASAJPL' class='addthis_button_facebook_follow icon'></a>
                    <a addthis:userid='NASAJPL' class='addthis_button_twitter_follow icon'></a>
                    <a addthis:userid='JPLnews' class='addthis_button_youtube_follow icon'></a>
                    <a addthis:userid='nasajpl' class='addthis_button_instagram_follow icon'></a>
                    <a class='icon all_icon' href='/social'>
                      <span>All</span>
                    </a>
                  </div>
                  <script>
                    addthis_loader.init("//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5429eeee4e460927", {follow: true})
                  </script>
                </div>
              </div>
            </div>
            <div class='gradient_line'></div>
          </section>
		      		  <section class='sitemap'>
            <div class='grid_layout'>
              <div class='sitemap_directory'>
                <div class='sitemap_block'>
                  <div class='footer_sitemap_item'>
                    <h3 class='sitemap_title'>
                      about JPL
                    </h3>
                    <ul class='subnav'>
                      <li>
                        <a href="/about/">About JPL</a>
                      </li>
                      <li>
                        <a href='https://www.jpl.nasa.gov/jpl2025/vision/'>JPL Vision</a>
                      </li>
                      <li>
                        <a href="/about/exec.php">Executive Council</a>
                      </li>
                      <li>
                        <a href="/about/history.php">History</a>
                      </li>
                      <li>
                        <a href="/about/reports.php">Annual Reports</a>
                      </li>
                      <li>
                        <a href="/contact_JPL.php">Contact Us</a>
                      </li>
                      <li>
                        <a href="/opportunities/">Opportunities</a>
                      </li>
                      <li>
                        <a href="https://thejplstore.com" target="_blank">JPL Online Store</a>
                      </li>
                      <li>
                        <a href="/acquisition/">Doing Business with JPL</a>
                      </li>
                    </ul>
                  </div>
                  <div class='footer_sitemap_item'>
                    <h3 class='sitemap_title'>
                      missions
                    </h3>
                    <ul class='subnav'>
                      <li>
                        <a href="/missions/?type=current">Current</a>
                      </li>
                      <li>
                        <a href="/missions/?type=past">Past</a>
                      </li>
                      <li>
                        <a href="/missions/?type=future">Future</a>
                      </li>
                      <li>
                        <a href="/missions/?type=proposed">Proposed</a>
                      </li>
                      <li>
                        <a href="/missions">All</a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class='sitemap_block'>
                  <div class='footer_sitemap_item'>
                    <h3 class='sitemap_title'>
                      education
                    </h3>
                    <ul class='subnav'>
                      <li>
                        <a href="/edu/intern/">Intern</a>
                      </li>
                      <li>
                        <a href="/edu/learn/">Learn</a>
                      </li>
                      <li>
                        <a href="/edu/teach/">Teach</a>
                      </li>
                      <li>
                        <a href="/edu/news/">News</a>
                      </li>
                      <li>
                        <a href="/edu/events/">Events</a>
                      </li>
                    </ul>
                  </div>
                  <div class='footer_sitemap_item'>
                    <h3 class='sitemap_title'>
                      news
                    </h3>
                    <ul class='subnav'>
                      <li>
                        <a href="/news">Latest News</a>
                      </li>
                      <li>
                        <a href="/news/presskits.php">Press Kits</a>
                      </li>
                      <li>
                        <a href="/news/factsheets.php">Fact Sheets</a>
                      </li>
                      <li>
                        <a href="/news/mediainformation.php">Media Information</a>
                      </li>
                      <li>
                        <a href="/universe/">Universe Newspaper</a>
                      </li>
                    </ul>
                  </div>
                  <div class='footer_sitemap_item'>
                    <h3 class='sitemap_title'>
                      public events</h3>
                    <ul class='subnav'>
                      <li>
                        <a href="/events/">Overview</a>
                      </li>
                      <li>
                        <a href="/events/tours/views/">Tours</a>
                      </li>
                      <li>
                        <a href="/events/lectures.php">Lecture Series</a>
                      </li>
                      <li>
                        <a href="/events/speakers-bureau.php">Speakers Bureau</a>
                      </li>
                      <li>
                        <a href="/events/team-competitions.php">Team Competitions</a>
                      </li>
                      <li>
                        <a href="/events/special-events.php">Special Events</a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class='sitemap_block'>
                  <div class='footer_sitemap_item'>
                    <h3 class='sitemap_title'>
                      Our Sites
                    </h3>
                    <ul class='subnav'>
                      <li>
                        <a href="/asteroidwatch/">Asteroid Watch</a>
                      </li>
                      <li>
                        <a href="https://solarsystem.nasa.gov/basics/" target="_blank">Basics of Spaceflight
                      </li>
                      <li>
                        <a href="http://saturn.jpl.nasa.gov/index.cfm">Cassini - Mission to Saturn</a>
                      </li>
                      <li>
                        <a href="http://climate.nasa.gov">Earth / Global Climate Change</a>
                      </li>
                      <li>
                        <a href="http://planetquest.jpl.nasa.gov">Exoplanet Exploration</a>
                      </li>
                      <li>
                        <a href="/missions/juno/">Juno - Mission to Jupiter</a>
                      </li>
                      <li>
                        <a href="https://mars.nasa.gov/">Mars Exploration</a>
                      </li>
                      <li>
                        <a href="http://scienceandtechnology.jpl.nasa.gov/">Science and Technology</a>
                      </li>
                      <li>
                        <a href="http://solarsystem.nasa.gov/">Solar System Exploration</a>
                      </li>
                      <li>
                        <a href="https://eyes.nasa.gov/">NASA's Eyes</a>
                      </li>
                      <li>
                        <a href="http://www.spitzer.caltech.edu/">Spitzer Space Telescope</a>
                      </li>
                      <li>
                        <a href="https://voyager.jpl.nasa.gov/">Voyager Interstellar Mission</a>
                      </li>
                    </ul>
                  </div>
                  <div class='footer_sitemap_item'>
                    <h3 class='sitemap_title'>
                      galleries
                    </h3>
                    <ul class='subnav'>
                      <li>
                        <a href="/spaceimages/">JPL Space Images</a>
                      </li>
                      <li>
                        <a href="/videos/">Videos</a>
                      </li>
                      <li>
                        <a href="/infographics/">Infographics</a>
                      </li>
                      <li>
                        <a href="https://photojournal.jpl.nasa.gov/">Photojournal</a>
                      </li>
                      <li>
                        <a href="http://www.nasaimages.org/">NASA Images</a>
                      </li>
                      <li>
                        <a href="/apps/">Mobile Apps</a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class='sitemap_block'>
                  <div class='footer_sitemap_item'>
                    <h3 class='sitemap_title'>
                      Follow JPL
                    </h3>
                    <ul class='subnav'>
                      <li>
                        <a href="/signup/">Newsletter</a>
                      </li>
                      <li>
                        <a href="https://www.facebook.com/NASAJPL">Facebook</a>
                      </li>
                      <li>
                        <a href="http://twitter.com/NASAJPL">Twitter</a>
                      </li>
                      <li>
                        <a href="http://www.youtube.com/user/JPLnews">YouTube</a>
                      </li>
                      <li>
                        <a href="http://www.flickr.com/photos/nasa-jpl">Flickr</a>
                      </li>
                      <li>
                        <a href="http://instagram.com/nasajpl">Instagram</a>
                      </li>
                      <li>
                        <a href="https://www.linkedin.com/company/2004/">LinkedIn</a>
                      </li>
                      <li>
                        <a href="http://itunes.apple.com/podcast/hd-nasas-jet-propulsion-laboratory/id262254981">iTunes</a>
                      </li>
                      <li>
                        <a href="http://www.ustream.tv/nasajpl">UStream</a>
                      </li>
                      <li>
                        <a href="/rss/">RSS</a>
                      </li>
                      <li>
                        <a href="http://blogs.jpl.nasa.gov">Blog</a>
                      </li>
                      <li>
                        <a href="/onthego/">Mobile</a>
                      </li>
                      <li>
                        <a href="/social/">All Social Media</a>
                      </li>
                    </ul>
                  </div>
                  <div class='footer_sitemap_item'>
                    <h3 class='sitemap_title'>
                      NASA
                    </h3>
                    <ul class='subnav'>
                      <li>
                        <a href="http://jplwater.nasa.gov">NASA Water Cleanup</a>
                      </li>
                      <li>
                        <a href="http://www.hq.nasa.gov/office/pao/FOIA/agency/">FOIA</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class='gradient_line'></div>
          </section>
		      <section class='lower_footer'>
            <div class='nav_container'>
              <nav>
                <ul>
                  <li>
                    <a href='http://www.nasa.gov/' target='_blank'>NASA</a>
                  </li>
                  |
                  <li>
                    <a href='http://www.caltech.edu/' target='_blank'>Caltech</a>
                  </li>
                  |
                  <li>
                    <a href='/copyrights.php'>Privacy</a>
                  </li>
                  |
                  <li>
                    <a href='/imagepolicy'>Image Policy</a>
                  </li>
                  |
                  <li>
                    <a href='/faq.php'>FAQ</a>
                  </li>
                  |
                  <li>
                    <a href='/contact_JPL.php'>Feedback</a>
                  </li>
                </ul>
              </nav>
            </div>
            <div class='credits'>
              <span class='credits_manager'>Site Manager: Jon Nelson</span>
              <span class='credits_webmaster'>Webmasters: Tony Greicius, Luis Espinoza, Anil Natha</span>
            </div>
          </section>        </footer>
      </div>
    </div>
    <script src="/assets/javascripts/vendor/prefixfree.js" type="text/javascript"></script><script src="/assets/javascripts/vendor/prefixfree.jquery.js" type="text/javascript"></script><script id="_fed_an_ua_tag" type="text/javascript" src="https://dap.digitalgov.gov/Universal-Federated-Analytics-Min.js?agency=NASA&pua=UA-45212297-1&subagency=JPL&dclink=true&sp=search,s,q&sdor=false&exts=tif,tiff"></script>
<script type="text/javascript">
setTimeout(function(){var a=document.createElement("script");
var b=document.getElementsByTagName("script")[0];
a.src=document.location.protocol+"//script.crazyegg.com/pages/scripts/0025/5267.js?"+Math.floor(new Date().getTime()/3600000);
a.async=true;a.type="text/javascript";b.parentNode.insertBefore(a,b)}, 1);
</script>  </body>
  <!-- END FOOTER: "DEFAULT" --></html>