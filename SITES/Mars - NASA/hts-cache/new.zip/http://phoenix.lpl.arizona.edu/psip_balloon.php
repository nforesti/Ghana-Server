<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html lang="en">
	<!-- InstanceBegin codeOutsideHTMLIsLocked="false" -->
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<!-- InstanceBeginEditable name="docTitle" --><title>Phoenix Mars Mission - Education - PSIP</title><!-- InstanceEndEditable -->
	<link href='mars.css' rel=stylesheet type=text/css>
	<link href='error.css' rel=stylesheet type=text/css>
</head>

<body>
<div id="container">
<!--<div style="margin: 0px 0px 0px 6px;"><span style="color: #ffad43; font-weight:bold;"> The Phoenix Mars Mission website will be down for planned server maintenance on Tuesday, January 29. Expect periods of short downtime of 10 - 15 minutes between 8:00am - 5:00pm MST.</span></div>-->
<!--<div style="margin: 0px 0px 0px 6px;"><span style="color: #ffad43; font-weight:bold;">2/28/08 11:00AM MST: Due to an error with the websites database the search function is currently not working. The team is working on the issue and expects search functions back on February 29, 2008.</span></div>-->
<!--<div style="margin: 0px 0px 0px 6px;"><span style="color: #ffad43; font-weight:bold;"> The Phoenix Mars Mission website will be down due to building electrical work on Saturday, March 8. The website is expected to be back up on Sunday, March 9.</span></div>-->
	<div id="header">
		<img src="images/picHeader.gif" alt="Phoenix Mars Mission - NASA" width="770" height="129" border="0" usemap="#picHeader_Map" /><map name="picHeader_Map">
<area shape="rect" alt="" coords="684,46,751,103" href="http://www.nasa.gov/" title="NASA" target="_blank"/>
<area shape="rect" alt="" coords="0,0,770,129" href="index.php" title="PHOENIX MARS MISSION"/>
</map></div>
	<div id="nav"><a href="/mission.php" onmouseover="document.images['Mission'].src='images/btnMissionON.gif'" onfocus="document.images['Mission'].src='images/btnMissionON.gif'" onblur="document.images['Mission'].src='images/btnMissionON.gif'" onmouseout="document.images['Mission'].src='images/btnMission.gif'"><img name="Mission" src="images/btnMission.gif" alt="Mission" width=101 height=41 border=0></a><a href="/education.php" onmouseover="document.images['Education'].src='images/btnEducationON.gif'" onfocus="document.images['Education'].src='images/btnEducationON.gif'" onblur="document.images['Education'].src='images/btnEducationON.gif'" onmouseout="document.images['Education'].src='images/btnEducationON.gif'"><img name="Education" src="images/btnEducationON.gif" alt="Education" width=101 height=41 border=0></a><a href="/blogs.php" onmouseover="document.images['Blogs'].src='images/btnBlogsON.gif'" onfocus="document.images['Blogs'].src='images/btnBlogsON.gif'" onblur="document.images['Blogs'].src='images/btnBlogsON.gif'" onmouseout="document.images['Blogs'].src='images/btnBlogs.gif'"><img name="Blogs" src="images/btnBlogs.gif" alt="Blogs" width=101 height=41 border=0></a><a href="/news.php" onmouseover="document.images['News'].src='images/btnNewsON.gif'" onfocus="document.images['News'].src='images/btnNewsON.gif'" onblur="document.images['News'].src='images/btnNewsON.gif'" onmouseout="document.images['News'].src='images/btnNews.gif'"><img name="News" src="images/btnNews.gif" alt="News" width=101 height=41 border=0></a><a href="/gallery.php" onmouseover="document.images['Gallery'].src='images/btnGalleryON.gif'" onfocus="document.images['Gallery'].src='images/btnGalleryON.gif'" onblur="document.images['Gallery'].src='images/btnGalleryON.gif'" onmouseout="document.images['Gallery'].src='images/btnGallery.gif'"><img name="Gallery" src="images/btnGallery.gif" alt="Gallery" width=101 height=41 border=0></a></div><div id="nav2"><form action="search.php" method="get" name="search"><div class="key"><label for="search">Keyword Search:</label></div><input class="but" type="text" id="search" name="Keyword" label="Keyword Search" value="Search"/></form></div><div id="nav3"><a href="javascript:document.forms.search.submit()" onMouseOver="document.images['Go'].src='images/btnGoON.gif'" onfocus="document.images['Go'].src='images/btnGoON.gif'"  onMouseOut="document.images['Go'].src='images/btnGo.gif'" onblur="document.images['Go'].src='images/btnGo.gif'"><img name="Go" src="images/btnGo.gif" alt="Go" width="30" height="41" border="0" /></a></div>
<div id="main">
	<table summary="" cellpadding="0" cellspacing="0" border="0"><tr><td valign="top">
		<div id="left">
			<div id="blog">
			<div id="blogText">
					<div id="boxCont_edu" style="margin-bottom: 20px;">
						<div id="box">
							<div class=head>PSIP Resources</div>
							<ul>
								<li><a href="psip.php">Home</a></li>
								<li><b>Balloon Powered Lander</b></li>
								<li><a href="psip_ra.php">Tonka&reg; Robotic Arms</a></li>
								<li><a href="psip_board.php">Mars Bulletin Boards</a></li>
								<li><a href="psip_outreach.php">Outreach in Action</a></li>
								<li><a href="psip_lander.php">Phoenix Lander Model</a></li>
								<li><a href="psip_news.php">PSIP News Story</a></li>
								<li><a href="psip_mentor.php">PSIP Mentor Interview</a></li>
							</ul>
						</div>
					</div>
			<h1>Balloon Powered Lander</h1>
			Check out the balloon powered Phoenix Mars Lander created by one of our PSIP teams. There are three models that can be downloaded. The <a href="very_simple_lander_model.pdf">first</a> is very easy, the <a href="simple_lander_model.pdf">second</a> is slightly harder and the <a href="lander_model.pdf">third</a> is the most complicated. Check out the video below to see the lander in action.<br /><object width="425" height="366"><param name="movie" value="http://www.youtube.com/v/nwcoL5RIOkU"></param><param name="wmode" value="transparent"></param><embed src="http://www.youtube.com/v/nwcoL5RIOkU" type="application/x-shockwave-flash" wmode="transparent" width="425" height="366"></embed></object></p>
		</div>
	
		</td><td valign="top">
		<div id="right">
			<div id="rightNav">
				<div class=nav><a href="kids.php" onFocus="" onBlur="" onMouseOver="document.images['Kids'].src='images/divNavON.gif'" onMouseOut="document.images['Kids'].src='images/divNav.gif'"><img name="Kids" src="images/divNav.gif" alt="" width=16 height=23 border=0 align=left hspace=0><img src="images/spaclear.gif" alt="" width=64 height=4 border=0><br>
				Just for Kids</a></div>
				<div id="divR"><img src="images/spaclear.gif" alt="" width=1 height=1></div>
				<div class=nav><a href="mars101.php" onFocus="" onBlur="" onMouseOver="document.images['Mars 101'].src='images/divNavON.gif'" onMouseOut="document.images['Mars 101'].src='images/divNav.gif'"><img name="Mars 101" src="images/divNav.gif" alt="" width=16 height=23 border=0 align=left hspace=0><img src="images/spaclear.gif" alt="" width=69 height=4 border=0><br>
				Mars 101</a></div>
				<div id="divR"><img src="images/spaclear.gif" alt="" width=1 height=1></div>
				<div class="nav" style="white-space: nowrap;"><img name="Teachers" src="images/divNavON.gif" width=16 height=23 border=0 align=left hspace=0><img src="images/spaclear.gif" width=56 height=4 border=0><br>The Phoenix Classroom</div>
				<div id="divR"><img src="images/spaclear.gif" alt="" width=1 height=1></div>
				<div class=nav><a href="exhibit.php" onFocus="" onBlur="" onMouseOver="document.images['Exhibit'].src='images/divNavON.gif'" onMouseOut="document.images['Exhibit'].src='images/divNav.gif'"><img name="Exhibit" src="images/divNav.gif" alt="" width=16 height=23 border=0 align=left hspace=0><img src="images/spaclear.gif" alt="" width=81 height=4 border=0><br>
				Web Exhibit</a></div>
				<div id="divR"><img src="images/spaclear.gif" alt="" width=1 height=1></div>
				<div class=nav><a href="ask.php" onFocus="" onBlur="" onMouseOver="document.images['Ask'].src='images/divNavON.gif'" onMouseOut="document.images['Ask'].src='images/divNav.gif'"><img name="Ask" src="images/divNav.gif" alt="" width=16 height=23 border=0 align=left hspace=0><img src="images/spaclear.gif" alt="" width=92 height=4 border=0><br>
				Ask the Team</a></div>
				<div id="divR"><img src="images/spaclear.gif" alt="" width=1 height=1></div>
				<div class=nav><a href="games.php" onFocus="" onBlur="" onMouseOver="document.images['Games'].src='images/divNavON.gif'" onMouseOut="document.images['Games'].src='images/divNav.gif'"><img name="Games" src="images/divNav.gif" alt="" width=16 height=23 border=0 align=left hspace=0><img src="images/spaclear.gif" alt="" width=46 height=4 border=0><br>
				Games, Gear & More</a></div>
				<div id="divR"><img src="images/spaclear.gif" alt="" width=1 height=1></div>
				<!--<div class=nav><a href="requestSpeaker_edu.php" onFocus="" onBlur="" onMouseOver="document.images['Request'].src='images/divNavON.gif'" onMouseOut="document.images['Request'].src='images/divNav.gif'"><img name="Request" src="images/divNav.gif" alt="" width=16 height=23 border=0 align=left hspace=0><img src="images/spaclear.gif" alt="" width=128 height=4 border=0><br>
				Request a Speaker</a></div>
				<div id="divR"><img src="images/spaclear.gif" alt="" width=1 height=1></div>-->
			</div>
			
			<div id="rightText">
				<h1>
					<!-- InstanceBeginEditable name="maps_title" -->MAPS AND TABLES<!-- InstanceEndEditable --></h1>
				<!-- InstanceBeginEditable name="maps" -->
				<ul><!-- InstanceBeginEditable name="maps_body" -->
					<li><a href="mars111.php">Mars/Earth Comparison Table</a></li>
					<li><a href="mars131.php">Planetary Poles Comparison Table</a></li>
					<li><a href="mars161.php">Mars Water Features</a></li><!-- InstanceEndEditable -->
				</ul>
			</div>
			<div id="rightText"><!-- InstanceBeginEditable name="factsheet" -->
				<a href="pdf/fact_sheet.pdf" target="blank">Mission Overview Fact Sheet</a>
				<!-- InstanceEndEditable -->
			</div>
			
			<div id="divR"><img src="images/spaclear.gif" alt="" width=1 height=1></div>
			
			<div id="timeline"><a href="timeline.php"><img src="images/picTimeline.gif" alt="Earth to Mars Timeline" width=220 height=259 border=0></a></div>
</div>
</td></tr></table>
	</div>  <div id="foot">
<img src="images/divFoot.gif" alt="" width="770" height="8" /><br />
<a href="index.php" title="The Phoenix Mission">The Phoenix Mission</a> is led by Principal Investigator <a href="smithPeter.php" title="Peter Smith">Peter H. Smith</a> of <a href="http://www.arizona.edu" title="University of Arizona" target="blank">The University of Arizona</a>, supported by <a href="team01.php">a science team of CO-Is</a>, with project management at <a href="http://www.nasa.gov/" title="Nasa" target="blank">NASA's</a> <a href="http://jpl.nasa.gov/" title="JPL" target="blank">Jet Propulsion Laboratory</a> and development partnership with <a href="http://www.lockheedmartin.com/" title="Lockheed Martin" target="blank">Lockheed Martin Space Systems</a>. International contributions are provided by the <a href="http://www.space.gc.ca/asc/eng/exploration/phoenix.asp" title="Canadian Space Agency" target="blank">Canadian Space Agency</a>; the <a href="http://www-samlab.unine.ch/activities/famars.htm" title="University of Neuchatel (Switzerland)" target="blank">University of Neuchatel</a>, Switzerland; the universities of <a href="http://ntserv.fys.ku.dk/mars/" title="University of Copenhagen" target="blank">Copenhagen</a> and <a href="http://www.au.dk/en" title="University of Aarhus" target="blank">Aarhus</a> Denmark; the <a href="http://www.mps.mpg.de/en/projekte/phoenix/" title="Max Planck Institute" target="blank">Max Planck Institute</a>, Germany; and the <a href="http://www.fmi.fi/research_space/space_23.html" title="Finnish Meteorological Institute" target="blank">Finnish Meteorological Institute</a>. Additional information on Phoenix is online at <a href="http://www.nasa.gov/phoenix" title="NASA Phoenix Site" target="blank">here</a> and <a href="http://www.jpl.nasa.gov/news/phoenix/main.php" title="JPL Phoenix Site" target="blank">here</a>. JPL, a division of the California Institute of Technology in Pasadena, manages <a href="http://mars.jpl.nasa.gov/odyssey/" title="Mars Odyssey" target="blank">Mars Odyssey</a> and <a href="http://mars.jpl.nasa.gov/mro/" title="MRO" target="blank">Mars Reconnaissance Orbiter</a> for the <a href="http://science.hq.nasa.gov/" title="NASA Science Mission Directorate" target="blank">NASA Science Mission Directorate</a>, Washington. Additional information on NASA's Mars program is online at <a href="http://www.nasa.gov/mars" title="NASA Mars" target="blank">here</a>.

<!--International contributions for Phoenix are provided by the <a href="http://www.space.gc.ca/asc/eng/exploration/phoenix.asp" title="Canadian Space Agency" target="blank">Canadian Space Agency</a>, the <a href="http://www-samlab.unine.ch/activities/famars.htm" title="University of Neuchatel (Switzerland)" target="blank">University of Neuchatel (Switzerland)</a>, the <a href="http://ntserv.fys.ku.dk/mars/" title="University of Copenhagen" target="blank">University of Copenhagen</a>, and the <a href="http://www.mps.mpg.de/en/" title="Max Planck Institute" target="blank">Max Planck Institute</a> in Germany.-->

<br /><br />
Some pages may require <a href="http://www.adobe.com/products/flashplayer/" title="Get Flash Player">Flash</a> or <a href="http://www.apple.com/quicktime/win.html" title="Get Quicktime Player">Quicktime</a> Players.	
<br /><br />
In remembrance of <a href="http://phoenix.lpl.arizona.edu/michelangeliDiane.php">Diane Michelangeli</a>
<div id="divFoot"><img src="/images/spaclear.gif" width="1" height="1" alt="" /></div>		
<h1><a href="contact.php" title="Contact">Contact</a>  |  <a href="http://www.lpl.arizona.edu/phoenix_secure/" target="_blank">Team Entrance</a>  |  <a href="privacy.php" title="Privacy">Privacy, Disclaimers, &amp; Accessibility</a></h1>
<div id="divFoot"><img src="/images/spaclear.gif" width="1" height="1" alt="" /></div>
Website powered by <a href='http://www.apple.com' target='_blank' >Apple Xserve</a>
		
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-1708004-1";
urchinTracker();
</script>

</div>
</body>
	<!-- InstanceEnd -->
</html>
