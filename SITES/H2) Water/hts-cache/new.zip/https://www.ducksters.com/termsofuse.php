<!DOCTYPE HTML>
<html lang="en">
<head>
<meta name="keywords" content="kids,terms of use,learn,software,browser">

<meta name="description" content="Ducksters: Terms of Use">

<title>Ducksters: Terms of Use</title>


<script type="text/javascript">
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
  var tyche = {
                mode: 'tyche',
                config: '//config.playwire.com/1015702/v2/websites/62069/banner.json',
                isMobile: 'true'
            };
}
else
{
  var tyche = {
                mode: 'tyche',
                config: '//config.playwire.com/1015702/v2/websites/62069/banner.json',
            };
}
</script>
<script id="tyche" src="//cdn.intergi.com/hera/tyche.js" type="text/javascript"></script>

<style type="text/css">

@media screen{

*, *:before, *:after {
  -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
}
 
body { margin: 0; }

img {
  max-width: 100%; height: auto;
}

.columnsContainer { position: relative; margin: 0px; margin-left:auto; margin-right:auto; max-width:1070px;background-color: #FFFFFF;}

#graphic1 {display:none; }
h1 { font-family: 'Century Gothic', Calibri, Geneva, sans-serif; font-size:2.3em; color: #008040;margin:6px 10px 6px 10px;}
h2 { font-family: 'Century Gothic', Calibri, Geneva, sans-serif; font-size:2.2em; color: #004080;margin:6px 10px 8px 10px;}
body {font-size:1.0em;}

body {
    font-size:100%;
	font-family: Arial;
	background: #2A9BD6;
	text-align: center;
	padding: 0;
}

ul li a {display: inline-block; margin: 4px 4px 4px 4px;} 
li a {display: inline-block; margin: 4px 4px 4px 4px;} 
ul a {display: inline-block; margin: 4px 4px 4px 4px;} 
span a {display: inline-block; margin: 4px 4px 4px 4px;} 
table a {display: inline-block; margin: 4px 4px 4px 4px;} 

a.playwire_report_ad_link{
color: #898989 !important;
text-decoration: none;
}
.wrapper {
  width:100%;
  max-width:1070px;
  margin:0 auto;
  background:#FFFFFF;
  overflow:hidden;
}
.inner {
  -webkit-transform: translateZ(0);
  transform: translateZ(0);
 }
.sidebar-right {
  background:#FFFFF;
  width:100%;
  float:none;
  padding:.4em;
  margin:.4em 0 .4em;
}
.contentT {
  padding:.4em;
  width: 100%;
  padding-right:.5em;
  float:left;
}
.content {
  padding:.4em;
  width: 100%;
  min-height:1450px;
  padding-right:.5em;
  float:left;
}
#playwire_video {padding-top:3px;margin:auto;max-width:640px;}
#standard_image {
    clear:both;
    margin:auto;
    border-style: solid;
    border-color: #525252;
    border-width: 4px;
    display:inline-block;
    background-color: white;
    box-shadow: 5px 10px 5px #888888;
    padding:2px;
    margin-bottom:25px;
}
#standard_image_center {
    clear:both;
    margin:auto;
    border-style: solid;
    border-color: #525252;
    border-width: 4px;
    display:inline-block;
    background-color: white;
    box-shadow: 5px 10px 5px #888888;
    padding:2px;
    margin-bottom:25px;
}
#header_container {
    max-width: 1070px;
    margin: 0px auto 0px auto;
	background-color: #FFFFFF;
	padding:10px 10px 0px 10px;
	position:relative;
	border:8px;
	border-color:#008000;
	border-style:solid;
	border-radius:20px; 
 }
#ad_text {
  font-family : "Arial",sans-serif;
  font-size : .9em;
  font-weight : normal;
  color: #898989;
 }
.radio-toolbar label {
    display:inline-block;
    background-color:#ddd;
    padding:4px 11px;
    font-family:Arial;
    font-size:16px;
}
.radio-toolbar input[type="radio"]:checked + label {
    background-color:#bbb;
}
.button {
  display : inline-block;
  cursor : pointer;
  border-radius : 5px;
  padding : 5px 11px 5px 11px;
  width: 112px;
  box-shadow : 0 1px 4px rgba(0,0,0,.6);
  font-size : 20px;
  font-weight : normal;
  color : #fff;
  text-shadow : 0 1px 3px rgba(0,0,0,.4);
  font-family : "Arial",sans-serif;
  text-decoration : none;
  margin: 0px 0px 10px 10px;
}
button.blue,
.button.blue {
  border-color : #0080C0;
  background: #0080C0;
}
button.green,
.button.green {
  border-color : #008000;
  background: #008000;
}
#rightsidebox1 { 
	width: 320px;
	padding: 0px;
	background-color:#FFF;
	border: 10px solid #004080;
	margin: 0px auto 10px auto;
	-webkit-transform: translateZ(0);
	transform: translateZ(0);
	}
#rightsidebox2 { 
	width: 320px;
	padding: 0px;
	background-color:#FFF;
	border: 10px solid #F48F0C;
	margin: 0px auto 10px auto;
	-webkit-transform: translateZ(0);
	transform: translateZ(0);
	} 		
#rightside {
    float:right;
	margin: 0 0 0px 0px;
	background-color: #FFFFFF;
    }	
#main_table {
	text-align:left;
	}
#footerid {
    font-size:0.9em;
    margin: 0px auto 0px auto;
    max-width:1070px;
}
#footer_search {
	border: 10px solid #F48F0C;
	margin: 10px auto 10px auto;
   padding: 20px;
   background-color: #FFFFFF;
 }	
#footer_menu {
  width: 100%;
  border: 10px solid #008000;
  text-align:left;
  background-color: #FFFFFF;
 } 
#footer_menu td { 
  vertical-align:top;
  font-size:1.1em;
}

#footer_column1 {width:50%;position:relative;float:left;} 
#footer_column2 {width:50%;position:relative;float:left;}
#footer_column3 {width:50%;position:relative;float:left;}
#footer_column4 {width:50%;position:relative;float:left;}

#whatsnewfont {
font-family: 'Comic Sans MS'; font-weight: bold; font-style: normal; text-decoration: none; font-size: 24pt; color: #008080}
#whatsnewlink  { 
font-family: 'Century Gothic', Calibri, Geneva, sans-serif; font-weight:bold; text-decoration: none; font-size: 24pt; color: #008000;}
} 

@media screen and (min-width: 550px){


#standard_image {
    float:right;
	margin: 25px 25px;
}
  
#main_table {max-width:1070px;}
#footer_search {max-width: 600px;}
#footerid {max-width: 1070px;background-color: #FFFFFF;}
#graphic1 {display:none; }

.wrapper {
  width:100%;
  max-width:1070px;
  margin:0 auto;
  background:#FFFFFF;
  overflow:hidden;
  border:5px;border-color:#008040;border-style:solid;
}

.sidebar-right {
  background:#FFFFF;
  width:31%;
  float:left;
  padding:.1em;
  margin:.1em 0 .1em;
}
.contentT {
  padding:.4em;
  width: 67%;
  padding-right:.5em;
  float:left;
}
.content {
  padding:.4em;
  width: 69%;
  min-height:1450px;
  padding-right:.5em;
  float:left;
}

.content_mobile {
  padding:.4em;
  width: 100%;
  padding-right:.5em;
  float:left;
}

.leftColumntop {margin-right: 450px; background-color: #2A9BD6;padding-left: 10px;padding-right:10px}
.rightColumntop {position: absolute; top: 0; right: 0; width: 450px;background-color: #2A9BD6;padding-right:10px}

.leftColumn1 {margin-right: 0px; background-color: #FFFFFF;padding-left: 10px;padding-right:10px}
.rightColumn1 { position: absolute; top: 0px; right: 8px; width: 320px;background-color: #FFFFFF;padding:15px 10px 0px 10px}

.leftColumn {margin-right: 343px; min-height:1450px;background-color: #FFFFFF;padding-left: 10px;padding-right:8px}
.rightColumn {position: absolute; top: 10px; right: 0; width: 343px;background-color: #FFFFFF;padding-right:5px;}

#footer_column1 {width:25%;position:relative;float:left;} 
#footer_column2 {width:25%;position:relative;float:left;}
#footer_column3 {width:25%;position:relative;float:left;}
#footer_column4 {width:25%;position:relative;float:left;}
}

@media screen and (max-width: 655px) 
{
#graphic1 {display:none; }
.leftColumntop {display:none; }
.rightColumntop {display:none; }

#adspace {display:none; }

.button {
  border-radius : 2px;
  padding : 4px 4px 4px 4px;
  width: auto;
  font-size : 20px;
  font-weight : normal;
  margin: 0px 0px 5px 5px;
}

}

@media screen and (max-width: 470px){
#graphic {display:none; }
#graphic1 {display:inline; }
}

@media screen and (max-width: 400px){
#graphic {display:none; }
#graphic1 {display:inline; }
#rightsidebox1 { 
	width: 308px;
	border: 4px solid #004080;
	}
#rightsidebox2 { 
	width: 308px;
	border: 4px solid #F48F0C;
	}
#header_container {
    max-width: 1070px;
    margin: 0px auto 0px auto;
	background-color: #FFFFFF;
	padding:0px 0px 2px 0px;
	position:relative;
	border:4px;
	border-color:#008000;
	border-style:solid;
	border-radius:10px; 
 }	
}

@media screen and (-webkit-min-device-pixel-ratio: 2){
  /* iphone 4*/
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
}
</style>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-714916-2', 'ducksters.com');
  ga('send', 'pageview');
  ga('set', 'anonymizeIp', true);
</script>

<script type="text/javascript" src="/jquery-1.10.1.min.js"></script>
<script type="text/javascript" src="/jquery.sticky-kit.js"></script>
<script type="text/javascript" src="/sticky4.js"></script>

<link rel="shortcut icon" href="/favico2.png"> 
<link rel="apple-touch-icon" href="/favico2.png">
<link rel="icon" href="/favico2.png" sizes="16x16" type="image/png">


<meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body bgcolor="#ffffff">

<div class="columnsContainer" style="background-color:#2A9BD6;">
<div class="leftColumntop" align="left">
<font size="-1"><i>Parents and Teachers</i>: Support Ducksters by following us on <a href="https://www.facebook.com/pages/Ducksters/103074613109209"><img src="/facebook_24.png" width="24" height="24" alt="Ducksters Facebook" title="" /></a> or <a href="https://www.twitter.com/DuckstersKids"><img src="/twitter_24.png" width="24" height="24" alt="Ducksters Twitter" title="" /></a>.</font>
</div>

<div class="rightColumntop">
<form action="https://www.google.com" id="cse-search-box" target="_blank">
  <div>
    <input type="hidden" name="cx" value="partner-pub-1809268078385119:3620521284" />
    <input type="hidden" name="ie" value="UTF-8" />
    <input type="text" name="q" size="40" />
    <input type="submit" name="sa" value="Search" />
  </div>
</form>
<script type="text/javascript" src="https://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang="></script>
</div>
</div>
<div id="header_container">
<div class="leftColumn1" align="center">
<span id="graphic" style="position: relative;border: 0px;">
<a href="/"><img src="/graphics/ducksters_new_header_shrunk2.gif" width="700" height="200" alt="Ducksters Educational Site" title="" /></a></span><span id="graphic1" style="position: relative;border: 0px;"><a href="/"><img src="/graphics/ducksters_mobile_4.gif" alt="Ducksters Educational Site" border="0"></a>
</span>
<div align="center"><font size="+2">
<a  class="button green" href="/history/">History</a>
<a class="button green" href="/biography/">Biography</a>
<a class="button green" href="/geography/">Geography</a>
<a class="button green" href="/science/">Science</a>
<a class="button green" href="/games/">Games</a>
</font></div></div></div>
<BR id="adspace">
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
}
else
{
document.write("<div align='center'><div data-pw-desk='leaderboard_atf'></div><div data-pw-mobi='leaderboard_atf'></div>"); 
}
</script>
<div class="wrapper">
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
document.write("<div class='content_mobile' align='left'>");
if ($(window).width() < 600) {
document.write("<div align='center'>");
document.write("<div data-pw-mobi='leaderboard_atf'></div><div data-pw-desk='leaderboard_atf'></div>");   
}
else {
document.write("<div style='float:right;'>");   
document.write("<div data-pw-mobi='med_rect_atf'></div><div data-pw-desk='med_rect_atf'></div>"); 
} 
}
else
{
document.write("<div class='content' align='left'><div align='center'>");
}
</script></div>

      <p align="center"><strong>Terms of Use</strong></p>
      
	  Back to <a href="/">Ducksters</a>
      <BR><BR>
<b>TERMS OF USE AGREEMENT BETWEEN USER AND TECHNOLOGICAL SOLUTIONS, INC. (TSI)</b>
<BR><BR>
"Ducksters" is comprised of various web pages operated by Technological Solutions, Inc. located at https://www.ducksters.com. Ducksters is offered to you conditioned on your acceptance without modification of the terms, conditions, and notices contained herein. Your use of the Ducksters website and pages constitutes your agreement to all such terms, conditions, and notices.
	  <BR><BR>
      Ducksters (wholly owned by TSI) makes no claims as to 
      the accuracy of any information on our web sites.&nbsp; All information, 
      data, software, services used from the website are used at the user's own 
      risk.
	  <BR><BR>
      If you need specific advice (for example, medical, legal, 
      financial, or risk management) please seek a professional who is licensed 
      or knowledgeable in that area.&nbsp; We do not provide or claim to provide 
      any professional advice on this web site.
	  <BR><BR>
      We claim copyright to all information and data that was 
      created by Ducksters or TSI.
	  <BR><BR>
	  <b>LIABILITY</b>
	  <BR><BR>
      WE DO NOT WARRANT THAT OUR WEB SITES WILL BE UNINTERRUPTED 
      OR ERROR FREE. IN ADDITION, WE DO NOT MAKE ANY WARRANTY AS TO THE CONTENT 
      ON OUR SITES. OUR SITES AND THEIR CONTENT ARE DISTRIBUTED ON AN "AS IS, AS 
      AVAILABLE" BASIS. ANY MATERIAL THAT YOU DOWNLOAD OR OTHERWISE OBTAIN 
      THROUGH OUR SITES IS DONE AT YOUR OWN DISCRETION AND RISK, AND YOU WILL BE 
      SOLELY RESPONSIBLE FOR ANY POTENTIAL DAMAGES TO YOUR COMPUTER SYSTEM OR 
      LOSS OF DATA THAT RESULTS FROM YOUR DOWNLOAD OF ANY SUCH MATERIAL.&nbsp; 
      YOU EXPRESSLY AGREE THAT YOU WILL ASSUME THE ENTIRE RISK AS TO THE QUALITY 
      AND THE PERFORMANCE OF OUR WEB SITES AND THE COMPLETENESS OR&nbsp;ACCURACY 
      OF ITS CONTENT.&nbsp; NEITHER WE BE LIABLE FOR ANY DIRECT, INDIRECT, 
      INCIDENTAL, SPECIAL, OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OF OR 
      INABILITY TO USE OUR SITES, EVEN IF WE HAVE BEEN ADVISED OF THE 
      POSSIBILITY OF SUCH DAMAGES.
	  <BR><BR>
	  Ducksters' and TSI's COLLECTION OF WEBSITE SERVICES AND CONTENT ARE PROVIDED "AS-IS" WITHOUT EXCEPTION.
	<BR><BR>  
THE INFORMATION, SOFTWARE, PRODUCTS, AND SERVICES INCLUDED IN OR AVAILABLE THROUGH DUCKSTER MAY INCLUDE INACCURACIES OR TYPOGRAPHICAL ERRORS. CHANGES ARE PERIODICALLY ADDED TO THE INFORMATION HEREIN. TSI AND/OR ITS SUPPLIERS MAY MAKE IMPROVEMENTS AND/OR CHANGES TO DUCKSTERS AT ANY TIME. TSI AND/OR ITS SUPPLIERS MAKE NO REPRESENTATIONS ABOUT THE SUITABILITY, RELIABILITY, AVAILABILITY, TIMELINESS, AND ACCURACY OF THE INFORMATION, SOFTWARE, PRODUCTS, SERVICES AND RELATED GRAPHICS CONTAINED ON DUCKSTER FOR ANY PURPOSE. TSI ITS SUPPLIERS HEREBY DISCLAIM ALL WARRANTIES AND CONDITIONS WITH REGARD TO THIS INFORMATION, SOFTWARE, PRODUCTS, SERVICES AND RELATED GRAPHICS, INCLUDING ALL IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL TSI AND/OR ITS SUPPLIERS BE LIABLE FOR ANY DIRECT, INDIRECT, PUNITIVE, INCIDENTAL, SPECIAL, CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF USE, DATA OR PROFITS, ARISING OUT OF OR IN ANY WAY CONNECTED WITH THE USE OR PERFORMANCE OF DUCKSTER WITH THE DELAY OR INABILITY TO USE DUCKSTERS OR RELATED SERVICES, THE PROVISION OF OR FAILURE TO PROVIDE SERVICES, OR FOR ANY INFORMATION, SOFTWARE, PRODUCTS, SERVICES AND RELATED GRAPHICS OBTAINED THROUGH DUCKSTERS, OR OTHERWISE ARISING OUT OF THE USE OF DUCKSTERS, WHETHER BASED ON CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE, EVEN IF TSI OR ANY OF ITS SUPPLIERS HAS BEEN ADVISED OF THE POSSIBILITY OF DAMAGES. BECAUSE SOME STATES/JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF LIABILITY FOR CONSEQUENTIAL OR INCIDENTAL DAMAGES, THE ABOVE LIMITATION MAY NOT APPLY TO YOU. IF YOU ARE DISSATISFIED WITH ANY PORTION OF DUCKSTER, OR WITH ANY OF THESE TERMS OF USE, YOUR SOLE AND EXCLUSIVE REMEDY IS TO DISCONTINUE USING DUCKSTERS.
<BR><BR>
	  <b>THIRD PARTY SITES</b>
	  <BR><BR>
	  We cannot be responsible for any content that is not part of 
      Ducksters.&nbsp; We utilize Google SafeSearch for our search engine, but 
      cannot verify or take responsibility for any content on other web sites 
      that either our web site or the search engine links to.&nbsp; As always, 
      parents should monitor their children's use of the 
      Internet.</p>
	  <b>WEBSITE CONTENT</b>
	  <BR><BR>
All copyrighted content such as articles, text, videos, games, exercises, and images are for online use only. You may not download, copy, reproduce, change, distribute, or create derivative works of our content without written permission from Ducksters. The content on Ducksters may only be shown from within our website. You may not display our proprietary and/or licensed content in iFrames.
<BR><BR>
<b>LINKING</b>
<BR><BR>
Ducksters grants you the revocable permission to link to individual pages only; provided, however, that any link to the website: (a) must not frame or create a browser or border environment around any of the content or otherwise mirror any part of website; (b) must not imply that Ducksters or TSI is endorsing or sponsoring any third party or its products or services, unless Ducksters or TSI has given the third party its prior written consent; (c) must not present false information about, or disparage, tarnish, or otherwise, in Duckster’s sole opinion, harm Ducksters or its products or services; (d) must not use any Ducksters trademarks without the prior written permission from Ducksters and/or TSI; (e) must not contain content that could be construed as distasteful, offensive or controversial or otherwise objectionable (in Duckster’s sole opinion); and (f) must be owned and controlled by you or the person or entity placing the link, or otherwise permit you to enable such link subject to these Terms. Notwithstanding anything to the contrary contained in these Terms, Ducksters reserves the right to prohibit linking to the Platform for any reason in our sole and absolute discretion.
<BR><BR>
<b>SUBMISSIONS</b>
<BR><BR>
Anything that is sent to Ducksters or TSI by email, regular mail or submission forms on the web site is the exclusive property of the publisher. The publisher has the right to unrestricted use of these submissions for any purpose commercial or otherwise without compensation to the provider of the submissions.
<BR><BR>
<b>INDEMNITY</b>
<BR><BR>
You agree to indemnify and hold harmless Technological Solutions, Inc., and its subsidiaries, affiliates, officers, agents, or other partners, and employees, from any claim or demand, including reasonable attorneys' fees, made by any third party due to or arising out of your use of and access to Ducksters, your violation of the terms of use, your violation of any rights of another person or entity, or your violation of any applicable laws or regulations.
	<BR><BR>  
	  
	  <b>PERMISSIONS</b>
	  <BR><BR>
We get a lot of requests to use our material and cannot reply to all of them with a specific answer. In general, we never allow for the reposting of our copyrighted material on the internet. A link to one of our pages is generally okay (see above).  If you would like to license some of our material for printing or for use on a password protected website; please contact us with the volume, page(s), and time frame for a quote.
<BR><BR>
       Back to <a href="/">Ducksters</a>
      
      
      </div>
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
}
else
{

document.write("<div class='sidebar-right' id='sidebar'><div class='inner'><span id='ad_text'>Advertisement</span><div align='center' id='rightsidebox1'>");
document.write("<div data-pw-desk='med_rect_atf'></div>");
document.write("<div data-pw-mobi='med_rect_atf'></div>");
document.write("</div><table  id='rightsidebox2'><tr><td>");

var value=Math.floor((Math.random()*4)+1);
if (value==1)
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>Vote for your favorite US President:</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpoll.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>George Washington<br><input name='answer' type='radio' value='two'>John Adams<br><input name='answer' type='radio' value='three'>Thomas Jefferson<br><input name='answer' type='radio' value='four'>Abraham Lincoln<br><input name='answer'type='radio' value='five'>Franklin D. Roosevelt<br></font>");
}
else if (value==2)
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>Which superpower would you want if you were a Superhero?</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpollsuperpower.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>Super Strength<br><input name='answer' type='radio' value='two'>Flying<br><input name='answer' type='radio' value='three'>Super Speed<br><input name='answer' type='radio' value='four'>Invisibility<br><input name='answer'type='radio' value='five'>Super Stretch<br></font>");
}
else if (value==3)
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>Vote for your favorite explorer:</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpollexplorers.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>Captain James Cook<br><input name='answer' type='radio' value='two'>Neil Armstrong<br><input name='answer' type='radio' value='three'>Christopher Columbus<br><input name='answer' type='radio' value='four'>Ferdinand Magellan<br><input name='answer'type='radio' value='five'>Marco Polo<br></font>");
}
else
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>What is your best subject at school?</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpollschoolsubject.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>Math<br><input name='answer' type='radio' value='two'>Reading<br><input name='answer' type='radio' value='three'>Writing<br><input name='answer' type='radio' value='four'>Science<br><input name='answer'type='radio' value='five'>History<br></font>");
}
document.write("</div></td><td><input name='psubmit' type='submit' value='Vote' class='button blue'></form><BR><BR><a href='/takekidspolls1.php'><font size='-1'>More polls</font></a></td></tr></table></td></tr></table>");
}
</script>
</div>
</div>
</div>

<div id="footerid">
<div align="center">
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
document.write("<div data-pw-desk='leaderboard_btf'></div><div data-pw-mobi='leaderboard_btf'></div>");
}
else
{
document.write("<div data-pw-desk='leaderboard_btf'></div><div data-pw-mobi='leaderboard_btf'></div>");
}
</script>
</div>
<BR><BR>
<div id="footer_search">
<form action="https://www.google.com" id="cse-search-box">
  <div>
    <input type="hidden" name="cx" value="partner-pub-1809268078385119:5398998522" />
    <input type="hidden" name="ie" value="UTF-8" />
    <input type="text" name="q" size="36" />
    <input type="submit" name="sa" value="Search" />
  </div>
</form>
<script type="text/javascript" src="https://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en"></script>
</div>
<BR>
<table id="footer_menu"><tr><td> 
<span id="footer_column1">
	<a href="/study.php"><font color="#F48F0C">Homework</font></a><br>	
		<a href="/animals.php">Animals</a><br>
		<a href="/kidsmath/">Math</a><br>
	    <a href="/history/">History</a><br>	
		<a href="/biography/">Biography</a><br>
		<a href="/money/">Money and Finance</a><br> 
	<br>
			<font color="#F48F0C">Biography</font><br>	
		  <a href="/history/art/">Artists</a><br>
		  <a href="/history/civil_rights/">Civil Rights Leaders</a><br>
		  <a href="/biography/entrepreneurs/">Entrepreneurs</a><br>
		  <a href="/biography/explorers/">Explorers</a><br>
		  <a href="/biography/scientists/scientists_and_inventors.php">Inventors and Scientists</a><br>
		  <a href="/biography/women_leaders/">Women Leaders</a><br>
		  <a href="/biography/world_leaders/">World Leaders</a><br>
		  <a href="/biography/uspresidents/">US Presidents</a><br>
		  <br>
</span>	<span id="footer_column2"> 
          <a><font color="#F48F0C">US History</font></a><br>
		  <a href="/history/native_americans.php">Native Americans</a><BR>
		  <a href="/history/colonial_america/">Colonial America</a><br>
          <a href="/history/american_revolution.php">American Revolution</a><BR>
		  <a href="/history/us_1800s/industrial_revolution.php">Industrial Revolution</a><BR>  
          <a href="/history/civil_war.php">American Civil War</a><BR>
          <a href="/history/westward_expansion/">Westward Expansion</a><BR>
		  <a href="/history/us_1900s/great_depression.php">The Great Depression</a><BR>
		  <a href="/history/civil_rights/">Civil Rights Movement</a><BR>
		  <a href="/history/us_1800s/">Pre-1900s</a><BR>
          <a href="/history/us_1900s/">1900 to Present</a><BR>
		  <a href="/history/us_government.php">US Government</a><BR>
          <a href="/geography/us_states/">US State History</a><BR>	
		<br> 
		<a href="/science/"><font color="#F48F0C">Science</font></a><br>
        <a href="/science/biology/">Biology</a><br>
		<a href="/science/chemistry/">Chemistry</a><br>	
		<a href="/science/earth_science/">Earth Science</a><br>							
		<a href="/science/physics/">Physics</a><br>	
	<BR>	
</span>	<span id="footer_column3">  
          <a><font color="#F48F0C">World History</font></a><br>
		  <a href="/history/africa/">Ancient Africa</a><BR>						
          <a href="/history/china/ancient_china.php">Ancient China</a><br>
          <a href="/history/ancient_egypt.php">Ancient Egypt</a><br>
          <a href="/history/ancient_greece.php">Ancient Greece</a><br>
          <a href="/history/mesopotamia/ancient_mesopotamia.php">Ancient Mesopotamia</a><br>		  
          <a href="/history/ancient_rome.php">Ancient Rome</a><br>
          <a href="/history/middle_ages_timeline.php">Middle Ages</a><br>
          <a href="/history/islam/">Islamic Empire</a><BR>		  
          <a href="/history/renaissance.php">Renaissance</a><br>
          <a href="/history/aztec_maya_inca.php">Aztec, Maya, Inca</a><br>
		  <a href="/history/french_revolution/">French Revolution</a><br>
          <a href="/history/world_war_i/">World War 1</a><br>
          <a href="/history/world_war_ii/">World War 2</a><br>
          <a href="/history/cold_war/summary.php">Cold War</a><br>
          <a href="/history/art/">Art History</a><br>	
         <br>
	 
</span>	
<span id="footer_column4">
	 <a href="/geography/"><font color="#F48F0C">Geography</font></a><br>
					<a href="/geography/usgeography.php">United States</a><br>
					<a href="/geography/africa.php">Africa</a><br>
					<a href="/geography/asia.php">Asia</a><br>
					<a href="/geography/centralamerica.php">Central America</a><br>
					<a href="/geography/europe.php">Europe</a><br>
					<a href="/geography/middleeast.php">Middle East</a><br>
					<a href="/geography/northamerica.php">North America</a><br>
					<a href="/geography/oceania.php">Oceania</a><br>
					<a href="/geography/southamerica.php">South America</a><br>
					<a href="/geography/southeastasia.php">Southeast Asia</a><br>	 
<br>
     <a><font color="#F48F0C">Fun Stuff</font></a><br>	
		       <a href="/games/">Educational Games</a><br>
			   <a href="/holidays/kids_calendar.php">Holidays</a><BR>	
			   <a href="/jokes/">Jokes for Kids</a><br>	
			   <a href="/movies.php">Movies</a><br>	
			   <a href="/music.php">Music</a><br>  
			   <a href="/sports.php">Sports</a><br>	

</span> 
	 </td></tr>
<div align="center"><img src="/graphics/ducksters_footer_1.gif" width="745" height="101" alt="" title="" />	</div> 
	 </table>
<BR><BR>
<a href="/about.php">About Ducksters</a>&nbsp;<a href="/privacy_policy.php"><b><font color="#008000">Privacy Policy</b></a></font>&nbsp;
<script type="text/javascript">
var title_1 = document.title;
var location_1 = document.location.href;
document.write ("<a href='/citation.php?title=" + title_1 + "&location=" + location_1 + "'>Cite this Page</a>");
</script>&nbsp;
<BR><BR>
Follow us on <a href="https://www.facebook.com/pages/Ducksters/103074613109209"><img src="/facebook_24.png" width="24" height="24" alt="Ducksters Facebook" title="" /></a> or <a href="https://www.twitter.com/DuckstersKids"><img src="/twitter_24.png" width="24" height="24" alt="Ducksters Twitter" title="" /></a>
<BR><BR>
This site is a product of TSI (Technological Solutions, Inc.), Copyright 2019, All Rights Reserved.
By using this site you agree to the
<a href="/termsofuse.php">Terms of Use.</a>
<BR><BR>
<script type="text/javascript">
var title_1 = document.title;
var location_1 = document.location.href;
document.write ("<a href='/citation.php?title=" + title_1 + "&location=" + location_1 + "'>Cite this Page</a>");
</script>
<BR><BR>
</div>
</div>             

</body>
</html>
