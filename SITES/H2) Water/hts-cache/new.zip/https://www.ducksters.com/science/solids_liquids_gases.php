<!DOCTYPE HTML>
<html lang="en">
<head>
<meta name="keywords" content="solids,liquids,gases,learn,science,kids,fun,children,study,education">

<meta name="description" content="Kid's learn about the science of states of matter. Solids, liquids, gases, and even plasma.">

<title>Kids science: Solid, Liquid, Gas</title>

<script type="text/javascript">
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
  var tyche = {
                mode: 'tyche',
                config: '//config.playwire.com/1015702/v2/websites/62069/banner.json',
                isMobile: 'true'
            };
}
else
{
  var tyche = {
                mode: 'tyche',
                config: '//config.playwire.com/1015702/v2/websites/62069/banner.json',
            };
}
</script>
<script id="tyche" src="//cdn.intergi.com/hera/tyche.js" type="text/javascript"></script>

<style type="text/css">

@media screen{

*, *:before, *:after {
  -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box;
}
 
body { margin: 0; }

img {
  max-width: 100%; height: auto;
}

.columnsContainer { position: relative; margin: 0px; margin-left:auto; margin-right:auto; max-width:1070px;background-color: #FFFFFF;}

#graphic1 {display:none; }
h1 { font-family: 'Century Gothic', Calibri, Geneva, sans-serif; font-size:2.3em; color: #008040;margin:6px 10px 6px 10px;}
h2 { font-family: 'Century Gothic', Calibri, Geneva, sans-serif; font-size:2.2em; color: #004080;margin:6px 10px 8px 10px;}
body {font-size:1.0em;}

body {
    font-size:100%;
	font-family: Arial;
	background: #2A9BD6;
	text-align: center;
	padding: 0;
}

ul li a {display: inline-block; margin: 4px 4px 4px 4px;} 
li a {display: inline-block; margin: 4px 4px 4px 4px;} 
ul a {display: inline-block; margin: 4px 4px 4px 4px;} 
span a {display: inline-block; margin: 4px 4px 4px 4px;} 
table a {display: inline-block; margin: 4px 4px 4px 4px;} 

a.playwire_report_ad_link{
color: #898989 !important;
text-decoration: none;
}
.wrapper {
  width:100%;
  max-width:1070px;
  margin:0 auto;
  background:#FFFFFF;
  overflow:hidden;
}
.inner {
  -webkit-transform: translateZ(0);
  transform: translateZ(0);
 }
.sidebar-right {
  background:#FFFFF;
  width:100%;
  float:none;
  padding:.4em;
  margin:.4em 0 .4em;
}
.contentT {
  padding:.4em;
  width: 100%;
  padding-right:.5em;
  float:left;
}
.content {
  padding:.4em;
  width: 100%;
  min-height:1450px;
  padding-right:.5em;
  float:left;
}
#playwire_video {padding-top:3px;margin:auto;max-width:640px;}
#standard_image {
    clear:both;
    margin:auto;
    border-style: solid;
    border-color: #525252;
    border-width: 4px;
    display:inline-block;
    background-color: white;
    box-shadow: 5px 10px 5px #888888;
    padding:2px;
    margin-bottom:25px;
}
#standard_image_center {
    clear:both;
    margin:auto;
    border-style: solid;
    border-color: #525252;
    border-width: 4px;
    display:inline-block;
    background-color: white;
    box-shadow: 5px 10px 5px #888888;
    padding:2px;
    margin-bottom:25px;
}
#header_container {
    max-width: 1070px;
    margin: 0px auto 0px auto;
	background-color: #FFFFFF;
	padding:10px 10px 0px 10px;
	position:relative;
	border:8px;
	border-color:#008000;
	border-style:solid;
	border-radius:20px; 
 }
#ad_text {
  font-family : "Arial",sans-serif;
  font-size : .9em;
  font-weight : normal;
  color: #898989;
 }
.radio-toolbar label {
    display:inline-block;
    background-color:#ddd;
    padding:4px 11px;
    font-family:Arial;
    font-size:16px;
}
.radio-toolbar input[type="radio"]:checked + label {
    background-color:#bbb;
}
.button {
  display : inline-block;
  cursor : pointer;
  border-radius : 5px;
  padding : 5px 11px 5px 11px;
  width: 112px;
  box-shadow : 0 1px 4px rgba(0,0,0,.6);
  font-size : 20px;
  font-weight : normal;
  color : #fff;
  text-shadow : 0 1px 3px rgba(0,0,0,.4);
  font-family : "Arial",sans-serif;
  text-decoration : none;
  margin: 0px 0px 10px 10px;
}
button.blue,
.button.blue {
  border-color : #0080C0;
  background: #0080C0;
}
button.green,
.button.green {
  border-color : #008000;
  background: #008000;
}
#rightsidebox1 { 
	width: 320px;
	padding: 0px;
	background-color:#FFF;
	border: 10px solid #004080;
	margin: 0px auto 10px auto;
	-webkit-transform: translateZ(0);
	transform: translateZ(0);
	}
#rightsidebox2 { 
	width: 320px;
	padding: 0px;
	background-color:#FFF;
	border: 10px solid #F48F0C;
	margin: 0px auto 10px auto;
	-webkit-transform: translateZ(0);
	transform: translateZ(0);
	} 		
#rightside {
    float:right;
	margin: 0 0 0px 0px;
	background-color: #FFFFFF;
    }	
#main_table {
	text-align:left;
	}
#footerid {
    font-size:0.9em;
    margin: 0px auto 0px auto;
    max-width:1070px;
}
#footer_search {
	border: 10px solid #F48F0C;
	margin: 10px auto 10px auto;
   padding: 20px;
   background-color: #FFFFFF;
 }	
#footer_menu {
  width: 100%;
  border: 10px solid #008000;
  text-align:left;
  background-color: #FFFFFF;
 } 
#footer_menu td { 
  vertical-align:top;
  font-size:1.1em;
}

#footer_column1 {width:50%;position:relative;float:left;} 
#footer_column2 {width:50%;position:relative;float:left;}
#footer_column3 {width:50%;position:relative;float:left;}
#footer_column4 {width:50%;position:relative;float:left;}

#whatsnewfont {
font-family: 'Comic Sans MS'; font-weight: bold; font-style: normal; text-decoration: none; font-size: 24pt; color: #008080}
#whatsnewlink  { 
font-family: 'Century Gothic', Calibri, Geneva, sans-serif; font-weight:bold; text-decoration: none; font-size: 24pt; color: #008000;}
} 

@media screen and (min-width: 550px){


#standard_image {
    float:right;
	margin: 25px 25px;
}
  
#main_table {max-width:1070px;}
#footer_search {max-width: 600px;}
#footerid {max-width: 1070px;background-color: #FFFFFF;}
#graphic1 {display:none; }

.wrapper {
  width:100%;
  max-width:1070px;
  margin:0 auto;
  background:#FFFFFF;
  overflow:hidden;
  border:5px;border-color:#008040;border-style:solid;
}

.sidebar-right {
  background:#FFFFF;
  width:31%;
  float:left;
  padding:.1em;
  margin:.1em 0 .1em;
}
.contentT {
  padding:.4em;
  width: 67%;
  padding-right:.5em;
  float:left;
}
.content {
  padding:.4em;
  width: 69%;
  min-height:1450px;
  padding-right:.5em;
  float:left;
}

.content_mobile {
  padding:.4em;
  width: 100%;
  padding-right:.5em;
  float:left;
}

.leftColumntop {margin-right: 450px; background-color: #2A9BD6;padding-left: 10px;padding-right:10px}
.rightColumntop {position: absolute; top: 0; right: 0; width: 450px;background-color: #2A9BD6;padding-right:10px}

.leftColumn1 {margin-right: 0px; background-color: #FFFFFF;padding-left: 10px;padding-right:10px}
.rightColumn1 { position: absolute; top: 0px; right: 8px; width: 320px;background-color: #FFFFFF;padding:15px 10px 0px 10px}

.leftColumn {margin-right: 343px; min-height:1450px;background-color: #FFFFFF;padding-left: 10px;padding-right:8px}
.rightColumn {position: absolute; top: 10px; right: 0; width: 343px;background-color: #FFFFFF;padding-right:5px;}

#footer_column1 {width:25%;position:relative;float:left;} 
#footer_column2 {width:25%;position:relative;float:left;}
#footer_column3 {width:25%;position:relative;float:left;}
#footer_column4 {width:25%;position:relative;float:left;}
}

@media screen and (max-width: 655px) 
{
#graphic1 {display:none; }
.leftColumntop {display:none; }
.rightColumntop {display:none; }

#adspace {display:none; }

.button {
  border-radius : 2px;
  padding : 4px 4px 4px 4px;
  width: auto;
  font-size : 20px;
  font-weight : normal;
  margin: 0px 0px 5px 5px;
}

}

@media screen and (max-width: 470px){
#graphic {display:none; }
#graphic1 {display:inline; }
}

@media screen and (max-width: 400px){
#graphic {display:none; }
#graphic1 {display:inline; }
#rightsidebox1 { 
	width: 308px;
	border: 4px solid #004080;
	}
#rightsidebox2 { 
	width: 308px;
	border: 4px solid #F48F0C;
	}
#header_container {
    max-width: 1070px;
    margin: 0px auto 0px auto;
	background-color: #FFFFFF;
	padding:0px 0px 2px 0px;
	position:relative;
	border:4px;
	border-color:#008000;
	border-style:solid;
	border-radius:10px; 
 }	
}

@media screen and (-webkit-min-device-pixel-ratio: 2){
  /* iphone 4*/
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
}
</style>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-714916-2', 'ducksters.com');
  ga('send', 'pageview');
  ga('set', 'anonymizeIp', true);
</script>

<script type="text/javascript" src="/jquery-1.10.1.min.js"></script>
<script type="text/javascript" src="/jquery.sticky-kit.js"></script>
<script type="text/javascript" src="/sticky4.js"></script>

<link rel="shortcut icon" href="/favico2.png"> 
<link rel="apple-touch-icon" href="/favico2.png">
<link rel="icon" href="/favico2.png" sizes="16x16" type="image/png">


<meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body bgcolor="#ffffff">

<div class="columnsContainer" style="background-color:#2A9BD6;">
<div class="leftColumntop" align="left">
<font size="-1"><i>Parents and Teachers</i>: Support Ducksters by following us on <a href="https://www.facebook.com/pages/Ducksters/103074613109209"><img src="/facebook_24.png" width="24" height="24" alt="Ducksters Facebook" title="" /></a> or <a href="https://www.twitter.com/DuckstersKids"><img src="/twitter_24.png" width="24" height="24" alt="Ducksters Twitter" title="" /></a>.</font>
</div>

<div class="rightColumntop">
<form action="https://www.google.com" id="cse-search-box" target="_blank">
  <div>
    <input type="hidden" name="cx" value="partner-pub-1809268078385119:3620521284" />
    <input type="hidden" name="ie" value="UTF-8" />
    <input type="text" name="q" size="40" />
    <input type="submit" name="sa" value="Search" />
  </div>
</form>
<script type="text/javascript" src="https://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang="></script>
</div>
</div>
<div id="header_container">
<div class="leftColumn1" align="center">
<span id="graphic" style="position: relative;border: 0px;">
<a href="/"><img src="/graphics/ducksters_new_header_shrunk2.gif" width="700" height="200" alt="Ducksters Educational Site" title="" /></a></span><span id="graphic1" style="position: relative;border: 0px;"><a href="/"><img src="/graphics/ducksters_mobile_4.gif" alt="Ducksters Educational Site" border="0"></a>
</span>
<div align="center"><font size="+2">
<a  class="button green" href="/history/">History</a>
<a class="button green" href="/biography/">Biography</a>
<a class="button green" href="/geography/">Geography</a>
<a class="button green" href="/science/">Science</a>
<a class="button green" href="/games/">Games</a>
</font></div></div></div>
<BR id="adspace">
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
}
else
{
document.write("<div align='center'><div data-pw-desk='leaderboard_atf'></div><div data-pw-mobi='leaderboard_atf'></div>"); 
}
</script>
<div class="wrapper">
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
document.write("<div class='content_mobile' align='left'>");
if ($(window).width() < 600) {
document.write("<div align='center'>");
document.write("<div data-pw-mobi='leaderboard_atf'></div><div data-pw-desk='leaderboard_atf'></div>");   
}
else {
document.write("<div style='float:right;'>");   
document.write("<div data-pw-mobi='med_rect_atf'></div><div data-pw-desk='med_rect_atf'></div>"); 
} 
}
else
{
document.write("<div class='content' align='left'><div align='center'>");
}
</script></div>

 <h1><div align="center">Solids, Liquids, and Gases</div></h1>
<a href="/science/">Science</a> >> <a href="/science/chemistry/">Chemistry for Kids</a><BR><BR>

We learned in some of our other lessons that matter is made up of <a href="/science/the_atom.php">atoms</a> and <a href="/science/molecules.php">molecules</a>. Millions and millions of these tiny objects fit together to form larger things like animals and planets and cars. Matter includes the water we drink, the air we breathe, and the chair we are sitting on.
<BR><BR>
<b>States or Phases</b>
<BR><BR>
Matter usually exists in one of three states or phases: solid, liquid, or gas. The chair you are sitting on is a solid, the water you drink is liquid, and the air you breathe is a gas.
<BR><BR>
<b>Changing State</b>
<BR><BR>
The atoms and molecules don't change, but the way they move about does. Water, for example, is always made up of two hydrogen atoms and one oxygen atom. However, it can take the state of liquid, solid (ice), and gas (steam). Matter changes state when more energy gets added to it. Energy is often added in the form of heat or <a href="/science/physics/pressure.php">pressure</a>.
<BR><BR>
<b>Water</b>
<BR><BR>
Solid water is called ice. This is water with the lowest energy and temperature. When solid, the molecules in water are held tightly together and don't move easily.
<BR><BR>
Liquid water is just called water. As ice heats up it will change phases to liquid water. Liquid molecules are looser and can move about easily.
<BR><BR>
Gas water is called steam or vapor. When water boils it will turn to vapor. These molecules are hotter, looser, and moving faster than the liquid molecules. They are more spread apart and can be compressed or squished.
<div align="center"><img src="water_forms.jpg" width="380" height="250" alt="" title="Three states of water H2O" border="0" align="" />
<BR>
The three states of Water</div>
<BR>
<b>More States</b>
<BR><BR>
There are actually two more states or phases that matter can take, but we don't see them much in our everyday life. 
<BR><BR>
One is called plasma. Plasma occurs at very high temperatures and can be found in stars and lightning bolts. Plasma is like gas, but the molecules have lost some electrons and become ions. 
<BR><BR>
Another state has the fancy name Bose-Einstein condensates. This state can occur at super low temperatures.
<BR><BR>
<div align="center"><script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
document.write("<div data-pw-desk='med_rect_btf'></div>");
document.write("<div data-pw-mobi='med_rect_btf'></div>");
}
</script></div><b>Fun Facts about Solids, Liquids, Gases</b>

<ul>
    <li>Gases are often invisible and assume the shape and volume of their container.</li>
    <li>The air we breathe is made up of different gases, but it is mostly nitrogen and oxygen.</li>
    <li>We can see through some solids like glass.</li>
    <li>When liquid gasoline is burned in a car, it turns into various gases which go into the air from the exhaust pipe.</li>
    <li>Fire is a mixture of hot gases.</li>
    <li>Plasma is by far the most abundant state of matter in the universe because stars are mostly plasma.</li>
</ul> 
<b>Activities</b>
<BR><BR>
Take a ten question <a href="/science/quiz/solids_liquids_gases_questions.php">quiz</a> about this page.
<BR><BR>
<b>More Chemistry Subjects</b>
<BR><BR>
<table border="0"  width="99%">
  <tr><!-- Row 1 -->
     <td valign="top">
<b>Matter</b><BR>
<a href="/science/the_atom.php">Atom</a><BR>
<a href="/science/molecules.php">Molecules</a><BR>
<a href="/science/chemistry/isotopes.php">Isotopes</a><BR>
<a href="/science/solids_liquids_gases.php">Solids, Liquids, Gases</a><BR>
<a href="/science/melting_and_boiling.php">Melting and Boiling</a><BR>
<a href="/science/chemistry/chemical_bonding.php">Chemical Bonding</a><BR>
<a href="/science/chemistry/chemical_reactions.php">Chemical Reactions</a><BR>
<a href="/science/chemistry/radiation_and_radioactivity.php">Radioactivity and Radiation</a><BR>
	 </td><!-- Col 1 -->
     <td valign="top">
<b>Mixtures and Compounds</b><BR>
<a href="/science/chemistry/naming_chemical_compounds.php">Naming Compounds</a><BR>
<a href="/science/chemistry/chemical_mixtures.php">Mixtures</a><BR>
<a href="/science/chemistry/separating_mixtures.php">Separating Mixtures</a><BR>
<a href="/science/chemistry/solutions_and_dissolving.php">Solutions</a><BR>
<a href="/science/acids_and_bases.php">Acids and Bases</a><BR>
<a href="/science/crystals.php">Crystals</a><BR>
<a href="/science/metals.php">Metals</a><BR>
<a href="/science/chemistry/soaps_and_salts.php">Salts and Soaps</a><BR>
<a href="/science/water.php">Water</a><BR>
	 </td><!-- Col 2 -->
     <td valign="top"> 
<b>Other</b><BR>
<a href="/science/chemistry/glossary_and_terms.php">Glossary and Terms</a><BR>
<a href="/science/chemistry/chemistry_lab_equipment.php">Chemistry Lab Equipment</a><BR>
<a href="/science/chemistry/organic_chemistry.php">Organic Chemistry</a><BR>
<a href="/science/chemistry/famous_chemists.php">Famous Chemists</a><BR>
	 </td><!-- Col 3 -->
  </tr>
</table>
<BR>
<b>Elements and the Periodic Table</b><BR>
<a href="/science/elements.php">Elements</a><BR>
<a href="/science/periodic_table.php">Periodic Table</a>
<BR><BR>

<a href="/science/">Science</a> >> <a href="/science/chemistry/">Chemistry for Kids</a> 
    
      
      </div>
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
}
else
{

document.write("<div class='sidebar-right' id='sidebar'><div class='inner'><span id='ad_text'>Advertisement</span><div align='center' id='rightsidebox1'>");
document.write("<div data-pw-desk='med_rect_atf'></div>");
document.write("<div data-pw-mobi='med_rect_atf'></div>");
document.write("</div><table  id='rightsidebox2'><tr><td>");

var value=Math.floor((Math.random()*4)+1);
if (value==1)
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>Vote for your favorite US President:</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpoll.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>George Washington<br><input name='answer' type='radio' value='two'>John Adams<br><input name='answer' type='radio' value='three'>Thomas Jefferson<br><input name='answer' type='radio' value='four'>Abraham Lincoln<br><input name='answer'type='radio' value='five'>Franklin D. Roosevelt<br></font>");
}
else if (value==2)
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>Which superpower would you want if you were a Superhero?</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpollsuperpower.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>Super Strength<br><input name='answer' type='radio' value='two'>Flying<br><input name='answer' type='radio' value='three'>Super Speed<br><input name='answer' type='radio' value='four'>Invisibility<br><input name='answer'type='radio' value='five'>Super Stretch<br></font>");
}
else if (value==3)
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>Vote for your favorite explorer:</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpollexplorers.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>Captain James Cook<br><input name='answer' type='radio' value='two'>Neil Armstrong<br><input name='answer' type='radio' value='three'>Christopher Columbus<br><input name='answer' type='radio' value='four'>Ferdinand Magellan<br><input name='answer'type='radio' value='five'>Marco Polo<br></font>");
}
else
{
document.write("<b><font color='#2C5463' font size='3' face='Arial, Microsoft Sans Serif, sans-serif'>What is your best subject at school?</b></font><table border='0'  width='100%'><tr><td><div align='left'><form method='POST' action='/addpollschoolsubject.php' TARGET='_blank'><font color='#284182' font size='2' face='Arial, Microsoft Sans Serif, sans-serif'><input name='answer' type='radio' value='one'>Math<br><input name='answer' type='radio' value='two'>Reading<br><input name='answer' type='radio' value='three'>Writing<br><input name='answer' type='radio' value='four'>Science<br><input name='answer'type='radio' value='five'>History<br></font>");
}
document.write("</div></td><td><input name='psubmit' type='submit' value='Vote' class='button blue'></form><BR><BR><a href='/takekidspolls1.php'><font size='-1'>More polls</font></a></td></tr></table></td></tr></table>");
}
</script>
</div>
</div>
</div>

<div id="footerid">
<div align="center">
<script>
if ((typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1))
{
document.write("<div data-pw-desk='leaderboard_btf'></div><div data-pw-mobi='leaderboard_btf'></div>");
}
else
{
document.write("<div data-pw-desk='leaderboard_btf'></div><div data-pw-mobi='leaderboard_btf'></div>");
}
</script>
</div>
<BR><BR>
<div id="footer_search">
<form action="https://www.google.com" id="cse-search-box">
  <div>
    <input type="hidden" name="cx" value="partner-pub-1809268078385119:5398998522" />
    <input type="hidden" name="ie" value="UTF-8" />
    <input type="text" name="q" size="36" />
    <input type="submit" name="sa" value="Search" />
  </div>
</form>
<script type="text/javascript" src="https://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en"></script>
</div>
<BR>
<table id="footer_menu"><tr><td> 
<span id="footer_column1">
	<a href="/study.php"><font color="#F48F0C">Homework</font></a><br>	
		<a href="/animals.php">Animals</a><br>
		<a href="/kidsmath/">Math</a><br>
	    <a href="/history/">History</a><br>	
		<a href="/biography/">Biography</a><br>
		<a href="/money/">Money and Finance</a><br> 
	<br>
			<font color="#F48F0C">Biography</font><br>	
		  <a href="/history/art/">Artists</a><br>
		  <a href="/history/civil_rights/">Civil Rights Leaders</a><br>
		  <a href="/biography/entrepreneurs/">Entrepreneurs</a><br>
		  <a href="/biography/explorers/">Explorers</a><br>
		  <a href="/biography/scientists/scientists_and_inventors.php">Inventors and Scientists</a><br>
		  <a href="/biography/women_leaders/">Women Leaders</a><br>
		  <a href="/biography/world_leaders/">World Leaders</a><br>
		  <a href="/biography/uspresidents/">US Presidents</a><br>
		  <br>
</span>	<span id="footer_column2"> 
          <a><font color="#F48F0C">US History</font></a><br>
		  <a href="/history/native_americans.php">Native Americans</a><BR>
		  <a href="/history/colonial_america/">Colonial America</a><br>
          <a href="/history/american_revolution.php">American Revolution</a><BR>
		  <a href="/history/us_1800s/industrial_revolution.php">Industrial Revolution</a><BR>  
          <a href="/history/civil_war.php">American Civil War</a><BR>
          <a href="/history/westward_expansion/">Westward Expansion</a><BR>
		  <a href="/history/us_1900s/great_depression.php">The Great Depression</a><BR>
		  <a href="/history/civil_rights/">Civil Rights Movement</a><BR>
		  <a href="/history/us_1800s/">Pre-1900s</a><BR>
          <a href="/history/us_1900s/">1900 to Present</a><BR>
		  <a href="/history/us_government.php">US Government</a><BR>
          <a href="/geography/us_states/">US State History</a><BR>	
		<br> 
		<a href="/science/"><font color="#F48F0C">Science</font></a><br>
        <a href="/science/biology/">Biology</a><br>
		<a href="/science/chemistry/">Chemistry</a><br>	
		<a href="/science/earth_science/">Earth Science</a><br>							
		<a href="/science/physics/">Physics</a><br>	
	<BR>	
</span>	<span id="footer_column3">  
          <a><font color="#F48F0C">World History</font></a><br>
		  <a href="/history/africa/">Ancient Africa</a><BR>						
          <a href="/history/china/ancient_china.php">Ancient China</a><br>
          <a href="/history/ancient_egypt.php">Ancient Egypt</a><br>
          <a href="/history/ancient_greece.php">Ancient Greece</a><br>
          <a href="/history/mesopotamia/ancient_mesopotamia.php">Ancient Mesopotamia</a><br>		  
          <a href="/history/ancient_rome.php">Ancient Rome</a><br>
          <a href="/history/middle_ages_timeline.php">Middle Ages</a><br>
          <a href="/history/islam/">Islamic Empire</a><BR>		  
          <a href="/history/renaissance.php">Renaissance</a><br>
          <a href="/history/aztec_maya_inca.php">Aztec, Maya, Inca</a><br>
		  <a href="/history/french_revolution/">French Revolution</a><br>
          <a href="/history/world_war_i/">World War 1</a><br>
          <a href="/history/world_war_ii/">World War 2</a><br>
          <a href="/history/cold_war/summary.php">Cold War</a><br>
          <a href="/history/art/">Art History</a><br>	
         <br>
	 
</span>	
<span id="footer_column4">
	 <a href="/geography/"><font color="#F48F0C">Geography</font></a><br>
					<a href="/geography/usgeography.php">United States</a><br>
					<a href="/geography/africa.php">Africa</a><br>
					<a href="/geography/asia.php">Asia</a><br>
					<a href="/geography/centralamerica.php">Central America</a><br>
					<a href="/geography/europe.php">Europe</a><br>
					<a href="/geography/middleeast.php">Middle East</a><br>
					<a href="/geography/northamerica.php">North America</a><br>
					<a href="/geography/oceania.php">Oceania</a><br>
					<a href="/geography/southamerica.php">South America</a><br>
					<a href="/geography/southeastasia.php">Southeast Asia</a><br>	 
<br>
     <a><font color="#F48F0C">Fun Stuff</font></a><br>	
		       <a href="/games/">Educational Games</a><br>
			   <a href="/holidays/kids_calendar.php">Holidays</a><BR>	
			   <a href="/jokes/">Jokes for Kids</a><br>	
			   <a href="/movies.php">Movies</a><br>	
			   <a href="/music.php">Music</a><br>  
			   <a href="/sports.php">Sports</a><br>	

</span> 
	 </td></tr>
<div align="center"><img src="/graphics/ducksters_footer_1.gif" width="745" height="101" alt="" title="" />	</div> 
	 </table>
<BR><BR>
<a href="/about.php">About Ducksters</a>&nbsp;<a href="/privacy_policy.php"><b><font color="#008000">Privacy Policy</b></a></font>&nbsp;
<script type="text/javascript">
var title_1 = document.title;
var location_1 = document.location.href;
document.write ("<a href='/citation.php?title=" + title_1 + "&location=" + location_1 + "'>Cite this Page</a>");
</script>&nbsp;
<BR><BR>
Follow us on <a href="https://www.facebook.com/pages/Ducksters/103074613109209"><img src="/facebook_24.png" width="24" height="24" alt="Ducksters Facebook" title="" /></a> or <a href="https://www.twitter.com/DuckstersKids"><img src="/twitter_24.png" width="24" height="24" alt="Ducksters Twitter" title="" /></a>
<BR><BR>
This site is a product of TSI (Technological Solutions, Inc.), Copyright 2019, All Rights Reserved.
By using this site you agree to the
<a href="/termsofuse.php">Terms of Use.</a>
<BR><BR>
<script type="text/javascript">
var title_1 = document.title;
var location_1 = document.location.href;
document.write ("<a href='/citation.php?title=" + title_1 + "&location=" + location_1 + "'>Cite this Page</a>");
</script>
<BR><BR>
</div>
</div>             

</body>
</html>
