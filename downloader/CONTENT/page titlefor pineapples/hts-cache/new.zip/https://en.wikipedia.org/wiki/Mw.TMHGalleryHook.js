<!DOCTYPE html>
<html class="client-nojs" lang="en" dir="ltr">
<head>
<meta charset="UTF-8"/>
<title>Mw.TMHGalleryHook.js - Wikipedia</title>
<script>document.documentElement.className=document.documentElement.className.replace(/(^|\s)client-nojs(\s|$)/,"$1client-js$2");RLCONF={"wgCanonicalNamespace":"","wgCanonicalSpecialPageName":!1,"wgNamespaceNumber":0,"wgPageName":"Mw.TMHGalleryHook.js","wgTitle":"Mw.TMHGalleryHook.js","wgCurRevisionId":0,"wgRevisionId":0,"wgArticleId":0,"wgIsArticle":!0,"wgIsRedirect":!1,"wgAction":"view","wgUserName":null,"wgUserGroups":["*"],"wgCategories":[],"wgBreakFrames":!1,"wgPageContentLanguage":"en","wgPageContentModel":"wikitext","wgSeparatorTransformTable":["",""],"wgDigitTransformTable":["",""],"wgDefaultDateFormat":"dmy","wgMonthNames":["","January","February","March","April","May","June","July","August","September","October","November","December"],"wgMonthNamesShort":["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"wgRelevantPageName":"Mw.TMHGalleryHook.js","wgRelevantArticleId":0,"wgRequestId":"XO4bCApAAEEAADZwyfMAAAAN","wgCSPNonce":!1,
"wgIsProbablyEditable":!1,"wgRelevantPageIsProbablyEditable":!1,"wgRestrictionCreate":[],"wgMediaViewerOnClick":!0,"wgMediaViewerEnabledByDefault":!0,"wgPopupsReferencePreviews":!1,"wgPopupsConflictsWithNavPopupGadget":!1,"wgVisualEditor":{"pageLanguageCode":"en","pageLanguageDir":"ltr","pageVariantFallbacks":"en"},"wgMFDisplayWikibaseDescriptions":{"search":!0,"nearby":!0,"watchlist":!0,"tagline":!1},"wgRelatedArticles":null,"wgRelatedArticlesUseCirrusSearch":!0,"wgRelatedArticlesOnlyUseCirrusSearch":!1,"wgWMESchemaEditAttemptStepOversample":!1,"wgPoweredByHHVM":!0,"wgULSCurrentAutonym":"English","wgNoticeProject":"wikipedia","wgCentralNoticeCookiesToDelete":[],"wgCentralNoticeCategoriesUsingLegacy":["Fundraising","fundraising"],"wgCentralAuthMobileDomain":!1,"wgEditSubmitButtonLabelPublish":!0};RLSTATE={"ext.gadget.charinsert-styles":"ready","ext.globalCssJs.user.styles":"ready","ext.globalCssJs.site.styles":"ready","site.styles":"ready",
"noscript":"ready","user.styles":"ready","ext.globalCssJs.user":"ready","ext.globalCssJs.site":"ready","user":"ready","user.options":"ready","user.tokens":"loading","mediawiki.legacy.shared":"ready","mediawiki.legacy.commonPrint":"ready","ext.visualEditor.desktopArticleTarget.noscript":"ready","ext.uls.interlanguage":"ready","ext.wikimediaBadges":"ready","ext.3d.styles":"ready","mediawiki.skinning.interface":"ready","skins.vector.styles":"ready"};RLPAGEMODULES=["site","mediawiki.page.startup","mediawiki.page.ready","mediawiki.searchSuggest","ext.gadget.teahouse","ext.gadget.ReferenceTooltips","ext.gadget.watchlist-notice","ext.gadget.DRN-wizard","ext.gadget.charinsert","ext.gadget.refToolbar","ext.gadget.extra-toolbar-buttons","ext.gadget.switcher","ext.centralauth.centralautologin","mmv.head","mmv.bootstrap.autostart","ext.popups","ext.visualEditor.desktopArticleTarget.init","ext.visualEditor.targetLoader","ext.eventLogging","ext.wikimediaEvents","ext.navigationTiming",
"ext.uls.compactlinks","ext.uls.interface","ext.centralNotice.geoIP","ext.centralNotice.startUp","skins.vector.js"];</script>
<script>(RLQ=window.RLQ||[]).push(function(){mw.loader.implement("user.tokens@0tffind",function($,jQuery,require,module){/*@nomin*/mw.user.tokens.set({"editToken":"+\\","patrolToken":"+\\","watchToken":"+\\","csrfToken":"+\\"});
});});</script>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.3d.styles%7Cext.uls.interlanguage%7Cext.visualEditor.desktopArticleTarget.noscript%7Cext.wikimediaBadges%7Cmediawiki.legacy.commonPrint%2Cshared%7Cmediawiki.skinning.interface%7Cskins.vector.styles&amp;only=styles&amp;skin=vector"/>
<script async="" src="/w/load.php?lang=en&amp;modules=startup&amp;only=scripts&amp;skin=vector"></script>
<meta name="ResourceLoaderDynamicStyles" content=""/>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.gadget.charinsert-styles&amp;only=styles&amp;skin=vector"/>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=site.styles&amp;only=styles&amp;skin=vector"/>
<meta name="generator" content="MediaWiki 1.34.0-wmf.6"/>
<meta name="referrer" content="origin"/>
<meta name="referrer" content="origin-when-crossorigin"/>
<meta name="referrer" content="origin-when-cross-origin"/>
<meta name="robots" content="noindex,nofollow"/>
<link rel="alternate" href="android-app://org.wikipedia/http/en.m.wikipedia.org/wiki/Mw.TMHGalleryHook.js"/>
<link rel="apple-touch-icon" href="/static/apple-touch/wikipedia.png"/>
<link rel="shortcut icon" href="/static/favicon/wikipedia.ico"/>
<link rel="search" type="application/opensearchdescription+xml" href="/w/opensearch_desc.php" title="Wikipedia (en)"/>
<link rel="EditURI" type="application/rsd+xml" href="//en.wikipedia.org/w/api.php?action=rsd"/>
<link rel="license" href="//creativecommons.org/licenses/by-sa/3.0/"/>
<link rel="canonical" href="https://en.wikipedia.org/wiki/Mw.TMHGalleryHook.js"/>
<link rel="dns-prefetch" href="//login.wikimedia.org"/>
<link rel="dns-prefetch" href="//meta.wikimedia.org" />
<!--[if lt IE 9]><script src="/w/load.php?lang=qqx&amp;modules=html5shiv&amp;only=scripts&amp;skin=fallback&amp;sync=1"></script><![endif]-->
</head>
<body class="mediawiki ltr sitedir-ltr mw-hide-empty-elt ns-0 ns-subject mw-editable page-Mw_TMHGalleryHook_js rootpage-Mw_TMHGalleryHook_js skin-vector action-view">
<div id="mw-page-base" class="noprint"></div>
<div id="mw-head-base" class="noprint"></div>
<div id="content" class="mw-body" role="main">
	<a id="top"></a>
	<div id="siteNotice" class="mw-body-content"><!-- CentralNotice --></div>
	<div class="mw-indicators mw-body-content">
</div>

	<h1 id="firstHeading" class="firstHeading" lang="en">Mw.TMHGalleryHook.js</h1>
	
	<div id="bodyContent" class="mw-body-content">
		<div id="siteSub" class="noprint">From Wikipedia, the free encyclopedia</div>
		<div id="contentSub"></div>
		
		
		
		<div id="jump-to-nav"></div>
		<a class="mw-jump-link" href="#mw-head">Jump to navigation</a>
		<a class="mw-jump-link" href="#p-search">Jump to search</a>
		<div id="mw-content-text" lang="en" dir="ltr" class="mw-content-ltr"><div class="noarticletext mw-content-ltr" dir="ltr" lang="en">
 <table id="noarticletext" class="plainlinks fmbox fmbox-system" role="presentation"><tbody><tr><td class="mbox-text" style="padding: 0.6em 0.9em;"><div class="infobox" id="sisterproject" style="width: 20em; font-size: 90%; float: right; padding: 0.5em;">Look for <b>Mw.TMHGalleryHook.js</b> on one of Wikipedia's <a href="/wiki/Special:SiteMatrix" title="Special:SiteMatrix">sister projects</a>:
<table style="background: none; margin: auto;" cellpadding="1" cellspacing="0">
 <tbody><tr style="height: 30px;">
  <td style="text-align: center; vertical-align: middle;"><a href="/wiki/File:Wiktionary-logo-v2.svg" class="image"><img alt="Wiktionary-logo-v2.svg" src="//upload.wikimedia.org/wikipedia/en/thumb/0/06/Wiktionary-logo-v2.svg/30px-Wiktionary-logo-v2.svg.png" decoding="async" width="30" height="30" srcset="//upload.wikimedia.org/wikipedia/en/thumb/0/06/Wiktionary-logo-v2.svg/45px-Wiktionary-logo-v2.svg.png 1.5x, //upload.wikimedia.org/wikipedia/en/thumb/0/06/Wiktionary-logo-v2.svg/60px-Wiktionary-logo-v2.svg.png 2x" data-file-width="391" data-file-height="391" /></a></td>
  <td style="vertical-align: middle;"><a href="https://en.wiktionary.org/wiki/Special:Search/Mw.TMHGalleryHook.js" class="extiw" title="wiktionary:Special:Search/Mw.TMHGalleryHook.js">Wiktionary</a> (free dictionary)</td>
 </tr>
 <tr style="height: 30px;">
  <td style="text-align: center; vertical-align: middle;"><a href="/wiki/File:Wikibooks-logo.svg" class="image"><img alt="Wikibooks-logo.svg" src="//upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/30px-Wikibooks-logo.svg.png" decoding="async" width="30" height="30" srcset="//upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/45px-Wikibooks-logo.svg.png 1.5x, //upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikibooks-logo.svg/60px-Wikibooks-logo.svg.png 2x" data-file-width="300" data-file-height="300" /></a></td>
  <td style="vertical-align: middle;"><a href="https://en.wikibooks.org/wiki/Special:Search/Mw.TMHGalleryHook.js" class="extiw" title="wikibooks:Special:Search/Mw.TMHGalleryHook.js">Wikibooks</a> (free textbooks)</td>
 </tr>
 <tr style="height: 30px;">
  <td style="text-align: center; vertical-align: middle;"><a href="/wiki/File:Wikiquote-logo.svg" class="image"><img alt="Wikiquote-logo.svg" src="//upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/25px-Wikiquote-logo.svg.png" decoding="async" width="25" height="30" srcset="//upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/38px-Wikiquote-logo.svg.png 1.5x, //upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Wikiquote-logo.svg/51px-Wikiquote-logo.svg.png 2x" data-file-width="300" data-file-height="355" /></a></td>
  <td style="vertical-align: middle;"><a href="https://en.wikiquote.org/wiki/Special:Search/Mw.TMHGalleryHook.js" class="extiw" title="wikiquote:Special:Search/Mw.TMHGalleryHook.js">Wikiquote</a> (quotations)</td>
 </tr>
 <tr style="height: 30px;">
  <td style="text-align: center; vertical-align: middle;"><a href="/wiki/File:Wikisource-logo.svg" class="image"><img alt="Wikisource-logo.svg" src="//upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/29px-Wikisource-logo.svg.png" decoding="async" width="29" height="30" srcset="//upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/43px-Wikisource-logo.svg.png 1.5x, //upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Wikisource-logo.svg/57px-Wikisource-logo.svg.png 2x" data-file-width="410" data-file-height="430" /></a></td>
  <td style="vertical-align: middle;"><a href="https://en.wikisource.org/wiki/Special:Search/Mw.TMHGalleryHook.js" class="extiw" title="wikisource:Special:Search/Mw.TMHGalleryHook.js">Wikisource</a> (free library)</td>
 </tr>
 <tr style="height: 30px;">
  <td style="text-align: center; vertical-align: middle;"><a href="/wiki/File:Wikiversity-logo.svg" class="image"><img alt="Wikiversity-logo.svg" src="//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/30px-Wikiversity-logo.svg.png" decoding="async" width="30" height="24" srcset="//upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/45px-Wikiversity-logo.svg.png 1.5x, //upload.wikimedia.org/wikipedia/commons/thumb/9/91/Wikiversity-logo.svg/60px-Wikiversity-logo.svg.png 2x" data-file-width="1000" data-file-height="800" /></a></td>
  <td style="vertical-align: middle;"><a href="https://en.wikiversity.org/wiki/Special:Search/Mw.TMHGalleryHook.js" class="extiw" title="wikiversity:Special:Search/Mw.TMHGalleryHook.js">Wikiversity</a> (free learning resources)</td>
 </tr>
 <tr style="height: 30px;">
  <td style="text-align: center; vertical-align: middle;"><a href="/wiki/File:Commons-logo.svg" class="image"><img alt="Commons-logo.svg" src="//upload.wikimedia.org/wikipedia/en/thumb/4/4a/Commons-logo.svg/22px-Commons-logo.svg.png" decoding="async" width="22" height="30" srcset="//upload.wikimedia.org/wikipedia/en/thumb/4/4a/Commons-logo.svg/33px-Commons-logo.svg.png 1.5x, //upload.wikimedia.org/wikipedia/en/thumb/4/4a/Commons-logo.svg/45px-Commons-logo.svg.png 2x" data-file-width="1024" data-file-height="1376" /></a></td>
  <td style="vertical-align: middle;"><a href="https://commons.wikimedia.org/wiki/Special:Search/Mw.TMHGalleryHook.js" class="extiw" title="commons:Special:Search/Mw.TMHGalleryHook.js">Commons</a> (images and media)</td>
 </tr>
 <tr style="height: 30px;">
  <td style="text-align: center; vertical-align: middle;"><a href="/wiki/File:Wikivoyage-Logo-v3-icon.svg" class="image"><img alt="Wikivoyage-Logo-v3-icon.svg" src="//upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/30px-Wikivoyage-Logo-v3-icon.svg.png" decoding="async" width="30" height="30" srcset="//upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/45px-Wikivoyage-Logo-v3-icon.svg.png 1.5x, //upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Wikivoyage-Logo-v3-icon.svg/60px-Wikivoyage-Logo-v3-icon.svg.png 2x" data-file-width="193" data-file-height="193" /></a></td>
  <td style="vertical-align: middle;"><a href="https://en.wikivoyage.org/wiki/Special:Search/Mw.TMHGalleryHook.js" class="extiw" title="wikivoyage:Special:Search/Mw.TMHGalleryHook.js">Wikivoyage</a> (free travel guide)</td>
 </tr>
 <tr style="height: 30px;">
  <td style="text-align: center; vertical-align: middle;"><a href="/wiki/File:Wikinews-logo.svg" class="image"><img alt="Wikinews-logo.svg" src="//upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/30px-Wikinews-logo.svg.png" decoding="async" width="30" height="16" srcset="//upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/45px-Wikinews-logo.svg.png 1.5x, //upload.wikimedia.org/wikipedia/commons/thumb/2/24/Wikinews-logo.svg/60px-Wikinews-logo.svg.png 2x" data-file-width="759" data-file-height="415" /></a></td>
  <td style="vertical-align: middle;"><a href="https://en.wikinews.org/wiki/Special:Search/Mw.TMHGalleryHook.js" class="extiw" title="wikinews:Special:Search/Mw.TMHGalleryHook.js">Wikinews</a> (free news source)</td>
 </tr>
 <tr style="height: 30px;">
  <td style="text-align: center; vertical-align: middle;"><a href="/wiki/File:Wikidata-logo.svg" class="image"><img alt="Wikidata-logo.svg" src="//upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/30px-Wikidata-logo.svg.png" decoding="async" width="30" height="17" srcset="//upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/45px-Wikidata-logo.svg.png 1.5x, //upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Wikidata-logo.svg/60px-Wikidata-logo.svg.png 2x" data-file-width="1050" data-file-height="590" /></a></td>
  <td style="vertical-align: middle;"><a href="https://www.wikidata.org/wiki/Special:Search/Mw.TMHGalleryHook.js" class="extiw" title="wikidata:Special:Search/Mw.TMHGalleryHook.js">Wikidata</a> (free linked database)</td>
 </tr>
</tbody></table></div><b>Wikipedia does not have an article with this exact name.</b> Please <span class="plainlinks"><a class="external text" href="//en.wikipedia.org/w/index.php?search=Mw.TMHGalleryHook.js&amp;title=Special%3ASearch&amp;fulltext=1">search for <i>Mw.TMHGalleryHook.js</i> in Wikipedia</a></span> to check for alternative titles or spellings.
<ul><li><a class="external text" href="//en.wikipedia.org/w/index.php?title=Special:UserLogin&amp;returnto=Mw.TMHGalleryHook.js">Log in or create an account</a> to start the <i><b>Mw.TMHGalleryHook.js</b></i> article, alternatively use the <a href="/wiki/Wikipedia:Article_wizard" title="Wikipedia:Article wizard">Article Wizard</a>, or <a href="/wiki/Wikipedia:Requested_articles" title="Wikipedia:Requested articles">add a request for it</a>.</li>
<li><span class="plainlinks"><a class="external text" href="//en.wikipedia.org/w/index.php?search=Mw.TMHGalleryHook.js&amp;title=Special%3ASearch&amp;fulltext=1&amp;ns0=1">Search for "<i>Mw.TMHGalleryHook.js</i>"</a></span> in existing articles.</li>
<li><a href="/wiki/Special:WhatLinksHere/Mw.TMHGalleryHook.js" title="Special:WhatLinksHere/Mw.TMHGalleryHook.js">Look for pages within Wikipedia that link to this title</a>.</li></ul>
<div id="noarticletext_technical">
<hr />
<p><b>Other reasons this message may be displayed:</b>
</p>
<ul><li>If a page was recently created here, it may not be visible yet because of a delay in updating the database; wait a few minutes or <a class="external text" href="//en.wikipedia.org/w/index.php?title=Mw.TMHGalleryHook.js&amp;action=purge">try the purge function</a>.</li>
<li>Titles on Wikipedia are <b><a href="/wiki/Case_sensitivity" title="Case sensitivity">case sensitive</a></b> except for the first character; please <span class="plainlinks"><a class="external text" href="//en.wikipedia.org/w/index.php?search=Mw.TMHGalleryHook.js&amp;title=Special%3ASearch&amp;fulltext=1">check alternative capitalizations</a></span> and consider adding a <a href="/wiki/Wikipedia:Redirect" title="Wikipedia:Redirect">redirect</a> here to the correct title.</li>
<li>If the page has been deleted, <a class="external text" href="//en.wikipedia.org/w/index.php?title=Special:Log/delete&amp;page=Mw.TMHGalleryHook.js">check the <b>deletion log</b></a>, and see <a href="/wiki/Wikipedia:Why_was_the_page_I_created_deleted%3F" title="Wikipedia:Why was the page I created deleted?">Why was the page I created deleted?</a>.</li></ul>
</div></td></tr></tbody></table>
</div><noscript><img src="//en.wikipedia.org/wiki/Special:CentralAutoLogin/start?type=1x1" alt="" title="" width="1" height="1" style="border: none; position: absolute;" /></noscript></div>
		
		<div class="printfooter">Retrieved from "<a dir="ltr" href="https://en.wikipedia.org/wiki/Mw.TMHGalleryHook.js">https://en.wikipedia.org/wiki/Mw.TMHGalleryHook.js</a>"</div>
		
		<div id="catlinks" class="catlinks catlinks-allhidden" data-mw="interface"></div>
		
		<div class="visualClear"></div>
		
	</div>
</div>

		<div id="mw-navigation">
			<h2>Navigation menu</h2>
			<div id="mw-head">
									<div id="p-personal" role="navigation" aria-labelledby="p-personal-label">
						<h3 id="p-personal-label">Personal tools</h3>
						<ul>
							<li id="pt-anonuserpage">Not logged in</li><li id="pt-anontalk"><a href="/wiki/Special:MyTalk" title="Discussion about edits from this IP address [n]" accesskey="n">Talk</a></li><li id="pt-anoncontribs"><a href="/wiki/Special:MyContributions" title="A list of edits made from this IP address [y]" accesskey="y">Contributions</a></li><li id="pt-createaccount"><a href="/w/index.php?title=Special:CreateAccount&amp;returnto=Mw.TMHGalleryHook.js" title="You are encouraged to create an account and log in; however, it is not mandatory">Create account</a></li><li id="pt-login"><a href="/w/index.php?title=Special:UserLogin&amp;returnto=Mw.TMHGalleryHook.js" title="You&#039;re encouraged to log in; however, it&#039;s not mandatory. [o]" accesskey="o">Log in</a></li>						</ul>
					</div>
									<div id="left-navigation">
										<div id="p-namespaces" role="navigation" class="vectorTabs" aria-labelledby="p-namespaces-label">
						<h3 id="p-namespaces-label">Namespaces</h3>
						<ul>
							<li id="ca-nstab-main" class="selected new"><span><a href="/w/index.php?title=Mw.TMHGalleryHook.js&amp;action=edit&amp;redlink=1" title="View the content page (page does not exist) [c]" accesskey="c">Article</a></span></li><li id="ca-talk" class="new"><span><a href="/w/index.php?title=Talk:Mw.TMHGalleryHook.js&amp;action=edit&amp;redlink=1" rel="discussion" title="Discussion about the content page (page does not exist) [t]" accesskey="t">Talk</a></span></li>						</ul>
					</div>
										<div id="p-variants" role="navigation" class="vectorMenu emptyPortlet" aria-labelledby="p-variants-label">
												<input type="checkbox" class="vectorMenuCheckbox" aria-labelledby="p-variants-label" />
						<h3 id="p-variants-label">
							<span>Variants</span>
						</h3>
						<ul class="menu">
													</ul>
					</div>
									</div>
				<div id="right-navigation">
										<div id="p-views" role="navigation" class="vectorTabs emptyPortlet" aria-labelledby="p-views-label">
						<h3 id="p-views-label">Views</h3>
						<ul>
													</ul>
					</div>
										<div id="p-cactions" role="navigation" class="vectorMenu emptyPortlet" aria-labelledby="p-cactions-label">
						<input type="checkbox" class="vectorMenuCheckbox" aria-labelledby="p-cactions-label" />
						<h3 id="p-cactions-label"><span>More</span></h3>
						<ul class="menu">
													</ul>
					</div>
										<div id="p-search" role="search">
						<h3>
							<label for="searchInput">Search</label>
						</h3>
						<form action="/w/index.php" id="searchform">
							<div id="simpleSearch">
								<input type="search" name="search" placeholder="Search Wikipedia" title="Search Wikipedia [f]" accesskey="f" id="searchInput"/><input type="hidden" value="Special:Search" name="title"/><input type="submit" name="fulltext" value="Search" title="Search Wikipedia for this text" id="mw-searchButton" class="searchButton mw-fallbackSearchButton"/><input type="submit" name="go" value="Go" title="Go to a page with this exact name if it exists" id="searchButton" class="searchButton"/>							</div>
						</form>
					</div>
									</div>
			</div>
			<div id="mw-panel">
				<div id="p-logo" role="banner"><a class="mw-wiki-logo" href="/wiki/Main_Page" title="Visit the main page"></a></div>
						<div class="portal" role="navigation" id="p-navigation" aria-labelledby="p-navigation-label">
			<h3 id="p-navigation-label">Navigation</h3>
			<div class="body">
								<ul>
					<li id="n-mainpage-description"><a href="/wiki/Main_Page" title="Visit the main page [z]" accesskey="z">Main page</a></li><li id="n-contents"><a href="/wiki/Portal:Contents" title="Guides to browsing Wikipedia">Contents</a></li><li id="n-featuredcontent"><a href="/wiki/Portal:Featured_content" title="Featured content – the best of Wikipedia">Featured content</a></li><li id="n-currentevents"><a href="/wiki/Portal:Current_events" title="Find background information on current events">Current events</a></li><li id="n-randompage"><a href="/wiki/Special:Random" title="Load a random article [x]" accesskey="x">Random article</a></li><li id="n-sitesupport"><a href="https://donate.wikimedia.org/wiki/Special:FundraiserRedirector?utm_source=donate&amp;utm_medium=sidebar&amp;utm_campaign=C13_en.wikipedia.org&amp;uselang=en" title="Support us">Donate to Wikipedia</a></li><li id="n-shoplink"><a href="//shop.wikimedia.org" title="Visit the Wikipedia store">Wikipedia store</a></li>				</ul>
							</div>
		</div>
			<div class="portal" role="navigation" id="p-interaction" aria-labelledby="p-interaction-label">
			<h3 id="p-interaction-label">Interaction</h3>
			<div class="body">
								<ul>
					<li id="n-help"><a href="/wiki/Help:Contents" title="Guidance on how to use and edit Wikipedia">Help</a></li><li id="n-aboutsite"><a href="/wiki/Wikipedia:About" title="Find out about Wikipedia">About Wikipedia</a></li><li id="n-portal"><a href="/wiki/Wikipedia:Community_portal" title="About the project, what you can do, where to find things">Community portal</a></li><li id="n-recentchanges"><a href="/wiki/Special:RecentChanges" title="A list of recent changes in the wiki [r]" accesskey="r">Recent changes</a></li><li id="n-contactpage"><a href="//en.wikipedia.org/wiki/Wikipedia:Contact_us" title="How to contact Wikipedia">Contact page</a></li>				</ul>
							</div>
		</div>
			<div class="portal" role="navigation" id="p-tb" aria-labelledby="p-tb-label">
			<h3 id="p-tb-label">Tools</h3>
			<div class="body">
								<ul>
					<li id="t-whatlinkshere"><a href="/wiki/Special:WhatLinksHere/Mw.TMHGalleryHook.js" title="List of all English Wikipedia pages containing links to this page [j]" accesskey="j">What links here</a></li><li id="t-upload"><a href="/wiki/Wikipedia:File_Upload_Wizard" title="Upload files [u]" accesskey="u">Upload file</a></li><li id="t-specialpages"><a href="/wiki/Special:SpecialPages" title="A list of all special pages [q]" accesskey="q">Special pages</a></li><li id="t-info"><a href="/w/index.php?title=Mw.TMHGalleryHook.js&amp;action=info" title="More information about this page">Page information</a></li>				</ul>
							</div>
		</div>
			<div class="portal" role="navigation" id="p-lang" aria-labelledby="p-lang-label">
			<h3 id="p-lang-label">Languages</h3>
			<div class="body">
								<ul>
									</ul>
							</div>
		</div>
				</div>
		</div>
				<div id="footer" role="contentinfo">
						<ul id="footer-places">
								<li id="footer-places-privacy"><a href="https://foundation.wikimedia.org/wiki/Privacy_policy" class="extiw" title="wmf:Privacy policy">Privacy policy</a></li>
								<li id="footer-places-about"><a href="/wiki/Wikipedia:About" title="Wikipedia:About">About Wikipedia</a></li>
								<li id="footer-places-disclaimer"><a href="/wiki/Wikipedia:General_disclaimer" title="Wikipedia:General disclaimer">Disclaimers</a></li>
								<li id="footer-places-contact"><a href="//en.wikipedia.org/wiki/Wikipedia:Contact_us">Contact Wikipedia</a></li>
								<li id="footer-places-developers"><a href="https://www.mediawiki.org/wiki/Special:MyLanguage/How_to_contribute">Developers</a></li>
								<li id="footer-places-cookiestatement"><a href="https://foundation.wikimedia.org/wiki/Cookie_statement">Cookie statement</a></li>
								<li id="footer-places-mobileview"><a href="//en.m.wikipedia.org/w/index.php?title=Mw.TMHGalleryHook.js&amp;mobileaction=toggle_view_mobile" class="noprint stopMobileRedirectToggle">Mobile view</a></li>
							</ul>
										<ul id="footer-icons" class="noprint">
										<li id="footer-copyrightico">
						<a href="https://wikimediafoundation.org/"><img src="/static/images/wikimedia-button.png" srcset="/static/images/wikimedia-button-1.5x.png 1.5x, /static/images/wikimedia-button-2x.png 2x" width="88" height="31" alt="Wikimedia Foundation"/></a>					</li>
										<li id="footer-poweredbyico">
						<a href="https://www.mediawiki.org/"><img src="/static/images/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" srcset="/static/images/poweredby_mediawiki_132x47.png 1.5x, /static/images/poweredby_mediawiki_176x62.png 2x" width="88" height="31"/></a>					</li>
									</ul>
						<div style="clear: both;"></div>
		</div>
		

<script>(RLQ=window.RLQ||[]).push(function(){mw.config.set({"wgBackendResponseTime":261,"wgHostname":"mw1270"});});</script>
</body>
</html>
